import hashlib, json, os, re, struct, subprocess, sys, time
from pathlib import Path

root = Path('/Users/dysodeng/project/go/cloud/sandbox')
workspace = root / '.superpowers/sdd/2026-10-07-launcher-kernel-boundary'
image = 'gcr.io/etcd-development/etcd:v3.6.15@sha256:5ed4e32061aa061f970d6500629213e8579ef17571dcf9789074966acb9afad1'
binary = Path(sys.argv[1]).resolve()
prefix = sys.argv[2]
selected = sys.argv[3:] or ['positive','reject-nnp','reject-missing-cap','reject-extra-cap','reject-role','reject-thread','reject-securebits']
fixture = 'launcher-kernel-boundary'
allowed = {'positive','reject-nnp','reject-missing-cap','reject-extra-cap','reject-role','reject-thread','reject-securebits','reject-setter','reject-partial'}
assert set(selected) <= allowed
assert binary.parent == workspace and binary.is_file()
metadata = {'binary':str(binary), 'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(), 'source_head':None, 'source_hashes':{}, 'cases':[]}
metadata['source_head'] = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
for path in sorted((root/'internal/runtime/launcher').glob('*.go')):
    metadata['source_hashes'][str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
imageinfo = json.loads(subprocess.check_output(['docker','image','inspect',image],text=True))[0]
arch = imageinfo['Architecture']
assert imageinfo['Os']=='linux' and arch in ('arm64','amd64')
data = binary.read_bytes()[:64]
assert data[:6] == b'\x7fELF\x02\x01'
assert struct.unpack_from('<H',data,18)[0] == {'arm64':183,'amd64':62}[arch]
metadata['image'] = image
metadata['architecture'] = arch
all_ok = True
for mode in selected:
    project = f'sandbox-launcher-kernel-test-{os.getpid()}-{time.time_ns()}'
    container, volume = project+'-runner', project+'-tmp'
    case = {'mode':mode,'project':project,'commands':[],'resources_attempted':[],'expected_nonzero':mode=='reject-securebits'}
    metadata['cases'].append(case)
    def run(args, timeout=90):
        result = subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
        case['commands'].append({'args':args,'exit':result.returncode,'output':result.stdout})
        return result
    def must(args):
        r=run(args)
        if r.returncode: raise RuntimeError(f'command failed {args}: {r.stdout}')
        return r.stdout
    try:
        case['resources_attempted'].append('volume')
        must(['docker','volume','create','--label',f'sandbox.test.project={project}','--label',f'sandbox.test.fixture={fixture}',volume])
        caps=['KILL','SETGID','SETUID','SETPCAP']
        if mode=='reject-missing-cap': caps.remove('SETPCAP')
        if mode=='reject-extra-cap': caps.append('CHOWN')
        args=['docker','container','create','--name',container,'--label',f'sandbox.test.project={project}','--label',f'sandbox.test.fixture={fixture}','--network','none','--user','0:0','--read-only','--memory','64m','--pids-limit','128','--cpus','0.5','--cap-drop','ALL']
        for cap in caps: args += ['--cap-add',cap]
        if mode!='reject-nnp': args += ['--security-opt','no-new-privileges']
        args += ['--env',f'SANDBOX_LAUNCHER_TEST_MODE={mode}','--env','GOMAXPROCS=2','--mount',f'type=bind,source={binary},target=/kernel-test,readonly','--mount',f'type=volume,source={volume},target=/tmp','--entrypoint','/kernel-test',image]
        if mode=='positive': args += ['-test.v','-test.count=1','-test.timeout=45s']
        case['resources_attempted'].append('container')
        must(args)
        started=time.monotonic()
        r=run(['docker','container','start','--attach',container])
        case['wall_seconds']=time.monotonic()-started
        raw=workspace/(prefix+'-'+mode+'.log');raw.write_text(r.stdout)
        case['log']=str(raw)
        case['attach_exit']=r.returncode
        state=json.loads(must(['docker','container','inspect',container]))[0]['State']
        case['state']=state
        assert state['Status']=='exited' and state['Running'] is False
        waiting=run(['docker','container','wait',container])
        case['wait_command_exit']=waiting.returncode
        case['wait_result']=waiting.stdout.strip()
        assert waiting.returncode==0 and int(waiting.stdout.strip())==state['ExitCode']
        case['counts']={k:len(re.findall(r'^\s*--- '+k+':',r.stdout,re.M)) for k in ('PASS','FAIL','SKIP')}
        case['top_PASS']=len(re.findall(r'^--- PASS:',r.stdout,re.M))
        if mode=='positive':
            ok=state['ExitCode']==0 and r.returncode==0 and case['counts']['FAIL']==0 and case['counts']['SKIP']==0 and 'kernel boundary verified: PID1 and root monitor exec' in r.stdout
        elif mode=='reject-securebits':
            ok=state['ExitCode']!=0 and 'AllThreadsSyscall6 results differ between threads' in r.stdout and 'kernel boundary verified' not in r.stdout
        else:
            marker = ('kernel boundary verified: ' + mode + ' rejected without boundary')
            ok=state['ExitCode']==0 and r.returncode==0 and marker in r.stdout
        case['accepted']=ok
        all_ok = all_ok and ok
    except Exception as e:
        case['coordinator_error']=repr(e);case['accepted']=False;all_ok=False
    finally:
        for kind,name in [('container',container),('volume',volume)]:
            if kind not in case['resources_attempted']: continue
            fmt='{{ index .Config.Labels "sandbox.test.project" }} {{ index .Config.Labels "sandbox.test.fixture" }}' if kind=='container' else '{{ index .Labels "sandbox.test.project" }} {{ index .Labels "sandbox.test.fixture" }}'
            ownership=run(['docker',kind,'inspect','--format',fmt,name])
            if ownership.returncode==0 and ownership.stdout.strip()==project+' '+fixture:
                removal=run(['docker',kind,'rm']+(['-f'] if kind=='container' else [])+[name])
                if removal.returncode: all_ok=False
        case['inventories']={}
        for kind,args in [('containers',['docker','container','ls','-aq']),('volumes',['docker','volume','ls','-q']),('networks',['docker','network','ls','-q'])]:
            inv=run(args+['--filter',f'label=sandbox.test.project={project}'])
            case['inventories'][kind]={'exit':inv.returncode,'remaining':inv.stdout.strip().splitlines()}
            if inv.returncode or inv.stdout.strip(): all_ok=False
        print(json.dumps({k:case.get(k) for k in ('mode','project','attach_exit','state','counts','accepted','coordinator_error','inventories')}),flush=True)
        (workspace/(prefix+'.json')).write_text(json.dumps(metadata,indent=2)+'\n')
metadata['coordinator_exit']=0 if all_ok else 1
(workspace/(prefix+'.json')).write_text(json.dumps(metadata,indent=2)+'\n')
sys.exit(metadata['coordinator_exit'])
