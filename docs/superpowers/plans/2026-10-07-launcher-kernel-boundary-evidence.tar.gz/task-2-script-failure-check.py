#!/usr/bin/env python3
"""Execute the real canonical shell with isolated fake Docker/Go failure edges.
No real Docker, image operation, Go build, or native kernel proof is performed.
"""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

repo = Path(__file__).resolve().parents[3]
script = repo / 'scripts/test-launcher-kernel.sh'
root = Path(__file__).resolve().parent / ('task-2-script-failures-' + sys.argv[1])
root.mkdir(exist_ok=False)
fake = r'''#!/usr/bin/env python3
import json, os, pathlib, signal, sys, time
root=pathlib.Path(os.environ['FAKE_CASE_DIR'])
a=sys.argv[1:]
def record(event):
 with (root/'events.jsonl').open('a') as f: f.write(json.dumps(event)+'\n')
record({'argv':a,'pid':os.getpid()})
if pathlib.Path(sys.argv[0]).name=='go':
 pathlib.Path(a[a.index('-o')+1]).write_bytes(b'fake compile: shell failure check only\n');sys.exit(0)
statefile=root/'state.json'
state=json.loads(statefile.read_text()) if statefile.exists() else {}
def save(): statefile.write_text(json.dumps(state))
def labels():
 return dict(x.split('=',1) for i,x in enumerate(a) if i and a[i-1]=='--label')
if a[:2]==['image','inspect']:
 if '--format' not in a: print('[{"Os":"linux","Architecture":"arm64"}]')
 elif '{{.Os}}' in a[a.index('--format')+1]: print('linux/arm64')
 else: print('gcr.io/etcd-development/etcd@sha256:5ed4e32061aa061f970d6500629213e8579ef17571dcf9789074966acb9afad1')
elif a[:2]==['volume','create']:
 state['volume']=a[-1];state['labels']=labels();save();print(a[-1])
elif a and a[0]=='create':
 state['container']=a[a.index('--name')+1];state['labels']=labels();save();print('fake-container-id')
elif a and a[0]=='start':
 if os.environ['FAKE_SCENARIO']=='early': sys.exit(17)
 (root/'attach.pid').write_text(str(os.getpid()))
 def ignore_term(sig, frame): record({'survived_TERM':True,'pid':os.getpid()})
 signal.signal(signal.SIGTERM,ignore_term)
 while True: time.sleep(.1)
elif a and a[0]=='kill':
 record({'container_kill_failed':True});sys.exit(19)
elif a and (a[0]=='inspect' or a[:2]==['volume','inspect']):
 if '--format' not in a: print('[{"State":{"Status":"running","Running":true,"OOMKilled":false,"ExitCode":0}}]')
 elif 'Labels' in a[a.index('--format')+1]: print(state['labels']['sandbox.test.project'],state['labels']['sandbox.test.fixture'])
 else: print('running true false 0')
elif a and a[0]=='wait':
 record({'entered_nonterminal_wait':True})
 while True: time.sleep(.1)
elif a and a[0]=='rm':
 assert a[-1]==state['container'];state.pop('container');save();print(a[-1])
elif a[:2]==['volume','rm']:
 assert a[-1]==state['volume'];state.pop('volume');save();print(a[-1])
elif a and (a[0]=='ps' or a[:2] in [['volume','ls'],['network','ls']]):
 key='container' if a[0]=='ps' else a[0]
 if key in state: print(state[key])
else:
 record({'unexpected':a});sys.exit(91)
'''

def check(scenario):
 case=root/scenario;case.mkdir();bin_dir=case/'bin';bin_dir.mkdir()
 for name in ('docker','go'):
  path=bin_dir/name;path.write_text(fake);path.chmod(0o755)
 env=os.environ.copy();env.update(PATH=str(bin_dir)+os.pathsep+env['PATH'],FAKE_CASE_DIR=str(case),FAKE_SCENARIO=scenario)
 started=time.monotonic()
 with (case/'stdout.log').open('w') as out,(case/'stderr.log').open('w') as err:
  proc=subprocess.Popen(['bash',str(script),str(case/'evidence')],env=env,stdout=out,stderr=err,start_new_session=True)
  timed_out=False
  try: exit_code=proc.wait(timeout=8 if scenario=='early' else 69)
  except subprocess.TimeoutExpired:
   timed_out=True
   # Harness watchdog is not script cleanup. Kill only this new process group.
   os.killpg(proc.pid,signal.SIGKILL);exit_code=proc.wait(timeout=3)
 elapsed=time.monotonic()-started
 events=[json.loads(x) for x in (case/'events.jsonl').read_text().splitlines()]
 state=json.loads((case/'state.json').read_text())
 cleanup=(case/'evidence'/'cleanup.log')
 cleanup_text=cleanup.read_text() if cleanup.exists() else ''
 survived=any(e.get('survived_TERM') for e in events)
 pidpath=case/'attach.pid';attach_alive=False
 if pidpath.exists():
  try: os.kill(int(pidpath.read_text()),0);attach_alive=True
  except ProcessLookupError: pass
 checks={
  'bounded_script_exit1':not timed_out and exit_code==1,
  'no_docker_wait_on_nonterminal':not any(e.get('entered_nonterminal_wait') for e in events),
  'exact_container_and_volume_removed':not ('container' in state or 'volume' in state),
  'observed_two_rm_exit0':cleanup_text.count('rm exit=0')==2,
  'observed_three_empty_inventories':cleanup_text.count('inventory result (empty means successful query): \n')==3,
  'no_false_success':'kernel boundary verified: canonical' not in (case/'stdout.log').read_text(),
 }
 if scenario=='timeout':
  checks.update(real_60s_deadline_reached=elapsed>=59,container_kill_actually_failed=any(e.get('container_kill_failed') for e in events),attach_actually_survived_TERM=survived,attach_force_terminated_and_reaped=not timed_out and not attach_alive and (case/'evidence'/'positive-termination.txt').exists() and 'attachExit=137 forced=true joined=true' in (case/'evidence'/'positive-termination.txt').read_text())
 result={'scenario':scenario,'script_exit':exit_code,'watchdog_fired':timed_out,'elapsed_seconds':round(elapsed,3),'checks':checks,'passed':all(checks.values())}
 (case/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 return result

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
 results=list(executor.map(check,['early','timeout']))
summary={'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'results':results,'passed':all(r['passed'] for r in results)}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
sys.exit(0 if summary['passed'] else 1)
