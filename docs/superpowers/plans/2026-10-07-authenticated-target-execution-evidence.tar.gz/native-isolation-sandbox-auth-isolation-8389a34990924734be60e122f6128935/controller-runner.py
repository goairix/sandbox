#!/usr/bin/env python3
"""Controller-owned, retained native monitor-loss namespace isolation evidence (expected nonzero PID1); no build or pull."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[3]
OWN = Path(__file__).resolve().parent
IMAGE = "gcr.io/etcd-development/etcd:v3.6.15@sha256:5ed4e32061aa061f970d6500629213e8579ef17571dcf9789074966acb9afad1"
FIXTURE = "authenticated-target-process-isolation"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate trusted evidence JSON field: " + key)
        result[key] = value
    return result


def run_gate(args):
    binary = Path(args.binary).resolve(strict=True)
    manifest_path = Path(args.manifest).resolve(strict=True)
    if not binary.is_relative_to(OWN) or not manifest_path.is_relative_to(OWN):
        raise ValueError("Binary and manifest must be in this plan's owned workspace")
    manifest = json.loads(manifest_path.read_text())
    expected = manifest["source_sha256"]
    expected_binary = manifest["binary_sha256"]
    if not expected or sha(binary) != expected_binary:
        raise ValueError("Missing source freeze or compiled binary digest mismatch")
    for name, digest in expected.items():
        source = ROOT / name
        if not name.startswith(("internal/runtime/controltarget/", "internal/runtime/controlprotocol/", "internal/runtime/launcher/", "internal/runtime/controlrunner/", "cmd/sandbox-launcher/")) and name not in ("go.mod", "go.sum"):
            raise ValueError("Unexpected source path in native manifest")
        if source.resolve() != source.absolute() or sha(source) != digest:
            raise ValueError("Current source mismatch before native run: " + name)
    with binary.open("rb") as stream:
        header = stream.read(20)
    machine = {"arm64": 183, "amd64": 62}.get(manifest["goarch"])
    if header[:6] != b"\x7fELF\x02\x01" or int.from_bytes(header[18:20], "little") != machine:
        raise ValueError("Native test binary must be matching Linux64 little-endian ELF")
    extra_programs = {"/task3/sandbox-launcher": Path(args.monitor).resolve(strict=True),
                      "/task3/user-helper": Path(args.user).resolve(strict=True)}
    extra_expected = manifest["program_sha256"]
    for target, program in extra_programs.items():
        if not program.is_relative_to(OWN) or sha(program) != extra_expected[target]:
            raise ValueError("Extra program custody/digest mismatch: " + target)
        h = program.read_bytes()[:20]
        if h[:6] != b"\x7fELF\x02\x01" or int.from_bytes(h[18:20], "little") != machine:
            raise ValueError("Extra program ELF architecture mismatch: " + target)
    project = "sandbox-auth-isolation-" + uuid.uuid4().hex
    evidence = OWN / ("native-isolation-" + project)
    evidence.mkdir(mode=0o700)
    (evidence / "manifest.json").write_bytes(manifest_path.read_bytes())
    for name, digest in expected.items():
        source_bytes = (ROOT / name).read_bytes()
        if hashlib.sha256(source_bytes).hexdigest() != digest:
            raise ValueError("Frozen source changed during retained snapshot: " + name)
        retained_source = evidence / "source" / name
        retained_source.parent.mkdir(parents=True, exist_ok=True)
        retained_source.write_bytes(source_bytes)
    runner_bytes = Path(__file__).read_bytes()
    (evidence / "controller-runner.py").write_bytes(runner_bytes)
    runner_hash = hashlib.sha256(runner_bytes).hexdigest()
    records = []
    attempted_container = False
    attempted_volume = False
    attempted_journal = False
    container = project + "-runner"
    volume = project + "-tmp"
    journal = project + "-journal"
    fixture_dir = evidence / "fixture"
    fixture_dir.mkdir(mode=0o755)
    identity_file = fixture_dir / "identity.json"
    identity_file.write_text("{}\n")
    identity_file.chmod(0o444)
    result = 2
    details = {"project": project, "fixture": FIXTURE, "binary_sha256": expected_binary,
               "manifest_sha256": sha(manifest_path), "source_sha256": expected,
               "source_hash_mismatch_after": [], "actual_test_exit": None, "program_sha256": extra_expected,
               "runner_sha256": runner_hash, "scenario": args.scenario}

    def invoke(argv, timeout=60, required=True):
        start = time.time()
        monotonic_start = time.monotonic()
        try:
            proc = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=timeout)
            code, stdout, stderr = proc.returncode, proc.stdout.decode(errors="replace"), proc.stderr.decode(errors="replace")
        except subprocess.TimeoutExpired as exc:
            code = 124
            stdout = (exc.stdout or b"").decode(errors="replace")
            stderr = (exc.stderr or b"").decode(errors="replace") + "\ncontroller command timeout\n"
        record = {"argv": argv, "assigned_go_env": {}, "start_unix": start,
                  "end_unix": time.time(), "elapsed_seconds": time.monotonic() - monotonic_start,
                  "exit": code, "stdout": stdout, "stderr": stderr}
        records.append(record)
        (evidence / (str(len(records)).zfill(2) + ".json")).write_text(json.dumps(record, indent=2) + "\n")
        if required and code != 0:
            raise RuntimeError("Owned command failed: " + json.dumps(argv) + " exit=" + str(code))
        return record

    def inspect_labels(kind, name):
        r = invoke(["docker", kind, "inspect", name], required=False)
        if r["exit"] != 0:
            return None
        obj = json.loads(r["stdout"])[0]
        labels = obj.get("Labels", {}) if kind == "volume" else obj["Config"].get("Labels", {})
        if labels.get("sandbox.test.project") != project or labels.get("sandbox.test.fixture") != FIXTURE:
            raise RuntimeError("Owned resource labels do not match; removal refused")
        return obj

    try:
        image = json.loads(invoke(["docker", "image", "inspect", IMAGE])["stdout"])[0]
        if image["Os"] != "linux" or image["Architecture"] not in ("arm64", "amd64"):
            raise RuntimeError("Unsupported inspected pinned native image")
        details["image_id"] = image["Id"]
        details["architecture"] = image["Architecture"]
        if manifest["goarch"] != image["Architecture"] or manifest["goos"] != "linux" or manifest["cgo_enabled"] != "0":
            raise RuntimeError("Compiled manifest does not match inspected image/CGO0 contract")
        attempted_volume = True
        invoke(["docker", "volume", "create", "--label", "sandbox.test.project=" + project,
                "--label", "sandbox.test.fixture=" + FIXTURE, volume])
        attempted_journal = True
        invoke(["docker", "volume", "create", "--label", "sandbox.test.project=" + project,
                "--label", "sandbox.test.fixture=" + FIXTURE, journal])
        attempted_container = True
        invoke(["docker", "container", "create", "--pull=never", "--name", container,
                "--label", "sandbox.test.project=" + project, "--label", "sandbox.test.fixture=" + FIXTURE,
                "--network", "none", "--ipc", "private", "--user", "0:0", "--read-only",
                "--security-opt", "no-new-privileges", "--cap-drop", "ALL",
                "--cap-add", "KILL", "--cap-add", "SETGID", "--cap-add", "SETUID", "--cap-add", "SETPCAP",
                "--memory", "64m", "--memory-swap", "64m", "--pids-limit", "128", "--cpus", "0.5",
                "--env", "GOMAXPROCS=2",
                "--env", "SANDBOX_TASK3_NATIVE=1",
                "--env", "SANDBOX_TASK3_MONITOR=/task3/sandbox-launcher",
                "--env", "SANDBOX_TASK3_USER=/task3/user-helper",
                "--env", "SANDBOX_TASK3_ATTESTATION=/task3/fixture/identity.json", "--mount", "type=bind,source=" + str(binary) + ",target=/task3/test-pid1,readonly",
                "--mount", "type=bind,source=" + str(extra_programs["/task3/sandbox-launcher"]) + ",target=/task3/sandbox-launcher,readonly",
                "--mount", "type=bind,source=" + str(extra_programs["/task3/user-helper"]) + ",target=/task3/user-helper,readonly",
                "--mount", "type=bind,source=" + str(fixture_dir) + ",target=/task3/fixture,readonly",
                "--mount", "type=volume,source=" + journal + ",target=/journal",
                "--mount", "type=volume,source=" + volume + ",target=/tmp", "--entrypoint", "/task3/test-pid1",
                IMAGE, "-test.v", "-test.count=1", "-test.timeout=45s", "-test.run=" + args.select])
        obj = inspect_labels("container", container)
        h = obj["HostConfig"]
        if h["Memory"] != 67108864 or h["MemorySwap"] != 67108864 or h["PidsLimit"] != 128 or h["NanoCpus"] != 500000000:
            raise RuntimeError("Actual quota mismatch")
        if h["Privileged"] or h["PidMode"] or h["IpcMode"] != "private" or h["NetworkMode"] != "none" or not h["ReadonlyRootfs"]:
            raise RuntimeError("Actual namespace/rootfs boundary mismatch")
        if obj["Config"]["User"] != "0:0" or sorted(item.removeprefix("CAP_") for item in h["CapAdd"]) != ["KILL", "SETGID", "SETPCAP", "SETUID"] or h["CapDrop"] != ["ALL"]:
            raise RuntimeError("Actual UID/capability boundary mismatch")
        if not any("no-new-privileges" in item for item in h["SecurityOpt"]):
            raise RuntimeError("Actual NNP missing")
        if obj["Image"] != image["Id"] or h.get("CgroupnsMode") == "host":
            raise RuntimeError("Actual image/cgroup namespace mismatch")
        mounts = {m["Destination"]: m for m in obj["Mounts"]}
        expected_mounts = {"/task3/test-pid1": ("bind", str(binary)),
                           **{target: ("bind", str(program)) for target, program in extra_programs.items()},
                           "/task3/fixture": ("bind", str(fixture_dir)),
                           "/tmp": ("volume", volume), "/journal": ("volume", journal)}
        if set(mounts) != set(expected_mounts):
            raise RuntimeError("Actual mount-set mismatch")
        for target, (kind, source) in expected_mounts.items():
            m = mounts[target]
            if m["Type"] != kind or (m["Source"] if kind == "bind" else m["Name"]) != source or m["RW"] != (kind == "volume"):
                raise RuntimeError("Actual protected mount mismatch: " + target)
        contract = {"image_id": image["Id"], "architecture": image["Architecture"],
                    "launcher_sha256": extra_expected["/task3/sandbox-launcher"],
                    "uid": 1000, "gid": 1000, "network_allowed": False,
                    "security": {"cap_add": ["KILL", "SETGID", "SETUID", "SETPCAP"],
                                 "cap_drop": ["ALL"], "no_new_privileges": True,
                                 "readonly_rootfs": True, "pid_mode": "private", "network_mode": "none",
                                 "memory_bytes": h["Memory"], "pids_limit": h["PidsLimit"], "nano_cpus": h["NanoCpus"]},
                    "program_paths": ["/task3/test-pid1", "/task3/sandbox-launcher", "/task3/user-helper"]}
        canonical = json.dumps(contract, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        identity = {"version": 1, "runtime_id": obj["Id"], "runtime_uid": obj["Id"],
                    "image_id": image["Id"], "architecture": image["Architecture"],
                    "contract_digest": hashlib.sha256(canonical.encode()).hexdigest(), "contract_json": canonical}
        identity_file.chmod(0o644)
        identity_file.write_text(json.dumps(identity, indent=2) + "\n")
        identity_file.chmod(0o444)
        details["fixture_identity"] = identity
        details["normalized_inspect"] = {"pid_mode_raw": h["PidMode"], "pid_mode_normalized": "private",
                                        "ipc_mode": h["IpcMode"], "memory_swap": h["MemorySwap"],
                                        "management_user": obj["Config"]["User"], "exact_mounts_checked": True}
        print("Native owned project=" + project + " original64MiB/128pids/0.5CPU architecture=" + image["Architecture"], flush=True)
        attach = invoke(["docker", "container", "start", "--attach", container], timeout=75, required=False)
        (evidence / "native-output.log").write_text(attach["stdout"] + attach["stderr"])
        obj = inspect_labels("container", container)
        state = obj["State"]
        details["state"] = state
        if state["Status"] != "exited" or state["Running"] or state["OOMKilled"]:
            raise RuntimeError("No safe completed native test observation")
        details["actual_test_exit"] = state["ExitCode"]
        details["passes"] = len(re.findall(r"^\s*--- PASS:", attach["stdout"], re.M))
        details["failures"] = len(re.findall(r"^\s*--- FAIL:", attach["stdout"], re.M))
        details["skips"] = len(re.findall(r"^\s*--- SKIP:", attach["stdout"], re.M))
        output = attach["stdout"] + "\n" + attach["stderr"]
        events = {}
        for prefix in ("sandbox-pre-loss ", "sandbox-isolation "):
            lines = [line[len(prefix):] for line in output.splitlines() if line.startswith(prefix)]
            if len(lines) != 1 or len(lines[0].encode()) > 32768:
                raise RuntimeError("Missing/duplicate/oversized trusted isolation event: " + prefix)
            events[prefix.strip()] = json.loads(lines[0], object_pairs_hook=strict_object)
        before = events["sandbox-pre-loss"]
        isolated = events["sandbox-isolation"]
        if not isinstance(before, dict) or not isinstance(isolated, dict):
            raise RuntimeError("Trusted isolation events must be objects")
        if set(isolated) != {"version", "pid", "reason", "gate_closed", "executions", "exit_code"}:
            raise RuntimeError("Unknown/missing trusted isolation event field")
        for obj, key, wanted in ((before, "version", 1), (isolated, "version", 1),
                                 (isolated, "pid", 1), (isolated, "exit_code", 70)):
            if type(obj.get(key)) is not int or obj[key] != wanted:
                raise RuntimeError("Isolation event integer version/PID/exit mismatch")
        scenario = {"monitor-loss": ("monitor_lost", "held_pidfd_SIGKILL", 9),
                    "monitor-watchdog": ("monitor_watchdog", "held_pidfd_SIGSTOP", 19),
                    "output-backpressure": ("stream_blocked", "bounded_output_backpressure", 0)}[args.scenario]
        if isolated.get("reason") != scenario[0] or isolated.get("gate_closed") is not True:
            raise RuntimeError("Exact scenario closure observation missing")
        entries = isolated.get("executions")
        if not isinstance(entries, list) or not 1 <= len(entries) <= 64:
            raise RuntimeError("Invalid bounded isolation execution census")
        matched = []
        seen_commands = set()
        for entry in entries:
            if not isinstance(entry, dict) or set(entry) != {
                    "command_id", "monitor_pid", "root_pid", "state", "terminal_receipt", "owner_joined", "wait_joined"}:
                raise RuntimeError("Unknown/missing bounded isolation execution field")
            command_id = entry.get("command_id")
            if (not isinstance(command_id, str) or not re.fullmatch(
                    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", command_id)
                    or command_id in seen_commands):
                raise RuntimeError("Invalid/duplicate isolated original command")
            seen_commands.add(command_id)
            if any(type(entry.get(key)) is not int or entry[key] < 2 for key in ("monitor_pid", "root_pid")):
                raise RuntimeError("Invalid isolated actual process registration")
            if entry.get("state") != "unknown" or entry.get("terminal_receipt") is not False:
                raise RuntimeError("Isolation must remain unknown without terminal receipt")
            for key in ("owner_joined", "wait_joined"):
                if type(entry.get(key)) is not bool:
                    raise RuntimeError("Missing honest bounded-owner join outcome")
            if entry.get("command_id") == before.get("command_id"):
                matched.append(entry)
        if len(matched) != 1:
            raise RuntimeError("Original pre-loss command registration not matched exactly")
        entry = matched[0]
        if not re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", before.get("command_id", "")):
            raise RuntimeError("Invalid original command ID")
        for key in ("monitor_pid", "root_pid"):
            if type(before.get(key)) is not int or before[key] < 2 or entry.get(key) != before[key]:
                raise RuntimeError("Original actual process registration mismatch")
        if set(before) != {"version", "command_id", "monitor_pid", "root_pid", "root_observed", "trigger"}:
            raise RuntimeError("Unknown or missing trusted pre-loss evidence field")
        trigger = before.get("trigger")
        if (before["root_pid"] == before["monitor_pid"] or not isinstance(trigger, dict)
                or set(trigger) != {"method", "signal"}
                or trigger["method"] != scenario[1]
                or type(trigger["signal"]) is not int or trigger["signal"] != scenario[2]):
            raise RuntimeError("Missing exact scenario physical-fault trigger")
        observed = before.get("root_observed")
        if not isinstance(observed, dict) or set(observed) != {
                "uids", "gids", "groups", "caps", "no_new_privs", "seccomp", "ppid", "cgroup"}:
            raise RuntimeError("Missing/extraneous actual pre-loss root observation")
        for key in ("uids", "gids"):
            ids = observed[key]
            if (not isinstance(ids, list) or len(ids) != 4
                    or any(type(value) is not int or value != 1000 for value in ids)):
                raise RuntimeError("Actual pre-loss user credentials mismatch: " + key)
        caps = observed["caps"]
        if (observed["groups"] != [] or not isinstance(caps, dict)
                or set(caps) != {"inheritable", "permitted", "effective", "bounding", "ambient"}
                or any(type(value) is not int or value != 0 for value in caps.values())):
            raise RuntimeError("Actual pre-loss groups/capabilities mismatch")
        for key, wanted in (("no_new_privs", 1), ("seccomp", 2), ("ppid", before["monitor_pid"])):
            if type(observed[key]) is not int or observed[key] != wanted:
                raise RuntimeError("Actual pre-loss root protection/owner mismatch: " + key)
        # This exact private cgroup namespace fixture exposes its unified root as 0::/.
        # The trusted helper reads actual /proc/<root>/cgroup before sending the held pidfd signal.
        if observed["cgroup"] != "0::/\n":
            raise RuntimeError("Actual pre-loss root cgroup differs from private fixture root")
        details["trusted_isolation_events"] = events
        details["unjoined_owners"] = [entry["command_id"] for entry in entries if not entry["owner_joined"] or not entry["wait_joined"]]
        details["outcome_kind"] = "expected_nonzero_PID1_namespace_isolation_not_Go_test_PASS"
        if (state["ExitCode"] != 70 or attach["exit"] != 70 or details["passes"] != 0
                or details["failures"] != 0 or details["skips"] != 0):
            raise RuntimeError("Actual host-observed isolation outcome mismatch")
        details["attach_elapsed_seconds"] = attach["elapsed_seconds"]
        if args.scenario == "monitor-watchdog" and not 28 <= attach["elapsed_seconds"] <= 45:
            raise RuntimeError("Stopped-monitor isolation did not match one absolute cleanup budget")
        result = 0
    except Exception as exc:
        details["controller_error"] = str(exc)
        print(str(exc), file=sys.stderr, flush=True)
        result = 2
    finally:
        cleanup_errors = []
        for kind, name, attempted in (("container", container, attempted_container), ("volume", volume, attempted_volume), ("volume", journal, attempted_journal)):
            if not attempted:
                continue
            try:
                obj = inspect_labels(kind, name)
                if obj is not None:
                    cmd = ["docker", kind, "rm"] + (["-f"] if kind == "container" else []) + [name]
                    invoke(cmd)
            except Exception as exc:
                cleanup_errors.append(str(exc))
        for kind in ("container", "volume"):
            try:
                r = invoke(["docker", kind, "ls", "-q"] + (["-a"] if kind == "container" else []) +
                           ["--filter", "label=sandbox.test.project=" + project,
                            "--filter", "label=sandbox.test.fixture=" + FIXTURE])
                if r["stdout"].strip():
                    cleanup_errors.append("Owned residual " + kind + ": " + r["stdout"])
            except Exception as exc:
                cleanup_errors.append(str(exc))
        details["cleanup_errors"] = cleanup_errors
        details["source_hash_mismatch_after"] = [name for name, digest in expected.items() if sha(ROOT / name) != digest]
        details["program_hash_mismatch_after"] = [target for target, program in extra_programs.items() if sha(program) != extra_expected[target]]
        if sha(binary) != expected_binary:
            details["program_hash_mismatch_after"].append("/task3/test-pid1")
        if cleanup_errors or details["source_hash_mismatch_after"] or details["program_hash_mismatch_after"]:
            result = 2
        details["controller_exit"] = result
        (evidence / "proof.json").write_text(json.dumps(details, indent=2) + "\n")
        print(json.dumps({"evidence": str(evidence), "actual_exit": details["actual_test_exit"],
                          "controller_exit": result, "passes": details.get("passes"),
                          "failures": details.get("failures"), "skips": details.get("skips"),
                          "cleanup_errors": cleanup_errors}), flush=True)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--select", required=True)
    parser.add_argument("--monitor", required=True)
    parser.add_argument("--user", required=True)
    parser.add_argument("--scenario", choices=("monitor-loss", "monitor-watchdog", "output-backpressure"), default="monitor-loss")
    sys.exit(run_gate(parser.parse_args()))
