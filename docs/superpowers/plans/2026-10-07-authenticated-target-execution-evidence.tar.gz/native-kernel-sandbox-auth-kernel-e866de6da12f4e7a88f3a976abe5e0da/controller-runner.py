#!/usr/bin/env python3
"""Controller-owned, retained native kernel-origin evidence; no build or pull."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[3]
OWN = Path(__file__).resolve().parent
IMAGE = "gcr.io/etcd-development/etcd:v3.6.15@sha256:5ed4e32061aa061f970d6500629213e8579ef17571dcf9789074966acb9afad1"
FIXTURE = "authenticated-target-kernel-origin"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_gate(args):
    binary = Path(args.binary).resolve(strict=True)
    manifest_path = Path(args.manifest).resolve(strict=True)
    if not binary.is_relative_to(OWN) or not manifest_path.is_relative_to(OWN):
        raise ValueError("Binary and manifest must be in this plan's owned workspace")
    manifest = json.loads(manifest_path.read_text())
    expected = manifest["source_sha256"]
    expected_binary = manifest["binary_sha256"]
    if not expected or sha(binary) != expected_binary:
        raise ValueError("Missing source freeze or compiled binary digest mismatch")
    for name, digest in expected.items():
        source = ROOT / name
        if not name.startswith(("internal/runtime/controltarget/", "internal/runtime/controlprotocol/", "internal/runtime/launcher/")) and name not in ("go.mod", "go.sum"):
            raise ValueError("Unexpected source path in native manifest")
        if source.resolve() != source.absolute() or sha(source) != digest:
            raise ValueError("Current source mismatch before native run: " + name)
    with binary.open("rb") as stream:
        header = stream.read(20)
    machine = {"arm64": 183, "amd64": 62}.get(manifest["goarch"])
    if header[:6] != b"\x7fELF\x02\x01" or int.from_bytes(header[18:20], "little") != machine:
        raise ValueError("Native test binary must be matching Linux64 little-endian ELF")
    project = "sandbox-auth-kernel-" + uuid.uuid4().hex
    evidence = OWN / ("native-kernel-" + project)
    evidence.mkdir(mode=0o700)
    records = []
    attempted_container = False
    attempted_volume = False
    container = project + "-runner"
    volume = project + "-tmp"
    result = 2
    details = {"project": project, "fixture": FIXTURE, "binary_sha256": expected_binary,
               "manifest_sha256": sha(manifest_path), "source_sha256": expected,
               "source_hash_mismatch_after": [], "actual_test_exit": None}

    def invoke(argv, timeout=60, required=True):
        start = time.time()
        monotonic_start = time.monotonic()
        try:
            proc = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=timeout)
            code, stdout, stderr = proc.returncode, proc.stdout.decode(errors="replace"), proc.stderr.decode(errors="replace")
        except subprocess.TimeoutExpired as exc:
            code = 124
            stdout = (exc.stdout or b"").decode(errors="replace")
            stderr = (exc.stderr or b"").decode(errors="replace") + "\ncontroller command timeout\n"
        record = {"argv": argv, "assigned_go_env": {}, "start_unix": start,
                  "end_unix": time.time(), "elapsed_seconds": time.monotonic() - monotonic_start,
                  "exit": code, "stdout": stdout, "stderr": stderr}
        records.append(record)
        (evidence / (str(len(records)).zfill(2) + ".json")).write_text(json.dumps(record, indent=2) + "\n")
        if required and code != 0:
            raise RuntimeError("Owned command failed: " + json.dumps(argv) + " exit=" + str(code))
        return record

    def inspect_labels(kind, name):
        r = invoke(["docker", kind, "inspect", name], required=False)
        if r["exit"] != 0:
            return None
        obj = json.loads(r["stdout"])[0]
        labels = obj.get("Labels", {}) if kind == "volume" else obj["Config"].get("Labels", {})
        if labels.get("sandbox.test.project") != project or labels.get("sandbox.test.fixture") != FIXTURE:
            raise RuntimeError("Owned resource labels do not match; removal refused")
        return obj

    try:
        image = json.loads(invoke(["docker", "image", "inspect", IMAGE])["stdout"])[0]
        if image["Os"] != "linux" or image["Architecture"] not in ("arm64", "amd64"):
            raise RuntimeError("Unsupported inspected pinned native image")
        details["image_id"] = image["Id"]
        details["architecture"] = image["Architecture"]
        if manifest["goarch"] != image["Architecture"] or manifest["goos"] != "linux" or manifest["cgo_enabled"] != "0":
            raise RuntimeError("Compiled manifest does not match inspected image/CGO0 contract")
        attempted_volume = True
        invoke(["docker", "volume", "create", "--label", "sandbox.test.project=" + project,
                "--label", "sandbox.test.fixture=" + FIXTURE, volume])
        attempted_container = True
        invoke(["docker", "container", "create", "--pull=never", "--name", container,
                "--label", "sandbox.test.project=" + project, "--label", "sandbox.test.fixture=" + FIXTURE,
                "--network", "none", "--ipc", "private", "--user", "0:0", "--read-only",
                "--security-opt", "no-new-privileges", "--cap-drop", "ALL",
                "--cap-add", "KILL", "--cap-add", "SETGID", "--cap-add", "SETUID", "--cap-add", "SETPCAP",
                "--memory", "64m", "--memory-swap", "64m", "--pids-limit", "128", "--cpus", "0.5",
                "--env", "GOMAXPROCS=2", "--env", "SANDBOX_LAUNCHER_TEST_MODE=positive", "--mount", "type=bind,source=" + str(binary) + ",target=/task3/test-pid1,readonly",
                "--mount", "type=volume,source=" + volume + ",target=/tmp", "--entrypoint", "/task3/test-pid1",
                IMAGE, "-test.v", "-test.count=1", "-test.timeout=30s", "-test.run=" + args.select])
        obj = inspect_labels("container", container)
        h = obj["HostConfig"]
        if h["Memory"] != 67108864 or h["MemorySwap"] != 67108864 or h["PidsLimit"] != 128 or h["NanoCpus"] != 500000000:
            raise RuntimeError("Actual quota mismatch")
        if h["Privileged"] or h["PidMode"] or h["IpcMode"] != "private" or h["NetworkMode"] != "none" or not h["ReadonlyRootfs"]:
            raise RuntimeError("Actual namespace/rootfs boundary mismatch")
        if obj["Config"]["User"] != "0:0" or sorted(item.removeprefix("CAP_") for item in h["CapAdd"]) != ["KILL", "SETGID", "SETPCAP", "SETUID"] or h["CapDrop"] != ["ALL"]:
            raise RuntimeError("Actual UID/capability boundary mismatch")
        if not any("no-new-privileges" in item for item in h["SecurityOpt"]):
            raise RuntimeError("Actual NNP missing")
        print("Native owned project=" + project + " original64MiB/128pids/0.5CPU architecture=" + image["Architecture"], flush=True)
        attach = invoke(["docker", "container", "start", "--attach", container], timeout=60, required=False)
        (evidence / "native-output.log").write_text(attach["stdout"] + attach["stderr"])
        obj = inspect_labels("container", container)
        state = obj["State"]
        details["state"] = state
        if state["Status"] != "exited" or state["Running"] or state["OOMKilled"]:
            raise RuntimeError("No safe completed native test observation")
        details["actual_test_exit"] = state["ExitCode"]
        details["passes"] = len(re.findall(r"^\s*--- PASS:", attach["stdout"], re.M))
        details["failures"] = len(re.findall(r"^\s*--- FAIL:", attach["stdout"], re.M))
        details["skips"] = len(re.findall(r"^\s*--- SKIP:", attach["stdout"], re.M))
        result = state["ExitCode"]
        if result == 0 and (attach["exit"] != 0 or details["passes"] == 0):
            result = 2
    except Exception as exc:
        details["controller_error"] = str(exc)
        print(str(exc), file=sys.stderr, flush=True)
        result = 2
    finally:
        cleanup_errors = []
        for kind, name, attempted in (("container", container, attempted_container), ("volume", volume, attempted_volume)):
            if not attempted:
                continue
            try:
                obj = inspect_labels(kind, name)
                if obj is not None:
                    cmd = ["docker", kind, "rm"] + (["-f"] if kind == "container" else []) + [name]
                    invoke(cmd)
            except Exception as exc:
                cleanup_errors.append(str(exc))
        for kind in ("container", "volume"):
            try:
                r = invoke(["docker", kind, "ls", "-q"] + (["-a"] if kind == "container" else []) +
                           ["--filter", "label=sandbox.test.project=" + project,
                            "--filter", "label=sandbox.test.fixture=" + FIXTURE])
                if r["stdout"].strip():
                    cleanup_errors.append("Owned residual " + kind + ": " + r["stdout"])
            except Exception as exc:
                cleanup_errors.append(str(exc))
        details["cleanup_errors"] = cleanup_errors
        details["source_hash_mismatch_after"] = [name for name, digest in expected.items() if sha(ROOT / name) != digest]
        if cleanup_errors or details["source_hash_mismatch_after"]:
            result = 2
        details["controller_exit"] = result
        (evidence / "proof.json").write_text(json.dumps(details, indent=2) + "\n")
        print(json.dumps({"evidence": str(evidence), "actual_exit": details["actual_test_exit"],
                          "controller_exit": result, "passes": details.get("passes"),
                          "failures": details.get("failures"), "skips": details.get("skips"),
                          "cleanup_errors": cleanup_errors}), flush=True)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--select", required=True)
    sys.exit(run_gate(parser.parse_args()))
