"""Root-owned read-only evidence audit; invokes no Docker/build/test commands."""
import hashlib
import json
from pathlib import Path
import re
import sys

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[2]
evidence = (OWN / sys.argv[1]).resolve(strict=True)
assert evidence.parent == OWN
q = json.loads((evidence / 'proof.json').read_text())
m = json.loads((evidence / 'manifest.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha((evidence / 'manifest.json').read_bytes()) == q['manifest_sha256']
assert sha((evidence / 'controller-runner.py').read_bytes()) == q['runner_sha256']
assert m['source_sha256'] == q['source_sha256']
for f, h in m['source_sha256'].items():
    assert sha((ROOT / f).read_bytes()) == sha((evidence / 'source' / f).read_bytes()) == h, f
for f, h in [('task3-process-arm64.test', q['binary_sha256']),
             ('task3-monitor-arm64', q['program_sha256']['/task3/sandbox-launcher']),
             ('task3-user-arm64', q['program_sha256']['/task3/user-helper'])]:
    assert sha((OWN / f).read_bytes()) == h, f
actual_exit = int(sys.argv[3]) if len(sys.argv) > 3 else 0
records = [json.loads((evidence / f'{n:02}.json').read_text()) for n in range(1, 16)]
assert all(r['exit'] == (actual_exit if i == 5 else 0) for i, r in enumerate(records))
assert all(not r['stderr'] for i, r in enumerate(records) if i != 5)
assert q['actual_test_exit'] == actual_exit
assert q['cleanup_errors'] == q['source_hash_mismatch_after'] == q['program_hash_mismatch_after'] == []
identity = json.loads((evidence / 'fixture/identity.json').read_text())
assert sha(identity['contract_json'].encode()) == identity['contract_digest']
labels = {'sandbox.test.project': q['project'], 'sandbox.test.fixture': q['fixture']}
inspections = []
for n in [5, 7, 8]:
    d = json.loads(records[n-1]['stdout'])[0]
    h = d['HostConfig']
    assert d['Id'] == identity['runtime_uid'] == identity['runtime_id']
    assert d['Image'] == q['image_id'] == identity['image_id']
    assert d['Config']['User'] == '0:0' and d['Config']['Labels'] == labels
    assert h['Memory'] == h['MemorySwap'] == 67108864
    assert h['PidsLimit'] == 128 and h['NanoCpus'] == 500000000
    assert h['NetworkMode'] == 'none' and h['PidMode'] == ''
    assert h['IpcMode'] == h['CgroupnsMode'] == 'private'
    assert h['CapDrop'] == ['ALL']
    assert set(h['CapAdd']) == {'CAP_KILL', 'CAP_SETGID', 'CAP_SETUID', 'CAP_SETPCAP'}
    assert h['SecurityOpt'] == ['no-new-privileges'] and h['ReadonlyRootfs'] and not h['Privileged']
    assert len(d['Mounts']) == 6
    assert {x['Destination'] for x in d['Mounts']} == {'/task3/test-pid1', '/task3/sandbox-launcher', '/task3/user-helper', '/task3/fixture', '/journal', '/tmp'}
    assert all(x['RW'] == (x['Type'] == 'volume') for x in d['Mounts'])
    assert not d['State']['OOMKilled']
    if n > 5:
        assert d['State']['Status'] == 'exited' and not d['State']['Running'] and d['State']['ExitCode'] == actual_exit
    inspections.append({'raw': f'{n:02}.json', 'state': d['State'], 'host_config': h, 'mounts': d['Mounts']})
for n in [10, 12]:
    assert json.loads(records[n-1]['stdout'])[0]['Labels'] == labels
for n in [9, 11, 13]:
    assert records[n-1]['argv'][-1].startswith(q['project'])
for n in [14, 15]:
    assert not records[n-1]['stdout']
    assert all('label='+k+'='+v in records[n-1]['argv'] for k, v in labels.items())
log = (evidence / 'native-output.log').read_text()
assert log == records[5]['stdout'] + records[5]['stderr']
assert len(re.findall(r'^\s*--- PASS:', log, re.M)) == q['passes']
assert len(re.findall(r'^\s*--- FAIL:', log, re.M)) == q['failures']
assert len(re.findall(r'^\s*--- SKIP:', log, re.M)) == q['skips'] == 0
result = {'evidence': str(evidence), 'actual_exit': actual_exit, 'source_count': len(m['source_sha256']),
          'before_after_current_retained_mismatches': 0, 'programs_current_match': True,
          'manifest_sha256': q['manifest_sha256'], 'runner_sha256': q['runner_sha256'],
          'passes': q['passes'], 'failures': q['failures'], 'skips': q['skips'],
          'commands': [{'file': f'{i+1:02}.json', **{k: r[k] for k in ['argv', 'exit', 'start_unix', 'end_unix', 'elapsed_seconds']},
                        'stdout_sha256': sha(r['stdout'].encode()), 'stderr_sha256': sha(r['stderr'].encode())} for i, r in enumerate(records)],
          'inspections': inspections, 'fixture_identity': identity, 'exact_removals': 3, 'empty_own_inventories': 2,
          'scope': 'Test ELF PID1 and actual production monitor; selected cases only; not full production serve/TLS/original etcd/backend/End/idle-fleet proof.'}
out = OWN / sys.argv[2]
assert out.parent == OWN and out.name.endswith('.json')
out.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k: result[k] for k in ['actual_exit', 'source_count', 'before_after_current_retained_mismatches', 'passes', 'failures', 'skips', 'exact_removals', 'empty_own_inventories']}))
