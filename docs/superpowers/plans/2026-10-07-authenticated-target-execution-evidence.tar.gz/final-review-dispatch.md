Subagent (general-purpose):
  description: "Review code changes"
  prompt: |
    You are a Senior Code Reviewer with expertise in software architecture,
    design patterns, and best practices. Your job is to review completed work
    against its plan or requirements and identify issues before they cascade.

    ## What Was Implemented

    Complete NEW authenticated target execution unit: root-certified fresh birth, call-time authenticated clock and pinned mutual TLS; live durable accepted/renew/terminal/unknown journal; bounded real PID1/monitor/user execution and descendant drain; original etcd Prepared delivery, finite EOF/bridge/serve, lifecycle cleanup, current native gates, and reviewed shutdown ownership fix. Existing production Manager/backend selection still uses Redis; later task/dual-drain/settlement/image/adapter/scheduler/collector and removal work remain. Evaluate the entire current unit against its requirements and reasonable user expectations, including interactions across its four tasks.

    ## Requirements / Plan

    /Users/dysodeng/project/go/cloud/sandbox/docs/superpowers/specs/2026-10-07-authenticated-target-execution-design.md (binding spec) and /Users/dysodeng/project/go/cloud/sandbox/docs/superpowers/plans/2026-10-07-authenticated-target-execution.md (plan). Read both completely. Overall migration requirements are docs/superpowers/specs/2026-10-06-etcd-state-management-design.md; only consult named scope/dependency sections when needed, do not mistake this current sub-unit for the entire migration.

    ## Git Range to Review

    **Base:** 4c5c356
    **Head:** 30269f76951de716688a13c82128b5a3aa5834d0

    ```bash
    git diff --stat 4c5c356..30269f76951de716688a13c82128b5a3aa5834d0
    git diff 4c5c356..30269f76951de716688a13c82128b5a3aa5834d0
    ```

    ## The spec is a vision document

    The spec says what the software must do. It does not enumerate every
    input, environment, or condition the software will meet. For behavior
    the spec is silent on, judge by what a reasonable person using this
    software would expect: a reasonable person's expectation is a
    requirement, and a spec's silence is not permission. Grade such
    findings by their effect on that person, not by whether the spec
    mentions the trigger.

    ## Declined to judge

    Before your verdict, list every behavior you considered and set aside
    as outside the plan or spec, one line each, with the reason. The
    executor rules on each line; nothing you set aside is dropped
    silently. An empty list means you set nothing aside.

    ## Read-Only Review

    Your review is read-only on this checkout. Do not mutate the working tree, the index, HEAD, or branch state in any way. Use tools like `git show`, `git diff`, and `git log` to inspect history. If you need a working copy of a different revision, check it out into a separate temporary directory (e.g. `git worktree add /tmp/review-[SHA] [SHA]`) — never move HEAD on this checkout.

    ## You Do Not Dispatch Subagents

    Do all of this review yourself. Never spawn a subagent to review part
    of the diff, and never spawn another reviewer for a second opinion.
    This process already provides every review seat the work gets; a
    reviewer you spawn duplicates one of them at full cost, and its
    verdict counts for nothing. If the diff feels too large for one
    pass, review it in passes yourself and say so in your report.

    ## What to Check

    **Plan alignment:**
    - Does the implementation match the plan / requirements?
    - Are deviations justified improvements, or problematic departures?
    - Is all planned functionality present?

    **Code quality:**
    - Clean separation of concerns?
    - Proper error handling?
    - Type safety where applicable?
    - DRY without premature abstraction?
    - Edge cases handled?

    **Architecture:**
    - Sound design decisions?
    - Reasonable scalability and performance?
    - Security concerns?
    - Integrates cleanly with surrounding code?

    **Testing:**
    - Tests verify real behavior, not mocks?
    - Edge cases covered?
    - Integration tests where they matter?
    - All tests passing?

    **Production readiness:**
    - Migration strategy if schema changed?
    - Backward compatibility considered?
    - Documentation complete?
    - No obvious bugs?

    ## Calibration

    Categorize issues by actual severity. Not everything is Critical.
    Acknowledge what was done well before listing issues — accurate praise
    helps the implementer trust the rest of the feedback.

    If you find significant deviations from the plan, flag them specifically
    so the implementer can confirm whether the deviation was intentional.
    If you find issues with the plan itself rather than the implementation,
    say so.

    ## Output Format

    ### Strengths
    [What's well done? Be specific.]

    ### Issues

    #### Critical (Must Fix)
    [Bugs, security issues, data loss risks, broken functionality]

    #### Important (Should Fix)
    [Architecture problems, missing features, poor error handling, test gaps]

    #### Minor (Nice to Have)
    [Code style, optimization opportunities, documentation polish]

    For each issue:
    - File:line reference
    - What's wrong
    - Why it matters
    - How to fix (if not obvious)

    ### Recommendations
    [Improvements for code quality, architecture, or process]

    ### Assessment

    **Ready to merge?** [Yes | No | With fixes]

    **Reasoning:** [1-2 sentence technical assessment]

    ## Critical Rules

    **DO:**
    - Categorize by actual severity
    - Be specific (file:line, not vague)
    - Explain WHY each issue matters
    - Acknowledge strengths
    - Give a clear verdict

    **DON'T:**
    - Say "looks good" without checking
    - Mark nitpicks as Critical
    - Give feedback on code you didn't actually read
    - Be vague ("improve error handling")
    - Avoid giving a clear verdict

## Full packaged original unit range and independent review seat
Read once /Users/dysodeng/project/go/cloud/sandbox/.superpowers/sdd/2026-10-07-authenticated-target-execution/review-4c5c356..30269f7.diff through EOF, in chunks as needed; it contains all commits, stat and complete extended-context diff. Do not substitute HEAD~1 or Task4-only range; no rederivation with git needed. You authored none of this NEW-unit range; your prior kernel authorship is before the original4c5c356 baseline. Platform fresh-seat creation already failed; inherited completed seat fallback R36 is recorded. Disregard old author-task history and deleted/sibling scratch. This is the ONE entire-unit final review, not a repetition of per-task or old baseline reviews. Review readonly except sole full final report output /Users/dysodeng/project/go/cloud/sandbox/.superpowers/sdd/2026-10-07-authenticated-target-execution/final-review.md. No nested agents/Docker operations/package-wide suite replay. If a specific code doubt lacks retained evidence, identify it before any focused command. Final message is the complete saved report.

## Complete reports, gates and findings to consume
Read complete task-1-report.md/task-1-review.md, task-2-report.md/task-2-review.md, task-3-report.md/task-3-review.md/task-3-fix-round-1-re-review.md, task-4-report.md/task-4-review.md/task-4-fix-1-review.md in this exact own directory. Read progress.md for prior task gate commits, all individual CannotVerify dispositions and every deferred or parked line. Additional current files task-3-cannot-verify-dispositions.md and task-4-cannot-verify-dispositions.md. Reports/evidence are claims to evaluate against source, not authority for your verdict; do not blindly inherit the task reviewers.
Deferred minors to triage openly in this review: Task1 authority_clock_test.go474/481 unbounded listener.accepted receives; Task3 stream_test.go12 compressed nongofmt tests; Task4 retained42metadatafixtureWARNs plus ordinaryDocker--time deprecation. Raise severity based on actual implications; controller has not prejudged the final triage. All prior Important findings were fixed and independently scoped-reviewed; full reports retain original findings and exact boundaries.

## Retained physical/current verification
Task2 own real protected journal native94PASS (20top) and unknown/powerloss limitations; Task3 current fix actualnative12PASS and earlier actual afterspawnmonitorloss70 proof; Task4 coherent00458PASS/11projects,0052PASS/2projects,0061PASS/1project. Root verified exact native source/current-at-run/copied/exactGit/compiler/actualexportroot0755ARM64ELF/originalquotas/knownIDs/cleanup and full outputs. Current final8a0e60a repository test/vet/build/freeze/diff all0, independently verified sources (30269f7 changes only plan checkbox docs). Task4 summary files root-task4-candidate004-all-gates-summary.json, root-task4-candidate005-all-gates-summary.json, root-task4-candidate006-shutdown-summary.json and root-task4-fix1-final-repository-audit.json. Read evidence as needed; do not rerun unchanged native/kernel suites. Each report retains all exact raw paths. Historical RED/setup003/custody/compiler failures remain attributed, not folded into coherent pass totals. Darwin race is not Linux race; CGO0amd64 compile is not actualamd64 execution.

## Named certified predecessor seams
Read permanent tracked docs/superpowers/plans/2026-10-07-monitor-confinement-drain-final-review.md and -verification.md, launcher-kernel-boundary-final-review.md/-verification.md, runtime-target-journal-final-review.md/-verification.md, etcd-exec-effect-final-review.md/-verification.md and etcd-command-authority-final-review.md/-verification.md as relevant inherited evidence. These are completed baseline units. If a new call site poses a concrete outside-diff risk, inspect only the exact original capability/fence, protocol verifier, pinned-journal, kernel/confinement source needed to judge it, name the checked range and boundary. Do not reopen prior tasks or read deleted/sibling scratch. Exact full-Serve postspawn monitorSIGKILL remains unforced R27; historyborrow scheduling is compositional R37; assess these limits against the amended spec, and list every declined-to-judge behavior with its reason before your verdict. Production publication/attestation/time provisioning, FUSE observation, runtime images/adapters, remote End/settlement and fleet capacities remain explicit required downstream gates. Any genuine current contract gap is a review finding.

## Binding constraints verbatim
- Branch `codex/etcd-state-management`; no push/merge/deploy; never read/touch/stage the unrelated `docs/superpowers/plans/2026-09-17-sentinel-kubernetes-129-compatibility.md` edit.
- Own scratch `.superpowers/sdd/2026-10-07-authenticated-target-execution/` only; completed predecessor evidence is read through tracked permanent artifacts, never deleted/sibling scratch.
- Linux amd64/arm64 CGO_ENABLED=0 Go-owned threads; existing kernel/confinement boundaries remain exact, management UID0 and user UID/GID1..2147483647; no new dependencies, SYS_ADMIN/SYS_PTRACE, privileged/host-namespace access, writable delegated cgroups or silent quota increase.
- TLS1.3, ALPN `sandbox-control/v1`, mandatory mutual exact Ed25519 delegate key possession, complete VerifyConnection verification on every handshake, no session resumption/cache, no naked InsecureSkipVerify; certificates alone grant no effect authority.
- Clock observations are call-time controlled UTC with verified uncertainty+measured elapsed<=1second; nil/typed-nil/unauthenticated wire/late source rejects, no time.Now fallback as authority, no per-idle target Lease/timer/clock RPC.
- Target start requires independent current BootID/key/activation/static identity/gate/user contract, authenticated original-backend dynamic context, signed complete descriptor/ticket, live window and durable acceptance before any user spawn. History, signature, local drain and context cancellation alone are not Start, End or owner-release evidence.
- Exactly one completed user spawn and one wait owner per monitor, exact root PID/status attribution, no unrelated child/no new trusted spawn during drain. All management FDs/credentials close before user exec; explicit full user env/argv/cwd/stdin/real PTY semantics, original namespace/cgroup/quotas retained.
- Local journal256MiB default,70%warning/85%new-dangerous-refusal,65536content-files,128-entry pages,8192byte individual exec records; preserve unknown/temps and original fsync/rename/dirsync/pinned-FD protections. Activation wire<=16384bytes, clock wire<=4096bytes, TLS leaf DER<=8192bytes, control header<=131072bytes, stdin<=1048576bytes, output frames<=32768bytes.
- Start ACK precedes long completion wait and releases original capability mutex; accepted-only renewal cannot create/replay a command or extend terminal capability. Original start deadline never extends; renewal remains bounded by current original live capability, business expiry and30second target window.
- Target default MaxActive4, valid1..64; at most16 control connections,5second handshake/header deadline; per-active operation timers/readers/monitors are bounded and joined. No idle-N control worker, global transcript/output buffer or per-sandbox etcd client.
- Every coherent tested/self-reviewed change commits immediately. Meaningful REDs, original whole-task review range and full command/outcome/hash evidence retained; do not regenerate unchanged suites or label Darwin race as native Linux race.
- Native fixtures only already-local pinned `gcr.io/etcd-development/etcd:v3.6.15@sha256:5ed4e32061aa061f970d6500629213e8579ef17571dcf9789074966acb9afad1`, --pull=never, privatePID/netnone/root/NNP/ROroot+programs/dropALL addKILL/SETGID/SETUID/SETPCAP,64MiB/128pids/0.5CPU/GOMAXPROCS2; unique project/fixed fixture labels, exact owned removals and own inventories only.

Idle service boundary: the existing production PID1 main accept path may block passively on the root-protected control listener without periodic wakeups. No idle per-target execution/monitor/refresh actor or etcd client, Lease, timer, ticker, watch or clock RPC is permitted. Connection handlers exist only for actual incoming requests, remain within the original16-connection/five-second handshake-header limits and are stopped/joined on shutdown; bootstrap Hello/activation is bounded and stays closed to user execution. This permits the prescribed server itself, not additional per-idle polling services. Fixed Go runtime threads, socket/FD and memory are actual per-target costs to measure; idle N does not imply zero physical O(N) cost.

Production bootstrap interface: fixed root-protected `/run/sandbox-control/config.json` supplies only pinned roots/binding, independent user/network/contract and authenticated clock socket/public-key configuration; no user environment or arbitrary key/argv/socket flag selects authority. Fixed `/run/sandbox-control/control.sock` may accept bounded plaintext Hello and Root-signed activation installation only while freshly closed, with no user-command acceptance. Bootstrap uses strict uint32-big-endian framing, bounded total messages<=16384bytes, duplicate/unknown/trailing/truncated rejection and original16-connection/five-second request limits. Hello returns copied current constructor-generated Birth diagnostics; independent external Root attestation must bind actual observed runtime UID/current birth/security contract before signing activation. Config or Hello alone cannot supply independent observation. Activation is verified against pinned roots/binding and the live original Birth, then persisted before switching this same protected listener to TLS-only commands. Once activated, plaintext bootstrap cannot downgrade or reopen the gate; uncertain/missing activation stays closed. No file watcher or idle polling service is added.

Public TLS request boundary: exactly one request per TLS connection. Client writes the strict bounded metadata and exact declared binary stdin, then calls TLS CloseWrite. Server requires the completed input EOF before durable acceptance, so extra trailing bytes, truncation, size/purpose/schema violations or missed request deadline cannot start a user. Accepted receipt ACK still precedes bounded output/result streaming. Renewal and diagnostic query use separately authenticated fresh connections; query/duplicate history never grants another spawn. Lost ACK/connection remains unknown and uses the same command identity, not a replacement request. The EOF wait remains within the original five-second handshake/header/input deadline.

Credential comparison seam: add `(*ManagementTLSCredential).MatchesCertificate(certificate []byte) bool` solely to compare the configured immutable custom-certificate bytes with the original Prepared selected issuer; nil/zero/empty credentials or mismatched bytes return false. `Destination.Match` also checks its original exact runtime binding. No key/certificate getter, general signing or effect authority is exposed. Equality proves only configured identity agreement, not root trust, freshness, key possession or delivery permission; actual pinned mutual TLS verification and fresh original etcd/time authorization remain mandatory. This is a focused Task1 interface extension consumed only by Task4, with covering comparison/actual-handshake compatibility tests.

## Root Ruling23 — bounded uncertain renewal reconciliation

Uncertain renewal reconciliation: the original ExecDeliveryHandle retains the last confirmed deadline and at most one exact originally signed pending renewal/deadline before any renewal byte is sent. No further renewal is permitted while pending is unresolved. Query verifies a fresh authenticated target response against these two independently retained exact expected deadlines/context/digests/original window, never a deadline selected from receipt wire. An accepted receipt matching only the old confirmed deadline remains diagnostic and does not clear pending: the original delayed renewal could still arrive later. Only a current query EventAccepted from the same original live Execution owner, matching the exact pending deadline, may confirm it; target query uses bounded/nonblocking owner locking, fresh renewable/failure/terminal checks, and an owner record published only after durable renewal, sole-monitor ordered ACK and post-ACK actual-state checks. It never confirms from raw journal history or a durable-before-monitor-ACK snapshot. EventReceipt marks historical/terminal/unknown diagnostics and cannot reconcile an accepted pending renewal. Terminal receipt may close further renewal; unknown stays fail-closed/queryable; neither signature, event nor reconciliation grants Start, End, remote settlement or a replacement capability. Future renewals still require the original live backend capability/current fences. Meaningful tests force old query before delayed renewal arrival, pending durable-before-ACK rejection, successful exact pending confirmation, terminal/unknown and bounded single-pending refusal.

## Root Ruling24 — named real metadata fixture relay

Native metadata fixture endpoint: the pinned etcd/client Unix transport is supported, but the existing production Backend validates explicit http/https host endpoints. Preserve that production validation and the old three-member fixture ownership helper. Task4 may add a distinctly named test-only single-member fixture whose existing netnone test-parent starts a bounded loopback-only byte relay to the fixed owned-volume etcd Unix socket; the real Backend uses its existing explicit insecure-loopback fixture opt-in and no endpoint autodiscovery. No host port, public address, namespace, privilege or quota is added. Register bounded relay connections/buffers, close both ends/listener and join on fixture stop; report relay cost only in the parent cgroup. Before namespace provisioning, independently Root-inspect exact labeled container UID/image/security/socket-volume custody and verify actual MemberList/header/member name against that owned single member. This is real single-member transaction/full-chain proof, not old three-member failover, production etcd mTLS/RBAC or fleet capacity evidence. No fake etcd client, weakened ownership validator or production fixture bypass is permitted.

## Root Ruling25 — finite production PID1 diagnostics

Ordinary bounded diagnostics: extend the closed protected bootstrap allowlist with read-only `inspect` and the activated pinned-mTLS request allowlist with `exec_inspect`. Production serve PID1 gathers the response synchronously on that finite request, with no subprocess, idle sampler, timer/watch or fixture flag. Requests select no arbitrary path, PID, filter or key. Read only fixed own /proc status/fd/fdinfo, bounded current-namespace process census and own cgroup memory.current/memory.peak/pids.current; limit FD and process entries to128each, individual diagnostic path/comm strings to512bytes, each proc/cgroup file read to16384bytes and total response to16384bytes. Include version/current PID1/constructor Boot, gate and active-command count, actual selected RSS/HWM/Threads/FD flags and cgroup values plus diagnostic-only timestamps. Exceeded/error/inconclusive census returns a bounded error or explicitly incomplete snapshot, never a complete-cost claim. Same original16-connection/five-second request limits and shutdown joins apply. Diagnostic fields/events grant no Start, renewal, receipt, End or remote settlement. Root correlates actual inspected container UID/current TLS identity with each phase. Activated-idle measurements mean zero active commands with one finite diagnostic request/connection/handler; retain that observation overhead explicitly, do not subtract guessed cost or infer a stable memory ceiling/fleet speedup. Root takes only finite bootstrap/idle/one-active samples; no production per-idle polling is added.

## Root Rulings26–28 additions

Accepted delivery resource ownership: add cleanup-only `(*ExecDeliveryHandle).Close() error`. Immediately after accepted ACK, one per-active-handle reader owns the original stream, with a bounded queue of at most two output frames of32768bytes each plus a bounded terminal scalar/receipt of at most8192bytes; no transcript or global buffer. Finish/close on verified terminal, EOF/error, original parent-context cancellation, explicit Close, or a fixed watchdog anchored to accepted-ACK monotonic time plus the signed command timeout (at most3600seconds) plus30seconds. Renewal never extends that local cleanup timer and the timer grants no authority. Reader backpressure/queue exhaustion aborts boundedly and fails closed. Wait/Close/cancellation unregister the timer/context callback, close the underlying stream and join owned started readers/callbacks with existing bounded cleanup/error handling; no detached waiters or idle-N worker. Normal completed streams are reclaimed even if Wait is never called. Close represents local cleanup/unknown, never remote cancellation, End, owner release or settlement; target stream-loss handling may independently isolate the sandbox. Reader faults/Close prohibit further renewal, while later Wait can only diagnose the same original command. Caller-supplied stdout/stderr writers run in the caller's Wait goroutine, never a detached writer worker; arbitrary io.Writer has no cancellation API and must return. Close joins only owned reader/timer/callback activity, not arbitrary caller work, and cannot promise to interrupt a blocked foreign writer. Extra per-active reader/queue/timer/callback cost, backpressure availability and foreign-IO limitations remain explicit.

Changed-seam native fault coverage: retain Task3's actual production-monitor after-spawn loss evidence for unchanged Supervisor/monitor failure policy. New full production serve/TLS integration physically exercises accepted-user output-stream loss/Close (actual admission close, unknown and PID1 isolation with bounded handler shutdown) and separately actual user-start failure such as ENOENT. Do not add production fault hooks, extra trusted children, Dockerexec fault injection, new child privileges or claimed equivalent post-spawn monitor SIGKILL. Exact full-serve after-spawn monitor kill remains individually unforced/CannotVerify, with the retained real Task3 baseline, exact unchanged-source inheritance and new transport failure coupling reported separately. Later production operator/runtime fault tooling must force that precise wrapper-level case; changed coverage does not prove End, remote settlement, or full failure-mode equivalence.

Native fixture publication boundary: provision only through original public AcquireIntent/ClaimCreation/DeclareRuntimeDispatch/BindRuntime/ConsumeRuntimeMount/PublishRuntime APIs, followed by original BeginOperation/Prepare/Deliver; no fake private capability, raw metadata insertion or copied Boot/UID. A separately identified fresh fixture-owned legacy publication delegate may sign ReadyReceipt only after independently Root-observed exact actual container UID, fresh constructor Boot and activated gate inspection, using the original exact creation claim/data-gate epoch and explicit plain-mode mount skip. The legacy publication-delegate certificate and PID1 management-runtime identity certificate intentionally use distinct roles/keys: both bind the original exact namespace/restore/sandbox/workspace/generation and independently observed RuntimeReference{ID,UID,BootID}. Public publication retains that exact runtime tuple, while the management certificate authenticates the fresh PID1-generated key used for TLS/exec receipts. Required agreement is exact original tuple/context, management runtime certificate authenticated by the backend original roots/binding, and byte-identical original selected command-issuer transport credential; it is not byte equality between role-distinct publication/runtime certificates or an invented persisted management-certificate field. Prove and retain this mapping before source freeze. Retain authority provisioning, independent observations, certificate/digest mapping and all actual transaction/activation receipts. This covers a real single-member public metadata transaction and physical execution chain; it does not establish production publication-attester/key provisioning, FUSE mount observation or fleet performance. No new production ReadyReceipt signing API, key getter or fixture bypass is added.

Original backend runtime trust: add comparison/verification-only `(*Destination).VerifyRuntime(verifier *controlprotocol.ManagementVerifier, expected controlprotocol.RuntimeIdentityContext, now time.Time) error` to authenticate its immutable private management-runtime certificate with the backend's original exec verifier/root set/TrustBinding and exact expected identity at a fresh original controlled time. Expose no certificate/private-key getter, callback payload or new capability. Backend verifies before dialing and again after actual TLS and original fence checks immediately before first payload bytes; enforce original trust for renew/query fresh response consumption as well. A caller-configured Destination verifier may not widen the backend's roots or authority/namespace/target/restore binding, even for the same runtime tuple. Keep original issuer-byte matching and actual pinned mutual TLS/receipt signature verification. Cover different unapproved root signing the same exact runtime tuple, stale certificate, wrong binding/identity, and valid independently authenticated role-distinct publication/runtime mapping. This closes a new pre-commit self-review trust gap; no persisted management-certificate field is invented. Active certificate-verification cost and adversarial coverage are retained explicitly.

## Root Ruling30 custody correction

Native executable custody correction: actual Docker rejected archive extraction into the stopped read-only rootfs before any fixture started. Use one additional uniquely project/fixture/role-labeled programs volume and a separate stopped custody container with the same pinned image, original64MiB/128PID/0.5CPU/private-netnone/NNP/exact-four-capability/read-only-root contract; its sole writable mount is that programs volume at /native. Root copies only the three already frozen ELF programs with explicit tar UID/GID0 and0755 through Docker archive extraction into this mount, exports the exact archive for independent hash/ownership/mode verification, then removes the stopped custody container before any execution fixture starts. It never runs a process or supplies a trusted child. Target/initializer/backend mount the verified programs volume read-only at /native; metadata does not mount it. Root-protected configuration/signing custody is still generated only by the actual initializer in its separate owned volumes, not copied host configuration. Source/ELF/compiler freeze remains unchanged; retain the failed setup and the changed mount/observation contract. Docker daemon archive copying is preparation overhead outside measured target cgroup. The extra stopped object/volume and shared read-only program topology are test custody costs, not production image integration or capacity proof. Exact ownership labels, all cleanup and post-run inventories remain required. Primary implementation: [Moby archive writable-path validation](https://github.com/moby/moby/blob/master/daemon/archive_unix.go).


Native acceptance-absence observation: test-only Root may perform one finite nofollow Lstat of the original constructor-owned canonical CommandID at the existing fixed `/run/sandbox-control/journal/commands/<CommandID first two characters>/<CommandID>.json` path in the already Root-custodied mounted control volume. Validate that original UUID and fixed root-owned parent layout; no caller-selected path, Journal.Open, lock, key read, write, key getter, capability or replay is added. Restore the trusted fixture clock and require successful exact-current-UID/Boot pinned-TLS diagnostics with open gate and zero active commands. A positive accepted command must demonstrate the same fixed layout with a regular root-owned0600 record and valid same-protocol terminal query. Require ENOENT for the rejected original command. Absence alone is not cryptographic proof: combine this physical observation with original persist-before-start ordering, successful current diagnostic/query controls and exact original context/digests to establish only fixture-scoped no durable acceptance/no spawn. This adds no production remote absence or Start/End authority. Retain layout coupling, stale-observation risk and synchronous unpreemptible filesystem-call cost; never detach an observation worker. Future layout changes must fail this test rather than silently weaken it.


Native mutation isolation: actual candidate003 proved the first runtime-index mutation was refused, then later original BeginOperation correctly rejected the byte-restored index because its write-once invariant requires CreateRevision==ModRevision. Independently traced command-issuer reuse has the same immutableDispatchKV requirement. A Put cannot restore either shared authority. Preserve production validation and retain this failed native run. Isolate runtime-index and command-issuer value, Lease and same-byte recreation into six exact anchored selectors, each in its own fresh labeled project through the existing original public provisioning, and make no later admission after that mutation. The remaining33 cases use the coherent main Fences selector with fresh original admissions and their original fence checks. No fake capability, old revision reconstruction, raw authority repair or relaxed validator is allowed. This costs six extra finite test projects and setup/cleanup observations, not extra production actors or per-idle sandbox resources; prior partial passes and unconsumed cases remain individually attributed.


Native fixed bridge caller coverage: after consuming the frozen fault/fence candidate, permit one separate narrow native selector that invokes the real immutable `/native/sandbox-launcher bridge` in the existing trusted backend test-parent cgroup as an ordinary active byte-transport caller. Use only owned bounded stdin/stdout pipes, explicit GOMAXPROCS=2, fixed executable/mode, finite parent context, one original registered child wait owner and cleanup/join of every started pipe/callback/child. Pass no signing keys, protected config, certificate selector, arbitrary socket or user program flags. It relays actual pinned mutual TLS and the original backend Prepared execution/query only as bytes; target remains the same real serve PID1 with unchanged quotas/security/topology. This adds no target trusted child, no fault-injection child, privilege, namespace join or product hook. Attribute the finite bridge child/pipe/reader/memory/CPU cost to the backend fixture; fail under the original quota rather than widen it. Success proves only this fixed production bridge path and its bounded cleanup, not future Docker/Kubernetes exec transport adapters, remote End, production image integration or large-N capacity. Do not repeat already-consumed unchanged fence/fault suites to claim this narrow additional proof.


Finite request transport EOF: after successful strict WriteRequest and TLS CloseWrite, Session.Send invokes the original underlying byte connection's optional `CloseWrite() error` when implemented, closing only its write side while preserving response reads. Unsupported connections retain the existing TLS-only closure. This occurs within the same original five-second Send deadline and registered context-close ownership; no reset budget, detached IO/cancel worker or timeout exemption is added. Expose no raw/TLS getter, payload/key callback or authority. A trusted pipe/runtime adapter must implement actual finite EOF and owned idempotent input-close rather than overloading a deadline callback to infer protocol phase. Any half-close failure after bytes preserves the original delivery-unknown handle/command for diagnostic query, never replay, End or fabricated terminal. Underlying custom connection methods remain trusted byte IO and cannot be forcibly preempted in general; their blocking/cleanup limits must be stated. Cover real TLS/request-before-half-close ordering, retained response side and half-close-error propagation with meaningful RED/GREEN regression. Because this changes the production Send seam, additionally run one current direct-Unix NativeSuccess execution/renewal regression and the new narrow real bridge/original Prepared chain under the original frozen custody/quota contract. Previously consumed unchanged full fence/fault suites remain retained without broad repetition. Extra half-close behavior/interface verification and two finite native gates are active-transport costs, not new idle actors or production runtime-adapter/fleet proof.

Transport shutdown lifetime: all Serve handlers that may borrow the Supervisor journal/signer must register under the same protected ownership boundary before use; closing prevents new registration. Stop admission, bounded connections and active executions first, then join all registered transport users before journal close/key destruction. Concurrent public Close calls join the same original close owner/completion and retain its errors; Serve combines its accept/serve error with shutdown errors. Preserve the original finite execution cancellation/isolation policy and do not wait for a stream before initiating the shutdown it needs to finish. No new execution authority, idle actor or public callback/key getter is introduced.

Shutdown regression boundary: host tests may use a package-private ownership coordinator with genuinely owned journal/signing resources and a test-only worker paused after real history Lookup/before signing, without pretending to be a constructor-sealed Linux PID1 Supervisor. Force the old destroy-before-user-join ordering to fail behaviorally, then prove current ordering and an active-stream companion that requires shutdown cancellation to complete; retain targeted host race evidence and its platform limit. This test-only scheduling barrier is not a production fault hook or authority bypass. Pair it with one narrow real production Serve/original-authority native shutdown case whose exact external ordinary-stop marker, selector, outcomes and cleanup are agreed before Root launch under the unchanged frozen quota/custody contract. Source review must verify that the real Serve/Close path consumes the tested ownership coordinator. Do not label coordinator-level timing as an exact forced full-Serve Lookup/sign interleaving; retain the compositional proof boundary. Any changed Close-source inheritance must be recorded precisely; no broad replay of passing unrelated suites.

