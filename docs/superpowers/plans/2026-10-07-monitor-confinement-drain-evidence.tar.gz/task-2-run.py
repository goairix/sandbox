import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path.cwd(); own=root/'.superpowers/sdd/2026-10-07-monitor-confinement-drain'
name=sys.argv[1]; args=sys.argv[2:]; env=dict(os.environ)
while args and '=' in args[0] and not args[0].startswith('-'):
 k,v=args.pop(0).split('=',1);env[k]=v
record={'argv':args,'env':{k:env[k] for k in ['GOOS','GOARCH','CGO_ENABLED','GOMAXPROCS','PATH'] if k in env},'started':time.time(),'sources':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'internal/runtime/launcher').rglob('*')) if p.is_file()},'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
p=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
record.update(exit=p.returncode,ended=time.time(),stdout=p.stdout.decode(errors='replace'),stderr=p.stderr.decode(errors='replace'))
(own/(name+'.json')).write_text(json.dumps(record,indent=2));print(record['stdout'],end='');print(record['stderr'],end='',file=sys.stderr);sys.exit(p.returncode)
