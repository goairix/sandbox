#!/usr/bin/env python3
"""Root-owned one-positive-fixture observation, never product execution."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

repo = Path('/Users/dysodeng/project/go/cloud/sandbox')
own = repo / '.superpowers/sdd/2026-10-07-monitor-confinement-drain'
assert (own / 'plan-path').read_text().strip() == 'docs/superpowers/plans/2026-10-07-monitor-confinement-drain.md'
out = Path(sys.argv[1]).resolve()
assert out.parent == own and not out.exists()
selector, expected = sys.argv[2], int(sys.argv[3])
out.mkdir()
image = 'gcr.io/etcd-development/etcd:v3.6.15@sha256:5ed4e32061aa061f970d6500629213e8579ef17571dcf9789074966acb9afad1'
digest = 'gcr.io/etcd-development/etcd@sha256:5ed4e32061aa061f970d6500629213e8579ef17571dcf9789074966acb9afad1'
project = 'sandbox-monitor-native-' + uuid.uuid4().hex
fixture = 'monitor-confinement-drain'
container, volume = project + '-positive', project + '-tmp'
commands, summary, created, volume_created = [], {}, False, False

def run(argv, name, timeout=30, required=True, env=None):
    record = {'argv': argv, 'name': name, 'started': time.time()}
    if env is not None:
        record['env_overrides'] = {k: env[k] for k in ('CGO_ENABLED', 'GOOS', 'GOARCH') if k in env}
    try:
        p = subprocess.run(argv, cwd=repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        record.update(exit=p.returncode, stdout=p.stdout.decode(errors='replace'), stderr=p.stderr.decode(errors='replace'))
    except subprocess.TimeoutExpired as e:
        record.update(exit='timeout', stdout=(e.stdout or b'').decode(errors='replace'), stderr=(e.stderr or b'').decode(errors='replace'))
    record['ended'] = time.time()
    commands.append(record)
    (out / 'commands.json').write_text(json.dumps(commands, indent=2))
    (out / (name + '.stdout')).write_text(record['stdout'])
    (out / (name + '.stderr')).write_text(record['stderr'])
    if required and record['exit'] != 0:
        raise RuntimeError(name + ' command failed: ' + str(record['exit']))
    return record

def labels_match(data, is_volume=False):
    labels = data['Labels'] if is_volume else data['Config']['Labels']
    return labels.get('sandbox.test.project') == project and labels.get('sandbox.test.fixture') == fixture

failure = None
try:
    info = json.loads(run(['docker', 'image', 'inspect', image], 'image')['stdout'])[0]
    assert digest in info['RepoDigests'] and info['Os'] == 'linux' and info['Architecture'] in ('arm64', 'amd64')
    binary = out / 'launcher.test'
    env = dict(os.environ, CGO_ENABLED='0', GOOS='linux', GOARCH=info['Architecture'])
    source_files = sorted((repo/'internal/runtime/launcher').glob('*.go'))
    source_files.append(repo/'scripts/test-launcher-kernel.sh')
    helper_dir = repo/'internal/runtime/launcher/testdata/drainclone'
    helper = None
    if helper_dir.is_dir():
        helper = out/'drainclone'
        helper_sources = sorted(p for p in helper_dir.rglob('*') if p.is_file() and p.suffix in ('.go', '.s'))
        assert helper_sources, 'empty fixed clone helper source'
        source_files.extend(helper_sources)
    hashes = {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}
    run(['go', 'test', '-c', '-o', str(binary), './internal/runtime/launcher'], 'compile', 60, env=env)
    if helper is not None:
        run(['go', 'build', '-o', str(helper), './internal/runtime/launcher/testdata/drainclone'], 'compile-helper', 60, env=env)
        summary['helper_binary_sha256'] = hashlib.sha256(helper.read_bytes()).hexdigest()
        summary['helper_readonly_path'] = '/drainclone'
    assert hashes == {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}, 'source changed during compile'
    run(['git', 'rev-parse', 'HEAD'], 'source-commit')
    run(['git', 'diff', '--', 'internal/runtime/launcher', 'scripts/test-launcher-kernel.sh'], 'source-diff')
    hashes['binary'] = hashlib.sha256(binary.read_bytes()).hexdigest()
    (out/'source-sha256.json').write_text(json.dumps(hashes, indent=2))
    volume_created = True
    run(['docker', 'volume', 'create', '--label', 'sandbox.test.project='+project, '--label', 'sandbox.test.fixture='+fixture, volume], 'volume-create')
    created = True
    run(['docker', 'create', '--pull=never', '--name', container, '--label', 'sandbox.test.project='+project, '--label', 'sandbox.test.fixture='+fixture,
         '--network', 'none', '--user', '0:0', '--read-only', '--memory', '64m', '--pids-limit', '128', '--cpus', '0.5',
         '--cap-drop', 'ALL', '--cap-add', 'KILL', '--cap-add', 'SETGID', '--cap-add', 'SETUID', '--cap-add', 'SETPCAP',
         '--security-opt', 'no-new-privileges:true', '--mount', 'type=bind,src='+str(binary)+',dst=/launcher.test,readonly',
         *(['--mount', 'type=bind,src='+str(helper)+',dst=/drainclone,readonly'] if helper is not None else []),
         '--mount', 'type=volume,src='+volume+',dst=/tmp', '--env', 'SANDBOX_LAUNCHER_TEST_MODE=positive', '--env', 'GOMAXPROCS=2',
         '--entrypoint', '/launcher.test', image, '-test.v', '-test.count=1', '-test.timeout=40s', '-test.run', selector], 'container-create')
    before = json.loads(run(['docker', 'inspect', container], 'created')['stdout'])[0]
    assert labels_match(before)
    attach = run(['docker', 'start', '-a', container], 'attach', 50, required=False)
    after = json.loads(run(['docker', 'inspect', container], 'exited')['stdout'])[0]
    state = after['State']
    summary.update(project=project, fixture=fixture, container=container, volume=volume, selector=selector, expected=expected,
                   attach_exit=attach['exit'], state=state, source=hashes)
    assert labels_match(after)
    assert attach['exit'] == expected and state['Status'] == 'exited' and not state['Running'] and not state['OOMKilled'] and state['ExitCode'] == expected
    waited = run(['docker', 'wait', container], 'wait', 10)
    assert waited['stdout'].strip() == str(expected)
    summary['wait_process_exit'] = int(waited['stdout'].strip())
except BaseException as e:
    failure = repr(e)
finally:
    cleanup = []
    for active, name, volume_mode in [(created, container, False), (volume_created, volume, True)]:
        if not active:
            continue
        inspect_args = ['docker', 'volume', 'inspect', name] if volume_mode else ['docker', 'inspect', name]
        record = run(inspect_args, 'cleanup-inspect-'+('volume' if volume_mode else 'container'), 10, False)
        if record['exit'] != 0:
            cleanup.append({'name': name, 'removed': False, 'reason': 'inspect failed'})
            continue
        try:
            data = json.loads(record['stdout'])[0]
            assert labels_match(data, volume_mode)
            args = ['docker', 'volume', 'rm', name] if volume_mode else ['docker', 'rm', '-f', name]
            removed = run(args, 'cleanup-rm-'+('volume' if volume_mode else 'container'), 10, False)
            cleanup.append({'name': name, 'removed': removed['exit'] == 0, 'exit': removed['exit']})
        except BaseException as e:
            cleanup.append({'name': name, 'removed': False, 'reason': repr(e)})
    inventories = {}
    for kind, args in [('container', ['docker', 'ps', '-aq']), ('volume', ['docker', 'volume', 'ls', '-q']), ('network', ['docker', 'network', 'ls', '-q'])]:
        r = run(args+['--filter', 'label=sandbox.test.project='+project], 'inventory-'+kind, 10, False)
        inventories[kind] = {'exit': r['exit'], 'remaining': r['stdout'].strip()}
    summary.update(failure=failure, cleanup=cleanup, inventories=inventories)
    clean = all(r['removed'] for r in cleanup) and all(r['exit']==0 and not r['remaining'] for r in inventories.values())
    summary['cleanup_verified'] = clean
    (out/'result.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps({'evidence': str(out), 'observed_exit': summary.get('attach_exit'), 'failure': failure, 'cleanup_verified': clean}), flush=True)
    sys.exit(0 if failure is None and clean else 1)
