from pathlib import Path
import hashlib,json,tarfile,io,re
w=Path('.superpowers/sdd/2026-10-07-monitor-confinement-drain')
d=Path('docs/superpowers/plans');stem='2026-10-07-monitor-confinement-drain'
sha=lambda b:hashlib.sha256(b).hexdigest()
ledger=(w/'progress.md').read_text()
rulings=[l for l in ledger.splitlines() if 'Ruling:' in l]
assert len(rulings)==12
parts=['# Monitor confinement and descendant drain — permanent final review\n\nThis prerequisite unit is independently approved; the native etcd migration phases1–5 remain unfinished. Source range7b432c9..bdfc15f. No push, merge or deployment.\n\n## Rulings I made\n\n'+'\n\n'.join(rulings)+'\n']
for title,name in [('Full final independent review','final-review.md'),('Full Task1 independent review','task-1-review.md'),('Full Task1 scoped M1 re-review','task-1-rereview-1.md'),('Full Task2 independent review','task-2-review.md'),('Full controller dispositions and ledger','progress.md')]:
 parts.append('\n\n## '+title+'\n\n'+(w/name).read_text())
(d/(stem+'-final-review.md')).write_text(''.join(parts))
(d/(stem+'-next-target-notes.md')).write_text((w/'next-target-integration-notes.md').read_text())
files=[];excluded=[]
for p in sorted(w.rglob('*')):
 if p.is_symlink(): raise RuntimeError('unexpected symlink:'+str(p))
 if not p.is_file(): continue
 data=p.read_bytes()
 if p.name.endswith('.test') or data[:4] in [b'\x7fELF',b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'\xce\xfa\xed\xfe',b'\xfe\xed\xfa\xce',b'\xca\xfe\xba\xbe']:
  excluded.append({'path':str(p.relative_to(w)),'bytes':len(data),'sha256':sha(data)});continue
 files.append((p.relative_to(w).as_posix(),data))
manifest={'version':1,'owned_workspace':str(w),'source_range':'7b432c9..bdfc15f','compiled_files_excluded':excluded,'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in files]}
mb=(json.dumps(manifest,indent=2)+'\n').encode()
archive=d/(stem+'-evidence.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for n,b in files+[('archive-manifest.json',mb)]:
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o600;t.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:
 entries=t.getmembers(); assert len(entries)==len(files)+1
 observed={m.name:t.extractfile(m).read() for m in entries if m.isfile()}
 assert len(observed)==len(entries)
 for row in manifest['files']: assert sha(observed[row['path']])==row['sha256'],row['path']
 assert observed['archive-manifest.json']==mb
archive_sha=sha(archive.read_bytes())
ver=['# Monitor confinement and descendant drain — verification and retained evidence\n\nScope: prerequisite local component only, not complete migration or production permission. Final reviewer C0/I0/M0, exact final source manifest28files independently checked. Current canonical1502PASS/0FAIL/0SKIP includes old tests; actual Linux arm64 only. Darwin host race is not Linux race. Original Task1 host/static raw transcripts are unavailable independently; earlier controller tool-output attestation and full worker report remain, and later evidence does not reconstruct them.\n\nArchive: `'+archive.name+'`; SHA256 `'+archive_sha+'`. '+str(len(files)+1)+' regular members; '+str(len(excluded))+' compiled binaries excluded, their exact digests retained. All archived regular files independently read and SHA256-compared to the manifest after tar creation, zero mismatches. Exact Task1 thirteen containers/thirteen volumes plus Task2 fourteen/fourteen:54 owned removals0, all own inventories empty as recorded; no global cleanup.\n\nAll original REDs, compile-only failures, controlled omissions, raw commands/outcomes/labels/cleanup and full reports remain in the archive. Controlled REDs occurred after implementation where explicitly labeled. Fixture64MiB/128pids/0.5CPU success is not production minimum quota, fleet RSS or performance proof. No old etcd suite or uncached whole-repository census was regenerated.\n']
for title,name in [('Full Task1 worker report','task-1-report.md'),('Full Task2 worker report','task-2-report.md')]:ver.append('\n## '+title+'\n\n'+(w/name).read_text())
for p in sorted(w.glob('task-*-root-*-proof.json')):ver.append('\n## Root proof '+p.name+'\n\n```json\n'+p.read_text()+'```\n')
for p in sorted(w.glob('*.json')):
 if '-proof.json' in p.name or p.name.endswith('-freeze.json'):continue
 ver.append('\n## Complete persisted command record '+p.name+'\n\n```json\n'+p.read_text()+'```\n')
ver.append('\n## Archive complete manifest\n\n```json\n'+mb.decode()+'```\n')
(d/(stem+'-verification.md')).write_text(''.join(ver))
print(json.dumps({'archive':str(archive),'sha256':archive_sha,'members':len(files)+1,'excluded_binaries':len(excluded),'final_review_bytes':(d/(stem+'-final-review.md')).stat().st_size,'verification_bytes':(d/(stem+'-verification.md')).stat().st_size},indent=2))
