# Task 2 implementation report — DONE

BASE 4bc0b9c96f5ad1de3fbed38858be030801249079; controller docs-only Ruling9 b2de06f is retained. Implementation and required verification are complete in ea80c2c and35f1bc9. Earlier progress/pending entries below are historical; the final canonical section at EOF records their completion. Independent review belongs to Root. All fixture ownership belongs to Root. No nested agents, production raw-start API, new dependencies, privilege or quota expansion, image/config/Manager/Redis/FUSE edits, push/merge/deploy, unrelated Sentinel reads or sibling scratch access.

## Progress and evidence

The new synchronous Drain uses constructor self seal and nonblocking shared mutex, context budget validation, poison-on-operational-failure, real wait4(-1,WNOHANG|__WALL), bounded statuses, pinned proc-directory child inspection and pidfd_send_signal, and final ECHILD + actual validation + live context. The parser intentionally accepts zombie Threads:0. A per-call private three-function seam covers state-machine fault cases; production binds actual operations only. Temporary close errors take precedence over vanished-child observations, preventing ENOENT from hiding cleanup uncertainty.

- Initial host compile RED: task-2-red-host.json; go test ./internal/runtime/launcher -run TestMonitorDrainContext -count=1, exit1 undefined validateDrainContext.
- Initial Linux compile RED: task-2-red-linux.json; env CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go test -c -o own/task-2-red.test ./internal/runtime/launcher, exit1 missing new API/parser/state-machine symbols. These are compile-only evidence, not behavioral RED.
- Controlled omission behavioral RED: after implementation existed, only checkDrainChild identity/capability/NNP/seccomp condition was disabled; original bytes task-2-process-before-red.go; exact freeze task-2-red-freeze.json. Root ran selector ^TestMonitorDrainStatus$, expected and actual process1. Raw own/task-2-seal-red/commands.json and attach.stdout/stderr, result.json; independent root proof task-2-root-seal-red-proof.json. 52PASS/1FAIL/0SKIP; seven malformed-seal acceptances. Binary 8df073777ecc99ce7cb2efa2a63db5da502abbdbd719737322ff8be347eba66c. Attach1/wait command0/value1, exited/Running=false/OOMKilled=false; exact container+volume removals0; three own inventories0/empty. This is synthetic parser/guard behavior executed on Linux, not real child drain proof. Original guard restored after Root handback.
- Host GREEN task-2-green-host.json, host race task-2-race-host.json, host vet task-2-vet-host.json; all exit0. Linux arm64/amd64 compile task-2-static-{arm64,amd64}.json and vet task-2-vet-{arm64,amd64}.json all exit0. Each raw JSON preserves argv, environment, HEAD, all launcher source hashes, full stdout/stderr and exit. Native platform execution still belongs to Root.
- Post self-review close-error fix compile0 task-2-green-static.json and complete freeze task-2-green-freeze.json; focused Linux GREEN requested from Root.

## Inherited CannotVerify and unforced limitations ledger

All Task1 original review and scoped M1 re-review limitations remain; M1 itself is fixed and approved. Historical Task1 host/static raw transcripts were unavailable independently (Root attested original tool outputs); Task2 retains complete raw transcripts. Future production caller sole spawn/wait ownership, completed single spawn, no new trusted spawn, management/resource FD closure and stable topology are not certified by this local component. Future target integration must review them explicitly.

Darwin host race is not native Linux race. Native arm64 and amd64 static/interpreter evidence remain distinct. Foreign/manual/CGO thread support, full ABI/x32/LSM/kernel/platform matrix, missing Linux5.9 fields/strict mode actual runtime, forced seccomp later-thread divergence, exact vanished-thread retry interleavings/exhaustion, real 4096 thread/filter/process resource stress, cgroup-v1 breadth, external mount/cgroup mutation, arbitrary kernel IO/STW preemption, force PID-number reuse, crash recovery, fleet/production quota cost, authenticated target/journal admission, business End and remote-write settlement remain unforced or downstream as applicable. Filter counts remain diagnostics; per-thread installation does not promise later TSYNC compatibility. Synthetic limits and private-fault state-machine tests must never be relabeled actual kernel exhaustion.

## Native helper semantic boundary (pending Root ruling)

Official Linux v6.12 kernel/fork.c lines2352–2363 sets CLONE_PARENT exit_signal from the current leader; kernel/exit.c reparent_leader lines626–640 normalizes adopted children to SIGCHLD; eligible_child lines1045–1068 describes __WALL clone coverage. URLs: https://raw.githubusercontent.com/torvalds/linux/v6.12/kernel/fork.c and https://raw.githubusercontent.com/torvalds/linux/v6.12/kernel/exit.c. A helper may prove non-SIGCHLD before adoption with ordinary waitid ECHILD versus non-consuming __WALL nil and parent-independent proc/stat exit_signal0. Drain's eventual adoption/reaping does not establish an omission-__WALL native counterexample because adoption normalizes signal. No extra raw clone monitor bridge is planned.

Initial focused GREEN (Root): ^TestMonitorDrain, raw task-2-loop-green/, root task-2-root-loop-green-proof.json, 67PASS/0FAIL/0SKIP, attach/process0 and wait0/value0, noOOM, exact2removals0 and3queries0/empty. This covers executed Linux parser and fault state machine only. Fresh precommit host race/vet and both native architecture vet plus amd64 compile all exit0 in task-2-precommit-*.json; native arm64 compile matched GREEN.

Self-review then caught a spec precision issue: unrelated proc entries were having every policy field parsed before PPid selection. The correction adds identityOnly path for the initial same-FD status read and parses the full policy only after PPid==monitor. A regression accepts unrelated malformed caps for identity-only selection while full direct-child parsing rejects it. Missing-helper compile RED task-2-identity-red.json, compile GREEN task-2-identity-green-compile.json; root requested one changed-risk ^TestMonitorDrain GREEN against task-2-identity-freeze.json before immediate implementation commit.

## Coherent implementation committed

Commit ea80c2c `feat(launcher): drain pinned monitor children to actual ECHILD` contains seven files/657 inserted lines (implementation and focused tests). Root current-identity GREEN was 68PASS/0FAIL/0SKIP, binary 28cda2… retained in task-2-identity-green/result.json, root proof task-2-root-identity-green-proof.json; all23 Go hashes match. Final implementation Linux amd64 compile and arm64/amd64 vet are fresh exit0 task-2-final-impl-*.json. Previous fresh Darwin race/vet covers the unchanged common/unsupported files; final identity selection changes only the Linux parser. Complete staged diff/self-review and diff --cached --check passed before this promptly created commit. The native adversary suite was added only afterwards for a separate commit.

## Native tests and helper preparation

R10/R11/R12 clarifications from controller commit276cc07 have been read; native proof distinguishes pre-adoption clone type, and unexpected residual users fail even when test-only fallback cleans them. The monitor owns no Cmd.Wait for its user: native starts with actual os.File streams and Release closes only the Go process FD. A separate Cmd.Wait owner in PID1 manages only each management monitor. Fallback waits for every registered monitor to stop/join before PID1 waits adopted users. Poisoned-monitor cleanup uses a fresh bounded test-only loop, preserves poison and reports diagnostics, never successful Drain.

Helper fixed source is internal/runtime/launcher/testdata/drainclone/{main.go,clone_linux_amd64.s,clone_linux_arm64.s}. Build CGO_ENABLED=0 GOOS=linux GOARCH=$arch go build -o $evidence/drainclone ./internal/runtime/launcher/testdata/drainclone; readonly /drainclone mount, argv clone-zero or clone-parent. No arbitrary clone flags or production helper. Parent assembly masks all catchable signals before clone and attempts old-mask restoration on every parent/error return path; child only raw ppoll loop, never RET/CALL/Go. Mask-restoration failure is unforced availability/error behavior, not a guarantee of restoration against denied syscalls. Root reviewed all source and current x/sys syscall tables. Runtime source evidence: Go1.25.6 runtime/preempt.go:347–438 rejects FuncFlagAsm/missing locals maps at407–418 and unsafe NOSPLIT points at399–406, so this assembly PC is not async-preempted. This is source reasoning, not dynamic full ABI/handler proof; only arm64 native execution is planned. Both architectures helper build0, launcher/helper vet0 retained in task-2-helper-*.json/task-2-native-vet-*.json.

Canonical changes only fixed current-toolchain helper build, readonly mount, full main/helper Go+assembly hashes, both binary hashes and required positive marker; original I1 attach→actual terminal→wait/client join and caps/64MiB/128pids/0.5CPU/GOMAXPROCS2 unchanged. bash -n passed. No test binary is tracked.

Actual descendant controlled RED pending Root: selector ^TestMonitorDrainNativeAdversaries$/^double$, expectedprocess1, sourcefreeze task-2-descendant-red-freeze.json including all helper assembly and canonical script; arm64 compile0 task-2-descendant-red-compile.json. Production public Drain scan temporarily no-op while test-only diagnostic cleanup remains real. Saved original task-2-drain-before-native-red.go. Expect live setsid descendant after root exit, timeout+poison, then real sole-owner diagnostic cleanup; this tests omission of actual drain work rather than conflating root exit with terminal. No source edits during Root freeze.

Root descendant RED raw received (waiting explicit unfreeze): own/task-2-descendant-red/ full stdout/result inspected. Actual kernel uname decodes Linux7.0.12-linuxkit/aarch64. PID1 read root23 Z/PPid17/session1 plus live leaf33 S/PPid17/session28, all UID/GID1000/fivecaps0/NNP1/Seccomp2/filters2/exact0::/ cgroup. With public scan omitted, real Drain returned deadline exceeded after2s and poison stayedtrue; same-owner diagnostic cleanup reaped leaf33 rawstatus9, management monitor exit1 joined, PID1 fallback reaped0/errnil. Actual attach/process1/waitcmd0/value1/exited/noOOM; 0PASS/2FAIL/0SKIP (top and double subtest); exact two removals0 and own three inventories0/empty. Main binary96d89a0b390cb4bf4a1daa7c1ebd06ba200c3ba344586723f4f608e303019424; helper92d9ded2ad841ecfe5c043c74b5ebfb5771aa7ea604b04200198e046088cd68a. Helper was built/mounted but not executed by double selector, so this RED is no assembly runtime claim. A misleading unconditional top-level success-marker log appears after subtest failure; queued test-only fix will guard marker on !t.Failed without changing the actual RED exit/outcome. Current RED is preserved, not relabeled success.


## Verified native test commit and final repository checks

Commit35f1bc9 `test(launcher): verify native descendant drain and pinned process identity` (7 files,758 insertions/2 deletions) is separate from implementation ea80c2c. The complete fixed-mode source/helper/harness was self-reviewed for one spawn and sole Wait4 ownership, immediate registered error cleanup, no child Go continuation, actual-proc parent oracles, no SIGSTOP/group kill assumption, copied raw exit observations, repeated fresh Drain, no extra product API and unchanged quotas/lifecycle. No production code diff remained before this commit. Staged diff --check0. The native test file is602lines of fixed-mode/adversary/evidence/cleanup code; this is a maintenance size concern, not an expanded product abstraction. No known implementation correctness issue remains; independent review is Root-owned and still pending.

Final-source repository checks were each run exactly once, with full argv/environment/HEAD/source/stdout/stderr/exit persisted by task-2-run.py:

| Exact command | Raw record | Exit |
|---|---|---|
| `go test ./...` | task-2-final-repo-test.json | 0 |
| `go vet ./...` | task-2-final-repo-vet.json | 0 |
| `go build ./...` | task-2-final-repo-build.json | 0 |
| `env CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go test -c -o .superpowers/sdd/2026-10-07-monitor-confinement-drain/task-2-final-amd64.test ./internal/runtime/launcher` | task-2-final-native-amd64-compile.json | 0 |
| `env CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go vet ./internal/runtime/launcher ./internal/runtime/launcher/testdata/drainclone` | task-2-final-native-amd64-vet.json | 0 |
| `env CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go test -c -o .superpowers/sdd/2026-10-07-monitor-confinement-drain/task-2-native-green.test ./internal/runtime/launcher` | task-2-native-green-compile.json | 0 |
| `env CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go vet ./internal/runtime/launcher ./internal/runtime/launcher/testdata/drainclone` | task-2-native-green-vet.json | 0 |
| `bash -n scripts/test-launcher-kernel.sh` | task-2-native-script-syntax.json | 0 |

Repository go test output is nonverbose and includes cached packages and packages without tests. It is not evidence of a new etcd/FUSE/Redis fixture or expanded native platform/race coverage. No new etcd fixture was requested or created. Native helper Go+assembly is under testdata and therefore its explicit two-architecture build/vet records are retained separately from go test ./... . The host race records remain Darwin; no Linux race claim.

## Focused actual native GREEN details

Root ran `python3 .superpowers/sdd/2026-10-07-monitor-confinement-drain/root-focused-native.py .superpowers/sdd/2026-10-07-monitor-confinement-drain/task-2-native-green '^TestMonitorDrain' 0` (actual expanded command argv in commands.json). Raw460lines attach.stdout read through EOF, stderr empty; result.json and independent Root+implementer proofs read/created. 81PASS/0FAIL/0SKIP includes68 focused contract/parser/state-machine entries and13 native parent/subtest entries, not81 distinct adversaries. Actual attach/process0, docker wait command0/value0, exited/Running=false/OOMKilled=false. Kernel7.0.12-linuxkit/aarch64, CGO0. Twelve extra real wait4(-1,WNOHANG|__WALL) calls after successful Drain returned ECHILD; repeated Drain also succeeded freshly. PID1 verifies actual proc identities and absence, while only the live monitor can observe its own actual user Wait4 statuses. PID1 never competes for a live monitor's user wait.

Every parent proc observation below checks all four UID/GID values1000, fivecapsets0, NNP1, Seccomp2/count2 and exact cgroup `0::/\n`; management monitor all-thread observations are root/P-E e0/I-A-B0/NNP1/count2. The table reports real observations, not only success markers:

| Case | Actual parent-independent state and result |
|---|---|
| double fork/setsid | Root23 was Z/PPid17/session1 while leaf33 was live S/PPid17/session28. Drain reaped23 raw0 and33 raw9; both absent, monitor17 joined0. The intermediate28 was already waited by user root. |
| user subreaper | Root43 live/PPid37; leaf53 live/PPid43/session48 after intermediate48 exited and was waited. Monitor37 later reaped43 and53 raw9 after killing/adoption. |
| CLONE_PARENT | Helper63 and raw clone70 both live direct children of monitor57, exit_signal17. Both reaped raw9; assembly executed on arm64. |
| non-SIGCHLD | Helper78 live undermonitor72; raw child85 live/PPid78/exit_signal0. Helper waitid without WALL returned ECHILD; with WALL returned nil/signo0 using WNOWAIT both times. Monitor72 later reaped78+85 raw9. This proves pre-adoption clone type and later actual termination; it does not claim native omitted-WALL failure after signal normalization on adoption. |
| bounded repeated forks | Parent saw root93 plus leaves98,102,106 over successive proc snapshots; all4 reaped raw9. User loop permits at most6 forks and was killed after3 in this run, not claimed6 completed. No128-task stress/exhaustion claim. |
| sibling SIGCONT | Root117, leaf122 and sender123 were live with sender/leaf siblings. Sender's actual successful SIGCONT to122 was logged; all3 reaped raw9. No stopped-snapshot assumption. |
| zombie | Root136 already Z under130; Drain reaped raw0 and obtained ECHILD without needing a positive Threads assumption. Synthetic parser separately accepts Threads0. |
| natural no children | Root147 Z, then same sole monitor140 performed natural Wait4 raw0 before Drain. Drain returned empty Reaped and real ECHILD; one spawn still completed. |
| cancellation | Monitor151 and live user158; private validate wrapper canceled the real deadline context after actual current-boundary validation. Returned context.Canceled/zero observation, poison retained, child still alive after30ms and no new goroutine, retry refused. Fresh diagnostic same-owner cleanup reaped158 raw9 with poison stilltrue; this was not successful Drain. |
| same-UID concurrent monitors | Monitor162/user168 and monitor172/user178 both existed. Draining A reaped168 raw9; B178 remained S with identical start37923360. Old held procFD168 signal returned ESRCH, B still alive; B then drained normally. |
| fresh process after old exit | A183/user189 was drained/reaped before B193 spawned199. Old held procFD189 SIGKILL returned ESRCH while fresh199 stayedS/start37923366; B then drained. PID-number reuse was not forced, so no numeric-reuse workload claim. |

All13 registered management monitors were actually joined successfully. All11 PID1 per-subcase fallback invocations observed reaped0/errnil. Ordinary monitor diagnostic cleanup observed0; the intentionally canceled monitor observed1/raw9 with poison retained. Unexpected residual users would fail the test even if fallback cleaned them; no such residual occurred. The preserved controlled scan-omission RED separately exercises operational timeout and diagnostic cleanup after failure, not a passing workload.

Focused binaries: main `72e61d2a2b5a36ed98b947542f2bbabf9b22be07afe4a001d3361967e2d640fd`; helper `92d9ded2ad841ecfe5c043c74b5ebfb5771aa7ea604b04200198e046088cd68a`. Fixed `/drainclone` mount readonly recorded. Root independently checked caps dropALL+KILL/SETGID/SETUID/SETPCAP, privatePID/netnone/root/NNP, read-only rootfs and both binaries, memory67108864/pids128/NanoCpus500000000/GOMAXPROCS2. These are actual configured fixture quotas plus noOOM observation, not production idle/active memory benchmarks. Exact owned container+volume removed exit0; three own-label inventories returned0/empty.

Full final source manifest (unchanged after focused GREEN; canonical pending):

```text
c8e4cd60faa17fc767ba185a2226f387f45ab4b9deda531cc9abd8ca2fe89bd8  internal/runtime/launcher/kernel_cleanup_native_test.go
52f246320e7b62f55e3de224492325504dd6fd1f30ae508ab3aad65527238c70  internal/runtime/launcher/kernel_inspect_linux.go
b29f493863845ac1f9fbed7ea1db319f4f43bd10bb1d28acca0095564036812a  internal/runtime/launcher/kernel_linux.go
9c21992562b4f17e86eb92209c659d487a4e323dbf7834c4ae97cb348d844742  internal/runtime/launcher/kernel_models_test.go
6f5cbcbb9432f7877ac1312f35e8d396d04eb856513ec3349a5a12e0247d3c21  internal/runtime/launcher/kernel_mutate_linux.go
1120e471fed8c898f3c8c960f985fce0f9c9fada08ce052adc7366ac2949315c  internal/runtime/launcher/kernel_native_test.go
583d315d1f6143bf37ff7df8cf0ab79c297dd946f2a6f892cfa86d46be25d3e3  internal/runtime/launcher/kernel_types.go
d8c4a7bc67e6ab93a7f42c9e882121c2d3ffc5155ec2ce291a323cc6307bb0e5  internal/runtime/launcher/kernel_unsupported.go
66673c0c83ddac59b817946fc90531ba8cf490ce9a27207607ee00e11b770769  internal/runtime/launcher/kernel_unsupported_test.go
036838af46c79654dc9846c576d2fc0b4bfe1ebc9a027f2b0d162151efa83831  internal/runtime/launcher/kernel_user_native_test.go
5e99293509d980ca1d3867ba0018dfb2968cb53603f602cce434a10bb6770f8d  internal/runtime/launcher/monitor_drain_linux.go
bb0f1e07833b9026792699c8c73d7e054c0c718fe1cf3be7d0f12cbeb91fbe60  internal/runtime/launcher/monitor_drain_linux_test.go
f4a1651c432dda53aa358058e2c64c36465f072bc2ccac3282c38f9bc4c90b4e  internal/runtime/launcher/monitor_drain_native_test.go
b5bdc4a5180cef6d81090c00c09327e5c534152899a4f51520be340805888850  internal/runtime/launcher/monitor_drain_test.go
960df6c8874a0dbcfeec4b93f690eb00662a8ccff69f893f7c5c8d1ce56bbf0f  internal/runtime/launcher/monitor_inspect_linux.go
9b5f883b9a50946e2a57f51c3181d7d03ddeeedd229710dfad05bea110b3c634  internal/runtime/launcher/monitor_linux.go
3d5283e926e43ab80bd82b17653fb89f90e6ed719a7c89a76a1434274d475d99  internal/runtime/launcher/monitor_linux_test.go
ccba4cd8f35194ed38082a4f70b9aa5c0525ca27990fa6efcf4522aec2cda83e  internal/runtime/launcher/monitor_models_test.go
e3b381b173d19610da3da8a36b8ff3447ca8cdd51578f73981f97f137ab1ee6b  internal/runtime/launcher/monitor_native_test.go
b36066b497f0b78b7887e75560dfd035232bbfbbea44765b4d4d90697b471676  internal/runtime/launcher/monitor_process_linux.go
abd7375dce0901c5f81686d3410325a25ae0b5fc3113b6d37b768ed67d750226  internal/runtime/launcher/monitor_seccomp_linux.go
b30cbb6d42b317aaec79db30f6323af48282fb1894eca15ed60831a8ed269c16  internal/runtime/launcher/monitor_types.go
9fcb0cc8eb71034b755fc72f4ecf978113c4a7db2bafacf4f3663db632090698  internal/runtime/launcher/monitor_unsupported.go
68e01230a939c99c5dbfafb072f3c45451cb7fb8e10747eb24bbb9c7e9284f43  internal/runtime/launcher/monitor_unsupported_test.go
3f1e9840ac659b548723e4d431410e5068bdec51dcfcf9ee2b766c08d0137aed  internal/runtime/launcher/testdata/drainclone/clone_linux_amd64.s
7468e6d3fb419ff130d7cb1d43f778d51b328478fe48d4f5663e13a20e5d9bad  internal/runtime/launcher/testdata/drainclone/clone_linux_arm64.s
340f4dfe1ff6fdf217e7cc533c2f2f77e9d4a2d53464a85a4b563faac479328c  internal/runtime/launcher/testdata/drainclone/main.go
03716ede1b3224895d8a82aca9da4deb395c08d30259424fe871c992b13440a0  scripts/test-launcher-kernel.sh
```

Root canonical once is pending on the frozen35f1bc9 byte set; no Go/assembly/script edits planned. Independent Task2 review and final integration gate belong to Root.

Final repository command identity clarification: repository test/vet/build were launched before the native test commit while HEAD was `ea80c2c26cd07b4d9d29c2129295a4900e71d857`; their persisted source maps include the then-uncommitted final native tests/helper sources. Those exact bytes became35f1bc9 unchanged and match the28-file final freeze (launcher/helper plus script; per-command runner captures launcher/helper tree). The HEAD-only value must not be mistaken for the earlier implementation-only test set. No second full repository run was made after commit because only commit metadata changed. Canonical runs at35f1bc9 with the same source bytes.


## Final canonical verification — complete

Exact controller command, run once after final Go/assembly/script freeze:

```sh
bash scripts/test-launcher-kernel.sh /Users/dysodeng/project/go/cloud/sandbox/.superpowers/sdd/2026-10-07-monitor-confinement-drain/task-2-native-canonical
```

Controller full stdout/stderr/argv/start/end/exit are task-2-canonical-controller.{stdout,stderr,json}; script exit0. Evidence directory contains original nine mode logs, create/exit inspections, result files, source-commit/diff/SHA, both binaries+SHA and cleanup.log. Root independent full proof is task-2-root-canonical-proof.json; implementer independently verified all28 source digests and both binary digests in task-2-implementer-canonical-proof.json, read full new drain raw block positive.log:2972–3297, all nine result records and entire cleanup log. Root additionally read all negative raw logs through EOF and audited all creation parameters/terminal/wait outcomes/labels and inventories. No further suite run or source change followed.

Positive actual1502PASS/0FAIL/0SKIP (includes inherited predecessor/Task1 cases, not1502 new cases). Every mode exited and Running=false/OOMKilled=false. Attach/process and wait-command/value: positive0/0→0/0; reject-nnp0/0→0/0; reject-missing-cap0/0→0/0; reject-extra-cap0/0→0/0; reject-role0/0→0/0; reject-thread0/0→0/0; reject-securebits2/2→0/2 (expected preexisting runtime fatal); reject-setter0/0→0/0; reject-partial0/0→0/0. Expected fatal-helper text nested in inherited positive tests is not an unreported suite failure; counted terminal test records are allPASS.

Final source revision35f1bc9e85b774f52cdf132ef8236106875d3554; all28 current source entries exactly match the manifest above and canonical/source-sha256.txt. Main test binary SHA256 remains72e61d2a2b5a36ed98b947542f2bbabf9b22be07afe4a001d3361967e2d640fd. Canonical helper SHA256 is2d17cd27a1522a0933d891078aec51bd47912170441ee3ebecd52a710c7a6f81, distinct from focused helper92d9ded2…. `go version -m` raw output in task-2-helper-build-metadata.json proves both Go1.25.6/CGO0/linux/arm64 and the change in embedded VCS revision/time/module pseudo-version ea80c2c→35f1bc9, both dirty due the preexisting unrelated tracked edit. Helper source/assembly bytes remained identical; the two native runs are never relabeled as using the same helper binary. No unrelated file content was read to establish dirty metadata.

Canonical actual descendant evidence agrees with the earlier focused table on new PIDs: double monitor73 root79Z/session1 + leaf89live/session84 → raw0/9; user-subreaper monitor93 root99+leaf109(PPid99) →9/9; CLONE_PARENT119+126 bothPPid113/exit_signal17 →9/9; clone-zero133+140 with childPPid133/exit_signal0, waitid contrast ECHILD vsWALL nil/signo0 →both9 under127. Repeated fork147+152+156+160 →four9 (three completed forks observed; bound6). SIGCONT sender177 successfully signaled sibling176; root171+bothchildren →9. Zombie190→0; natural200 explicitly waited0 before empty Drain. Cancel user210 remained live through controlled cancellation then diagnostic wait9, poisontrue. Concurrent A220/B231 retained B start37940648 while oldFD220 returnedESRCH; fresh case A242 reaped before B252 spawn, oldFD242 ESRCH and B start37940653 survived. Both B children then drained9. Twelve additional real ECHILD oracles,13 management joins0 and all11 PID1 fallbacks0/errnil are recorded again. This still does not force PID-number reuse or post-adoption omitted-WALL failure.

Owned canonical project sandbox-launcher-kernel-test-7696-1791332997: nine exact containers and nine exact volumes removed exit0, three own-label inventories successful/empty. Fixed positive fixture remains privatePID/netnone/root/NNP/read-only binaries+rootfs/dropALL+KILL/SETGID/SETUID/SETPCAP/64MiB/128pids/0.5CPU/GOMAXPROCS2; inherited negative fixtures keep their deliberate original cap/NNP mismatches. No quota change or production overhead benchmark. Across Task2's five focused fixtures plus canonical,28 exact resource removals succeeded (14containers+14volumes), each fixture set had its own empty successful inventory checks. Root reports no active fixture/session, and implementer has no background command left.

Final repository test result was30ok packages,8 no-test packages,25 cached results; all repository test/vet/build commands exit0 as recorded above. Cached/nonverbose output is not new native integration evidence. Independent Task2 review is pending Root dispatch; the original whole-task range remains4bc0b9c..35f1bc9, including Root binding doc amendments b2de06f/276cc07. The actual implementation commits are ea80c2c and35f1bc9.

## Final files, self-review and remaining scope

- monitor_types.go: common deadline prevalidation; existing immutable seal/mutex/poison fields reused.
- monitor_drain_linux.go: synchronous sole-owner bounded state machine, actual Wait4 flags, zero observation/poison and fresh terminal validation.
- monitor_process_linux.go: identity-first/direct-child-only seal inspection, bounded paged proc scan/openat, same pinned FD revalidation/signal, immediate temporary close.
- monitor_drain_test.go and monitor_drain_linux_test.go: budget, ownership, parser, policy mismatch, overflow and operational fault regressions.
- monitor_unsupported.go and monitor_unsupported_test.go: fail-closed Drain API and fixed native dispatcher stubs on unsupported platforms.
- monitor_drain_native_test.go and kernel_native_test.go: fixed test-only modes, thirteen native test entries, independent proc/status/Wait4 assertions, cancellation and registered sole-owner cleanup.
- testdata/drainclone/main.go and clone_linux_{amd64,arm64}.s: current-toolchain standalone fixed clone adversary with child-only masked raw syscalls.
- scripts/test-launcher-kernel.sh: fixed helper build/mount/hash proof and required positive marker; retained I1 lifecycle/negative modes/quotas.

Self-review corrected close-error precedence, identity-only unrelated selection, test oracle page bounds, and misleading failed-subtest success marker before final green/commit. Native helper signal/ABI/runtime assumptions and kernel adoption signal semantics were escalated to Root before execution and resolved in binding rulings rather than guessed. Final implementation has no known unfixed finding. Synthetic faults, parser limits and source reasoning remain labeled distinctly from real Linuxarm64 observations. Actual forced resource exhaustion, arbitrary hung kernelIO, parent-mask-restore denial, numeric PID reuse, full kernel/ABI/LSM/nativeamd64/Linux-race breadth and inherited Task1 limits remain unforced. No production PID1 escalation, target transport/start admission, journal End, remote-write settlement, Manager/Redis/FUSE migration or fleet-cost certification is claimed. These remain named later integration work, not a silent reinterpretation of LocalDrainObservation.

Named integration seams for Root review: current KernelBoundary.ValidateCurrent/capability validation is actually consumed by the initial/final monitor checks; passive runtime-journal settlement and authenticated controlprotocol/target start/End remain unchanged and are not called or certified by Drain. Future integration must establish exact user root/FD closure, sole spawn/wait ownership, no-new-spawn and external-write settlement before interpreting any terminal business state.
