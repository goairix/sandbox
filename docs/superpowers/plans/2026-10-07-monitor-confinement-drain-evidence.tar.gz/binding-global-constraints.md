# Verbatim Global Constraints

- Branch `codex/etcd-state-management`; no push/merge/deploy; never touch/stage/read the unrelated tracked `docs/superpowers/plans/2026-09-17-sentinel-kubernetes-129-compatibility.md` edit.
- Work only on this plan's own `.superpowers/sdd/2026-10-07-monitor-confinement-drain/`; never read/write siblings or deleted predecessor scratch.
- `MonitorBoundary` is process-local cleanup evidence, never start permission, journal admission, authenticated target binding, remote-write settlement or business End.
- No production raw-start API, image/config/Manager/Redis/FUSE changes, new dependencies, SYS_ADMIN/SYS_PTRACE, privileged containers, host namespace access or writable delegated cgroups.
- Supported native Linux amd64/arm64, CGO_ENABLED=0 and Go-owned threads; foreign/manual/CGO threads unsupported; required Seccomp_filters field Linux5.9 compatibility floor.
- Sealed UID/GID `1..2147483647`; monitor kernel P/E `0xe0`, I/A/B0, NNP1, securebits0, dumpable0 and subreaper1; all user descendant cap sets0/NNP1; exact same cgroup bytes.
- Classic-BPF architecture guard kills foreign ABI; amd64 x32 bit and numbers512..547 return ENOSYS; clone3 ENOSYS; unshare/setns/ptrace/process_vm_readv/writev and namespace clone flags EACCES; ordinary native clone/thread/fork/exec allowed by this layer.
- Bounded threads/process scans page128/max4096, status64KiB, cgroup4096bytes, mountinfo1MiB/max4096lines/max16KiBline; max3 vanished-thread retries; no per-idle goroutine/timer/RPC/Lease.
- One command/monitor, no unrelated children, exactly one fork/wait owner; user spawn completed and no new trusted spawn before drain; no os.Process.Wait competing with monitor Wait4.
- Drain uses pinned proc directories and pidfd_send_signal only; no integer-PID/group kill, no stopped snapshot or root-exit-only terminal; final actual wait4 __WALL ECHILD plus current boundary validation and live context.
- Native image `gcr.io/etcd-development/etcd:v3.6.15@sha256:5ed4e32061aa061f970d6500629213e8579ef17571dcf9789074966acb9afad1`, already local, --pull=never; root/privatePID/netnone/RO binary+rootfs/NNP; dropALL addKILL/SETGID/SETUID/SETPCAP; fixture64MiB/128pids/0.5CPU/GOMAXPROCS2. Each run unique project plus fixed fixture labels; exact owned removals and own-label inventories only.
- TDD meaningful counterexamples, preserve actual RED evidence; focused tests while editing; verify and self-review each coherent small commit immediately. Independent reviewers consume original whole-task range; do not relabel host race as native Linux race or repeat unchanged suites without changed risk.

