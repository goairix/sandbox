# Task 1 — monitor confinement 实现报告

状态：DONE。最终实现提交 `2095425`；Task1 所有要求的实现和验证已完成，独立任务审查由 Root 后续执行。

原始 Task1 BASE: `76c0c43`。Root 在实现前以 Ruling8 要求 constructor-only self pointer；已读取更新规范并实施。Task2 Drain 方法未实现，也没有 stub。没有生产启动授权、Manager/image/config/Redis/FUSE 改动，没有新增依赖、push/merge/deploy。未读取、修改或暂存无关 Sentinel 文档。原生 Docker fixture 全部由 Root 启动、等待与清理；实现者未启动 fixture。

## 已交付代码与提交

- `c83c7cb` — `feat(launcher): seal monitor confinement and inherited seccomp policy`：8 个新文件，828 行。`ConfineMonitor`、`ValidateCurrent`、不可复制的本进程句柄和后续 Drain 共享类型；有效 monitor-role 尝试一次即消耗；真实无子进程 waitid preflight；严格 seccomp 状态/count、只读 cgroup 挂载/membership 检查；all-Go-thread prctl 安装固定 BPF，安装后精确 count+1、验证时至少 installed count；unsupported 平台 fail closed；模型、parser、实际 BPF 解释执行测试。
- `75839d5` — `fix(launcher): reject ambiguous mountinfo mandatory fields`：受行为 RED 覆盖的6个 mandatory field 错误输入拒绝；overflow fixture 改为独立ID以确实走到4097行。
- `2095425` — `test(launcher): verify native monitor confinement and rejection paths`：测试和脚本在完整 canonical GREEN 后提交；source字节与实际native二进制记录完全一致。

## TDD 记录与范围

### 初始编译 RED（不是 syscall 行为 RED）

测试先于新增实现写入。`go test ./internal/runtime/launcher` exit1：`undefined: validateMonitorIdentity`、`ConfineMonitor`、`MonitorBoundary`。完整输出 `task-1-red-host.log`。

`env CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go test -c -o .superpowers/sdd/2026-10-07-monitor-confinement-drain/launcher-red.test ./internal/runtime/launcher` exit1：缺失上述接口及 `seccompState`、`parseSeccompStatus`、`monitorInitialization`。完整输出 `task-1-red-linux.log`。这些证明测试先存在、接口缺失，不声称 syscall/可执行断言 RED。

### 受控原生行为反例：故意省略安装

Root 按明确冻结的源码，selector `^TestMonitorNativeConfinement$`，预期进程 exit1 运行。HEAD `c83c7cb97553e64a147215508600b6a77fc5f13f`，唯一故意的产品差异是省略 `installMonitorPolicy` 调用。原文件保存在 `task-1-monitor-linux-before-red.go`。这是提交实现后的 controlled omission counterexample，不是实现之前的原生 syscall 运行。

证据目录 `task-1-native-controlled-red/`：完整命令 `commands.json`、`result.json`、原始 `attach.stdout`/`attach.stderr`、source diff/hash、二进制均保留。

- Root runner exit0 表示观察到了预期失败；实际 attach/process exit1，docker wait 命令0、返回1，容器 exited、Running=false、OOMKilled=false。
- PID1 实测权限480→224；monitor PID17 的7个线程实测 root、P/E224、I/A/B0、NNP1、Seccomp2、filters1。
- 构造函数实际失败：`unsafe launcher kernel state: nonuniform or incompatible seccomp count mode=2 filters=1 required=2 exact=true`。无句柄、没有 user spawn。
- 0PASS/1FAIL/0SKIP。父进程实际 wait monitor exit1 且 joined。
- 1个确切归属容器和1个卷 removal exit0；container/volume/network 三类本标签 inventory 均 query0 且为空，`cleanup_verified=true`。
- 省略版本 `monitor_linux.go` SHA256 `2aed1cf85f8233e473bb0b11631ba1778134dd7e1b55635c3d2ae0a9349417c1`；binary SHA256 `84516b25474fc822e892e1ce6ff58a150b875e68b78367792811c065ff838ed5`。
- Root 交回结果后按字节恢复 installer，原文件 SHA256 `9b5f883b9a50946e2a57f51c3181d7d03ddeeedd229710dfad05bea110b3c634`。

### parser 行为 RED

新增 TestMonitorMountStrictFields 在实际 Linux fixture 运行前已经写入并完成 Linux arm64 compile0。冻结时 parser SHA256 `849f734176c6cfd04af74dc99d0f59b41ee7d4140cd48d52491eea6841fd9977`，test SHA256 `043871994449e3dbaf1657a595b10ecae37e2fc50b5a92e2434e69574ad63506`。Root 已执行 `^TestMonitorMountStrictFields$`，预期并实际进程1。已完整阅读 `task-1-parser-red/attach.stdout`、空 stderr 与 result.json：全部6个 malformed case 实际错误地返回 nil，分别为 missing_mount_access_mode、conflicting_mount_access_mode、raw_NUL、bad_escape、missing_record_newline、trailing_space；包含父测试合计0PASS/7FAIL/0SKIP。docker wait command0/value1，exited/Running=false/OOMKilled=false。两项确切归属 removal0，三类 inventory query0/empty。原始失败证据保留。

Binary SHA256 `8603c0b7217111f4b91aff42b24c6bc4f10716916efde6cd9fb8031c9d5c1e3d`。在 Root 交回之后才实现修正：逐字节拒绝控制字符、严格单空格字段边界/末尾换行、mount root/mountpoint 合法 proc escapes、每条 per-mount ro/rw 恰好一种。合法 escaped path 单测仍要求接受。修正提交 `75839d5`，最终 parser SHA256 `0255d73f610547629567dc02170b50f16e24809fe15201cfcafc2db0320110b1`。修正后的行为 GREEN 已由完整 canonical 测试证明（同一6个子测试全部PASS）；修正后 host test/race/vet、两架构 compile/vet均0。

## 已执行 host/static 检查

在完整 installer 首次实现后，以下实际退出均0：

- `go test ./internal/runtime/launcher`：ok（首次1.179s，后续 cached）。
- `go test -race ./internal/runtime/launcher`：ok（首次1.504s，后续 cached）。这是 Darwin arm64 host race，不是 Linux race。
- `go vet ./internal/runtime/launcher`。
- `env CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go test -c -o .superpowers/sdd/2026-10-07-monitor-confinement-drain/launcher-arm64.test ./internal/runtime/launcher` 与对应 go vet。
- 同上 GOARCH=amd64、输出 launcher-amd64.test，与对应 go vet。
- 额外 `env CGO_ENABLED=0 GOOS=linux GOARCH=386 go test -c -o .superpowers/sdd/2026-10-07-monitor-confinement-drain/launcher-unsupported-386.test ./internal/runtime/launcher` 与对应 go vet均0，覆盖 unsupported Linux architecture 的一致API编译；不声称其动态运行。
- `git diff --cached --check` 在实现提交前0；native 候选 `git diff --check`0。
- `bash -n scripts/test-launcher-kernel.sh`0。
- `bash scripts/test-launcher-kernel.sh` 无参数 exit2，输出 `usage: test-launcher-kernel.sh EVIDENCE_DIRECTORY`，在任何 Docker 操作之前拒绝。Root Ruling7 的 stale evidence default 已删除。

## 自查发现与 source proof

1. 同 PID 复制句柄可复制互斥锁/wait ownership/poison：Root Ruling8 已在实现前添加私有 self seal，方法先检查 receiver；portable 模型与 native 实际复制测试覆盖。
2. Go1.25.6 all-thread 安装的具体保证已读本机源码：`src/syscall/syscall_linux.go:1099..1140` 的 `uintptrescapes`、CGO ENOTSUP、首线程 errno 立即返回；`src/runtime/os_linux.go:727..869` 的 STW、allocmLock、等待线程启动避免双安装、每个 M 执行恰好一次；不同线程结果在后续 runtime 路径 fatal。程序和 BPF backing slice 均 KeepAlive。
3. 测试最初打算在逐线程产品安装之后使用 TSYNC 叠加 allow filter。自查和 Linux seccomp(2) 文档确认分别安装相同 BPF 仍是不同 filter tree，后续 TSYNC 可能失败。实际运行尚未到此路径；在 controlled RED 后将测试额外层改为 all-thread prctl。产品原有 all-thread 安装策略不变。这个兼容性限制需要保留。
4. 原生 namespace legacy clone 探针总额外带 CLONE_THREAD、缺失 CLONE_SIGHAND/VM，即使没有 filter 也必须拒绝，禁止 raw-fork 子进程继续运行 Go。成功的普通 thread/fork/exec 只走 Go runtime/exec。Linux clone(2) EINVAL 条款已核对；BPF interpreter 另行覆盖纯 namespace flags，避免安全保护掩盖策略测试。
5. mountinfo overflow 测试原先重复 mount ID，可能提前命中 duplicate 而未覆盖 line bound；已改为4097个不同ID。自查发现 mandatory field 对 raw control/bad escape/缺失 access mode 的拒绝不够严格；已获得上述实际6-case行为 RED，并在 `75839d5` 修正。

Primary references:
- https://man7.org/linux/man-pages/man2/seccomp.2.html — architecture/precedence/inheritance/TSYNC tree rules。
- https://man7.org/linux/man-pages/man2/clone.2.html — CLONE_THREAD without CLONE_SIGHAND 返回 EINVAL；低位 CSIGNAL 与 flags/clone3 的区别。
- https://man7.org/linux/man-pages/man2/waitpid.2.html — WNOWAIT、WNOHANG 和 __WALL。

## 原生 canonical 验证

Root 执行命令：

```sh
bash scripts/test-launcher-kernel.sh /Users/dysodeng/project/go/cloud/sandbox/.superpowers/sdd/2026-10-07-monitor-confinement-drain/task-1-native-canonical
```

冻结 HEAD `75839d51d0d3767b59b650fd85b27f0e3ec42966` 加 evidence 内完整 `source.diff`，CGO0/linux/arm64，既有 pinned image、原有 caps/64MiB/128pids/0.5CPU/GOMAXPROCS2、private PID/netnone/readonly/NNP 均由原脚本保留。未改 attach-state→wait I1 顺序、client termination/join、exact-label removal/inventory。

已阅读9个 `*-result.txt`、完整新 monitor 原始输出段、所有8个 negative 原始日志、cleanup 与 source/binary hashes。Root 已交回实际 script exit0，并独立核对所有9个create/exited/resource/cap/NNP/label/result状态、18个removal和3个再次独立inventory。完整独立证明为 `task-1-root-canonical-proof.json`，已读取核对。原始数据：

| mode | attach/process exit | wait command/value | state |
|---|---:|---|---|
| positive | 0 | 0 / 0 | exited, Running=false, OOMKilled=false |
| reject-nnp | 0 | 0 / 0 | 同上 |
| reject-missing-cap | 0 | 0 / 0 | 同上 |
| reject-extra-cap | 0 | 0 / 0 | 同上 |
| reject-role | 0 | 0 / 0 | 同上 |
| reject-thread | 0 | 0 / 0 | 同上 |
| reject-securebits | 2 | 0 / 2 | 同上；预期 runtime fatal |
| reject-setter | 0 | 0 / 0 | 同上 |
| reject-partial | 0 | 0 / 0 | 同上 |

Positive `PASS=1417 FAIL=0 SKIP=0`（含旧模型/新子测试，不把这个总数当作1417个新场景）。所有 `TestMonitor*` 及其子测试实际 PASS，包括 parser strictness 的6-case RED→GREEN、实际生成的 amd64/arm64 BPF 解释执行。

### 新增原生数据

- root monitor PID72；父PID1直接读取实际proc。prepared 7线程count1；installed 8线程count2；newthreads 16线程count2，其中8个TID此前不存在。所有观察 UID/GID0、P/E `e0`、I/A/B0、NNP1。sealed UID/GID1000、membership精确 `0::/\n`。
- monitor实际执行 unshare、setns、ptrace、process_vm_readv/writev 共5种，以及8种 namespace legacy-clone flags，共13个 EACCES/errno13；clone3 ENOSYS/errno38。用户子进程另执行同一14个探针，结果完全一致。
- root monitor cgroup write-open `EROFS`；user1000 write-open `EACCES`。打开成功会失败测试而不写入/移动进程。
- all-thread附加allow layer使count3，`ValidateCurrent`允许更强计数而未修复/再安装。user PID89、7个线程直接观察全部四项UID/GID1000、五cap0、NNP1、Seccomp2/count3，cgroup bytes一致；普通user嵌套Go fork/exec exit0。user和monitor wait均nil（exit0），清理均join。
- nil/zero/wrong-role没有消耗正常constructor尝试；prepared monitor真实成功；repeat拒绝；same-PID struct copy被拒绝；持有mutex时的第二方法调用ErrKernelUnavailable。
- 现存live子PID110和waitable zombie子PID120均导致无句柄的ErrUnsafeKernel；前后所有存活线程filters仍1；zombie preflight观测siginfo.Signo17（WNOWAIT不消耗），sole-owner随后真实Wait raw0，两个child joined=true。失败后再调用拒绝为already attempted。
- uid0/gid0/uid2147483648/gid2147483648在各自fresh root monitor拒绝、无句柄，前后count1不变，重试失败。
- nonuniform fixture PID144：TID147 count2，其余5个线程count1；真实preflight拒绝，前后逐线程计数不变。
- failing-installer fixture PID150：5线程baseline count2；真实all-thread PR_SET_SECCOMP得到EPERM，返回ErrKernelUnavailable且errors.Is保留EPERM；无句柄，前后计数仍2，重试失败。
- 旧 reject-securebits真实runtime fatal `AllThreadsSyscall6 results differ between threads`，expected2；这是旧scalar syscall divergence证据，不冒充本次seccomp部分安装的动态证明。旧reject-partial真实保留Inheritable=e0无rollback，预期nil boundary。

### 清理和源码归属

canonical project `sandbox-launcher-kernel-test-94399-1791330228`。`cleanup.log`逐项9个container、9个volume均 `rm exit=0`，三个本project inventory均为空且查询成功。加两个RED runner各自1container+1volume，整个Task1本轮一共22个确切归属removal exit0；每次fixture集合分别有自己的3项inventory，未混合清理外部资源。

Canonical binary SHA256 `61e493071dc15027b412c85bd6be82cd2261a2c240d0b659debe1b24343719f9`。全部source hashes如下（与冻结文件逐一核对；最终提交只记录相同字节）：

```text
c8e4cd60faa17fc767ba185a2226f387f45ab4b9deda531cc9abd8ca2fe89bd8  internal/runtime/launcher/kernel_cleanup_native_test.go
52f246320e7b62f55e3de224492325504dd6fd1f30ae508ab3aad65527238c70  internal/runtime/launcher/kernel_inspect_linux.go
b29f493863845ac1f9fbed7ea1db319f4f43bd10bb1d28acca0095564036812a  internal/runtime/launcher/kernel_linux.go
9c21992562b4f17e86eb92209c659d487a4e323dbf7834c4ae97cb348d844742  internal/runtime/launcher/kernel_models_test.go
6f5cbcbb9432f7877ac1312f35e8d396d04eb856513ec3349a5a12e0247d3c21  internal/runtime/launcher/kernel_mutate_linux.go
af349bc56bb9dacc05f3394e80aa11021ba4c51e509e70a5bc55d514f312d554  internal/runtime/launcher/kernel_native_test.go
583d315d1f6143bf37ff7df8cf0ab79c297dd946f2a6f892cfa86d46be25d3e3  internal/runtime/launcher/kernel_types.go
d8c4a7bc67e6ab93a7f42c9e882121c2d3ffc5155ec2ce291a323cc6307bb0e5  internal/runtime/launcher/kernel_unsupported.go
66673c0c83ddac59b817946fc90531ba8cf490ce9a27207607ee00e11b770769  internal/runtime/launcher/kernel_unsupported_test.go
036838af46c79654dc9846c576d2fc0b4bfe1ebc9a027f2b0d162151efa83831  internal/runtime/launcher/kernel_user_native_test.go
0255d73f610547629567dc02170b50f16e24809fe15201cfcafc2db0320110b1  internal/runtime/launcher/monitor_inspect_linux.go
9b5f883b9a50946e2a57f51c3181d7d03ddeeedd229710dfad05bea110b3c634  internal/runtime/launcher/monitor_linux.go
043871994449e3dbaf1657a595b10ecae37e2fc50b5a92e2434e69574ad63506  internal/runtime/launcher/monitor_linux_test.go
ccba4cd8f35194ed38082a4f70b9aa5c0525ca27990fa6efcf4522aec2cda83e  internal/runtime/launcher/monitor_models_test.go
e3b381b173d19610da3da8a36b8ff3447ca8cdd51578f73981f97f137ab1ee6b  internal/runtime/launcher/monitor_native_test.go
abd7375dce0901c5f81686d3410325a25ae0b5fc3113b6d37b768ed67d750226  internal/runtime/launcher/monitor_seccomp_linux.go
e1d28dac5a8ec642301a1329c38a32dcae9e3d2a3aa190a57c06ddc1018caa8d  internal/runtime/launcher/monitor_types.go
e55df1c2a257fa7c619d4134fb00e1600f0a4ee9c5e5be916cdb27db70801363  internal/runtime/launcher/monitor_unsupported.go
dfaba3d064e517317a97853c4fe800dfe208a4b54f615146f4e3733b82e8407e  internal/runtime/launcher/monitor_unsupported_test.go
ef20b8365503a4fbacc3013e1d56368f69c41d6958ee0fe86b23ed7a2951880e  scripts/test-launcher-kernel.sh
```


## 限制与未强迫分支（均保留）

- 未动态验证 Linux race；native 是 CGO0 arm64，amd64 是 static compile/vet 与同一 native runner 中的 BPF interpreter。
- Foreign/manual/CGO threads 不受支持；missing Seccomp_filters/Linux<5.9、不同内核/LSM/ABI matrix 未运行。
- 部分 all-thread install 失败后 rollback 不提供；首线程失败实际测试，随后线程分歧 fatal 的语义有 Go source proof，但未强迫 seccomp installer 后续线程分歧。
- 精确线程消失时序、全部3次重试耗尽、真实 filter4096 或 max4096 thread/1MiB mountinfo 限额不在 native workload 中强迫；parser/计数边界单测覆盖。
- 外部 host mount/cgroup 改动、所有 cgroup-v1 拓扑、权限/IO/resource exhaustion 组合不宣称已实测；未来生产启动必须遵守固定 mount/FD closure 和 sole spawn/wait owner。
- 计数只是诊断，不是 filter 内容的密码学测量；可信 Go runtime/caller 约束仍成立。
- 逐线程 filter 对后续 TSYNC 的兼容性限制保留，追加层应按受支持 all-thread contract 安装。
- 没有保证初始化期间 arbitrary syscall/kernel IO/STW 的可取消性，没有测 fleet成本、生产quota、业务End、remote write settlement、target/journal admission或完整 etcd 迁移完成。

## 文件清单与最终自查

所有代码位于 `/Users/dysodeng/project/go/cloud/sandbox/`：

| 文件 | 责任 |
|---|---|
| internal/runtime/launcher/monitor_types.go | portable opaque seal、UID/GID范围、共享diagnostic类型与Task2状态 |
| internal/runtime/launcher/monitor_linux.go | valid-role single attempt、真实waitid preflight、constructor与只读validation |
| internal/runtime/launcher/monitor_seccomp_linux.go | 两native架构固定BPF、all-thread安装/KeepAlive |
| internal/runtime/launcher/monitor_inspect_linux.go | bounded strict Seccomp/mountinfo/cgroup inspection与3次vanish retry |
| internal/runtime/launcher/monitor_unsupported.go | OS/architecture unsupported API |
| internal/runtime/launcher/monitor_models_test.go | identity范围及samePID/anotherPID receiver seal |
| internal/runtime/launcher/monitor_linux_test.go | nil/role/count/parser bounds、actual BPF interpreter、strictness regression |
| internal/runtime/launcher/monitor_unsupported_test.go | unsupported host行为、unsupported Linux test dispatcher编译 |
| internal/runtime/launcher/monitor_native_test.go | fixed monitor/user modes、真实线程和syscall/cgroup/child/failure测试 |
| internal/runtime/launcher/kernel_native_test.go | 仅注册固定测试模式 |
| scripts/test-launcher-kernel.sh | 必填explicit evidence目录、新positive markers；I1/waits/cleanup未改 |

自查已完整阅读native新增diff及产品关键diff，逐项核对作用域、error causes、固定flags和arch跳转、pointer stability、合法与非法receiver、未消耗invalidrole/已消耗validrole失败、no-child的nil/ECHILD区别、先注册worker/process清理和sole Wait ownership。发现的strict-parser问题与test-only TSYNC误用均已修正，未留已知待修问题。

`monitor_native_test.go` 为538行固定测试模式与oracle；保持计划指定文件布局，未另行扩展产品executor/assembly或Task2实现。复杂度集中在真实子进程/线程生命周期；它复用既有nativeProcess/holdNativeThreads注册/join机制。Task2未来必须使用 `validateCurrentLocked` 而非递归调用公开锁方法，并在Drain执行时完成poison/reaped上限逻辑；本Task只交付共享字段和confinement。

最终提交前 `git diff --cached --check`0；`shasum -a 256 -c .../task-1-native-canonical/source-sha256.txt` 所有20项OK（launcher所有Go文件+script）。Native字节没有在Root结果交回后改动。最终 `git status --short` 仅列原先无关Sentinel文档，不含本Task未提交代码。

验证没有强迫真实host改变mount/cgroup、strict seccomp mode1、partial后线程失败、线程瞬时消失/资源上限等分支，以上限制均逐条列出而非声称通过。没有把source proof、BPF interpreter、host race、实际Linuxarm64 syscall四类证据互相替代。原始RED失败记录、错误输出、二进制与精确源码全部保留在本Task自己的scratch目录，待Root完成独立审查及归档。

## Fix round 1 — M1 raw CRLF normalization

本节追加于初次报告，修正BASE为 `2095425dad82e45ad646dc974205f92a49112a97`。初次报告的“最终提交/source hashes/native canonical”记录保留为当时事实；本节的后续提交及focused证据覆盖此2文件修正，不声称旧canonical二进制包含新修正。

已阅读完整 `task-1-review.md`、指定re-review模板以及M1源码。Go1.25.6 `bufio.ScanLines` 在返回token前调用dropCR；产品原来在token上拒绝control bytes，因此原始CRLF和16KiB+CR边界会被规范化后接受。此判断已通过真实focused RED确认。

### RED（先新增测试，产品未修正）

增加 `TestMonitorMountCRLF`：3种 malformed 输入分别是cgroup record CRLF、非cgroup record CRLF后接合法cgroup、合法16KiB行后追加原始CR。合法普通LF和恰好16KiB LF必须成功。旧parser SHA256 `0255d73f610547629567dc02170b50f16e24809fe15201cfcafc2db0320110b1`，test SHA256 `3d5283e926e43ab80bd82b17653fb89f90e6ed719a7c89a76a1434274d475d99`。

Root冻结源码后运行focused coordinator：selector `^TestMonitorMountCRLF$`、expected process1。完整命令argv/所有返回值保存在 `task-1-m1-red/commands.json`；实际完整测试stdout/stderr为 `task-1-m1-red/attach.stdout`、`attach.stderr`，源/binary/outcome/cleanup为 `result.json`，Root独立复核为 `task-1-root-m1-red-proof.json`。实现者已读取raw stdout与result，未自行启动Docker。

实际输出：

```text
=== RUN   TestMonitorMountCRLF/other_record_CRLF
    monitor_linux_test.go:277: raw CR accepted after line normalization: <nil>
=== RUN   TestMonitorMountCRLF/cgroup_CRLF
    monitor_linux_test.go:277: raw CR accepted after line normalization: <nil>
=== RUN   TestMonitorMountCRLF/CR_exceeds_raw_line_bound
    monitor_linux_test.go:277: raw CR accepted after line normalization: <nil>
--- FAIL: TestMonitorMountCRLF (0.00s)
    --- FAIL: TestMonitorMountCRLF/other_record_CRLF (0.00s)
    --- FAIL: TestMonitorMountCRLF/cgroup_CRLF (0.00s)
    --- FAIL: TestMonitorMountCRLF/CR_exceeds_raw_line_bound (0.00s)
FAIL
```

0PASS/4FAIL/0SKIP；actual attach/process1，docker wait command0/value1，exited/Running=false/OOMKilled=false。合法LF assertions成功后才进入这些子测试。RED binary SHA256 `c8f96d97b6bbbf0b38c46114b6209f4677aa0ac3864fbdef003b77780e5e1e05`。单个确切归属container及volume均removed/exit0，三个own inventories均exit0/empty；没有遗留session/fixture。

### 最小修正与自查

只在 `validateCgroupMounts` 的输入byte-bound检查后、Scanner创建前添加 `bytes.IndexByte(data, '\r')` 拒绝及注释，产品改动5行。新测试24行；全diff只涉及 `monitor_inspect_linux.go`、`monitor_linux_test.go`。既有LF记录、escaped路径、per-mount只读语义、其余control检查、1MiB/4096行/16KiB限制不改动。pre-scan在已限制1MiB的byte slice上执行，没有新增状态、IO、goroutine、syscall或平台分支。没有额外产品范围/Task2实现。

新parser SHA256 `960df6c8874a0dbcfeec4b93f690eb00662a8ccff69f893f7c5c8d1ce56bbf0f`，test SHA不变。完整29-line diff已自查；`git diff --check`0。

### 修正后的静态覆盖（raw持久化）

每条command、env、exit、stdout、stderr分别持久化于 `task-1-m1-static-arm64.json`、`task-1-m1-static-amd64.json`：

```sh
env CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go test -c -o .superpowers/sdd/2026-10-07-monitor-confinement-drain/task-1-m1-arm64.test ./internal/runtime/launcher
env CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go vet ./internal/runtime/launcher
env CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go test -c -o .superpowers/sdd/2026-10-07-monitor-confinement-drain/task-1-m1-amd64.test ./internal/runtime/launcher
env CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go vet ./internal/runtime/launcher
```

四条全部exit0，stdout/stderr均空。未重复不受此2文件改变影响的host/race或9mode canonical suite；旧suite证据和所有原先限制继续保留。focused native GREEN已由Root交回，结果如下。

### GREEN、提交与最终结论

Root运行focused selector `^TestMonitorMount`（existing mount tests、strict mandatory fields/proc escapes、newCRLF）expected0。完整命令及env/digests/source差异/output仍保存在 `task-1-m1-green/commands.json`、`result.json`、`source-*`。已完整阅读 `attach.stdout` 以及Root独立证明 `task-1-root-m1-green-proof.json`；stderr为空。

关键实际输出：

```text
--- PASS: TestMonitorMounts (0.01s)
    --- PASS: TestMonitorMounts/long_line (0.00s)
    --- PASS: TestMonitorMounts/too_many_bytes (0.00s)
    --- PASS: TestMonitorMounts/too_many_lines (0.00s)
--- PASS: TestMonitorMountStrictFields (0.00s)
--- PASS: TestMonitorMountCRLF (0.00s)
    --- PASS: TestMonitorMountCRLF/other_record_CRLF (0.00s)
    --- PASS: TestMonitorMountCRLF/cgroup_CRLF (0.00s)
    --- PASS: TestMonitorMountCRLF/CR_exceeds_raw_line_bound (0.00s)
PASS
```

实际30PASS/0FAIL/0SKIP。attach/process0、wait command0/value0、exited/Running=false/OOMKilled=false。合法LF和exact16KiB LF均通过新测试前置断言；既有escaped paths继续通过strict fields测试。binary SHA256 `2dda1c12cfd4436420c5bab160a51a7e3c224822b471d92d74c9eedccd161e79`，实际CGO0/Linuxarm64。

GREEN本轮确切归属container/volume各1、removal0，三个own inventory成功为空。结合M1 RED本轮合计4次确切归属removal0；这些不是在重复旧canonical资源。Root报告无遗留fixture/session。

结果交回后，逐文件重新用Python SHA256核对focused GREEN `result.json.source` 与当前所有源码和binary，全部一致；`git diff --cached --check`0。未再改变受测源码，立即提交 `56ce9a1` — `fix(launcher): reject raw CR before mountinfo tokenization`（只2文件、29新增行）。最终status仅剩原先无关Sentinel文档；未读取其内容、暂存或修改它。

M1已修正，没有新增已知问题或新的syscall/runtime假设。最后29-line diff只提前拒绝原来漏过的rawCR，未触及seccomp/线程/child ownership/fixture脚本。最新focused30PASS用于本parser修正；先前1417PASS canonical属于前一个parser版本并保留原source identity。没有将focused结果冒充最新whole-unit canonical。后续Task2或整体gate是否运行最新whole-unit canonical由Root按实际变更决定。原先平台、线程churn、partial-seccomp divergence、TSYNC及生产集成等限制继续适用。
