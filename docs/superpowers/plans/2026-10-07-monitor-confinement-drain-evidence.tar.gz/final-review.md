# Monitor confinement and descendant drain — final independent review

## Scope and requirements

**Spec PASS / Quality Approved / Critical 0 / Important 0 / Minor 0.** This is the final review of the complete NEW monitor-confinement/local-descendant-drain unit, original **7b432c9..bdfc15f**, 12 commits, 21 changed paths, supplied 140,062-byte/3,317-line review package. It is not a completion or merge approval for the overall Redis migration/phases 1–5.

Used the full `/Users/dysodeng/.codex/skills/requesting-code-review/code-reviewer.md` template. Read the binding global constraints, full design and plan, both implementation reports including all appendices, original Task1/M1 re-review/Task2 reviews, all eleven Root proof JSON records, and the complete own progress ledger including all twelve ordered rulings and their costs. Judgments below follow my source/evidence inspection rather than the earlier reviewers' grades.

The preexisting kernel and earlier migration baseline is reused from `docs/superpowers/plans/2026-10-07-launcher-kernel-boundary-final-review.md`, read fully with all 64 inherited boundaries and 28 kernel-specific limits. I did not reread the older >100-commit migration delta or reopen deleted/sibling scratch. The named present-day kernel, journal and start-protocol seams were inspected separately below.

## Strengths

- **Confinement is genuine and process-local.** `internal/runtime/launcher/monitor_linux.go:26` consumes only a current prepared monitor role; nil/wrong-role checks precede the one-attempt guard, while real-role preflight failures consume the attempt. Actual non-consuming `waitid(P_ALL, WEXITED|WNOHANG|WNOWAIT|WALL)` accepts only ECHILD, including correct rejection of live children that are not yet waitable. `monitor_types.go:13,50` and constructor self initialization reject same-PID receiver copies before lock acquisition; copied mutexes cannot acquire independent wait ownership or bypass poison.
- **The fixed policy checks architecture before native syscall rules.** `monitor_seccomp_linux.go:15` has correct amd64/arm64 audit constants and deny tables, amd64 x32-bit and 512–547 ENOSYS, clone3 ENOSYS, five EACCES rules and low-word namespace-clone masking. The emitted instructions are interpreted in `monitor_linux_test.go:147,186`, independently from the builder predicates. `:58` installs through the all-Go-thread stable-pointer/KeepAlive path. The inherited installed-runtime contract and actual new-thread observations support the stated CGO0 scope; no single-thread fallback was introduced.
- **Inspection is bounded and fail closed.** `monitor_inspect_linux.go:26,87,110,175` checks missing/duplicate/incompatible seccomp fields, uniform bounded baseline, exact count+1 after installation and at least installed count later. Mount parsing distinguishes per-mount ro from superblock rw and rejects every writable cgroup view; current membership must exactly equal the copied seal. The original M1 CR normalization bug is absent: raw CR is rejected before ScanLines. Byte/page/line/thread ceilings are explicit and no idle worker exists.
- **Drain has one auditable success path.** `monitor_drain_linux.go:21,37` fixes production calls to actual wait4(-1,WNOHANG|WALL), current validation and direct-child scan. Context/receiver/owner guards precede mutation; every operational failure poisons and zeros output. Only real ECHILD followed by fresh boundary validation and live context returns a copied observation. Repeated Drain calls wait and validate anew. At most 4096 raw terminal statuses are retained; stopped/continued status is rejected. The synchronous 5ms pending timer creates no detached cleanup goroutine.
- **Signal identity stays pinned.** `monitor_process_linux.go:31,140,191,235` parses identity before policy selection, accepts zombie Threads:0, scans page128/max4096, pins O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC directories, opens bounded status/cgroup through openat, and checks the full seal before signaling. It rereads the same FD's PID/Tgid/PPid/seal immediately before pidfd_send_signal. Neither recycled numeric PID lookup, process-group kill, stopped-snapshot reasoning nor a retained transitive PID map is used. Close failure takes precedence over a disappearing child. Under the explicit immutable-topology/no-new-trusted-spawn/sole-wait contract, the direct-child adoption fixed point is consistent with final ECHILD.
- **Tests distinguish kernel behavior from models.** `monitor_drain_native_test.go:477,552` tests root-exited/live-setsid descendants, a user subreaper, CLONE_PARENT, pre-adoption non-SIGCHLD type, bounded forks, delivered SIGCONT, zombie/natural cleanup, cancellation, concurrent same-UID monitors and stale pinned proc FD. Parent proc observations and sole-monitor actual wait statuses corroborate results. Raw-helper children in both assembly files execute only masked raw syscalls and cannot return to Go. Non-SIGCHLD pre-adoption contrast is correctly separate from post-adoption reaping.
- **Failure cleanup retains ownership and uncertainty.** `monitor_drain_native_test.go:158,262,447` registers same-owner diagnostic cleanup before spawn and joins all management wait owners before PID1 adopted-user fallback. Poison is not cleared; unexpected residual users fail even if fallback cleans them. Controlled omission RED is preserved rather than relabeled as a passing workload.
- **Scope and cost remain explicit.** Product files add no RPC, Lease, idle-N timer, production start method, dependency, image/config/Manager/Redis/FUSE change or new privilege. The 112-line state machine and separate observation/policy files keep product complexity local. The larger fixed-mode native test files have identifiable lifecycle and oracle responsibilities; their size alone is not a defect.

## Issues

### Critical (Must Fix)

None found.

### Important (Should Fix)

None found.

### Minor (Nice to Have)

None found. Original Task1 M1 is closed; no deferred minor or parked current finding is introduced.

## Plan alignment and named integration seams

1. **Kernel current-state/capability boundary:** read `internal/runtime/launcher/kernel_linux.go` completely, then `kernel_inspect_linux.go` and `kernel_types.go` for the concrete risk that monitor validation might accept a cached role/capability snapshot. `monitor_linux.go:94` calls `m.kernel.ValidateCurrent`; that calls actual `inspectKernel(role,false)`. Every observed thread must have all root IDs, P/E=e0, I/A/B=0, NNP1, securebits0, dumpable0 and subreaper1. The scalar securebits GET remains all-thread; proc traversal is bounded. No diagnostic Snapshot substitutes for this check. Mutex/syscall/STW waits remain availability limits, not context-preemptible operations.
2. **Passive closed journal:** read `internal/runtime/controltarget/journal_types.go` and `journal_exec.go` fully. `recordFromEvidence` constructs only State=unknown; `RecordUnknown` validates opaque evidence consistency, binds runtime/workspace/generation/data-gate identity and durably records passive history. `Lookup` returns bounded diagnostic records. Neither API receives `LocalDrainObservation`, emits business End nor releases ownership. Historical evidence may intentionally outlive its authentication window; this is not live admission. The older journal filesystem/close implementation remains the certified baseline rather than a newly audited whole package.
3. **Start-ticket attribution:** read `internal/runtime/controlprotocol/exec_start_types.go` and `exec_start.go` fully. Evidence fields are private and wire copying is preserved. Verification checks pinned trust binding, fresh issuer certificate, actual descriptor digest, exact caller-supplied expected operation/runtime context, delegate signature and bounded time. Its explicit non-guarantees (active issuer, live lease, committed intent, open gate) remain true. The new monitor observation has no conversion into that evidence or into an authenticated target binding.
4. **No accidental production authority path:** targeted `rg` over `internal` and `cmd`, excluding launcher, for the launcher import and ConfineMonitor/MonitorBoundary/LocalDrainObservation returned no matches. The complete NEW diff likewise contains no external consumer. Therefore no new route makes local cleanup become Start, End or owner release; equally, current production legacy paths have not acquired this protection.
5. **Protected management/user/wait identity:** read `kernel_user_native_test.go:27–160` solely for the risk that the reused fixture helper creates competing wait owners. It creates one management Cmd.Wait goroutine and stop confirms that owner has joined. New user spawn uses os.File streams plus Process.Release, no Cmd.Wait; PID1 fallback runs only after management joins. Production serialization, exact root identity and descriptor closure remain mandatory future integration, separately itemized below.
6. **Plan deviations:** no harmful deviation found. The standalone Go/assembly test helper, exact helper source/binary proof, test-only fallback and non-SIGCHLD evidence refinement match prior binding Rulings9–12. They neither add a production helper nor claim an omitted-WALL native counterexample. Mandatory explicit evidence path and copied-handle rejection match Rulings7–8. The final controller retention/checkbox step remains open for Root after this report, as planned.

## Evidence checked and limits of this review

- Read supplied NEW diff sequentially through EOF. Initial large output clipped part of the documentation hunk; recovered the affected 130–188 documentation segment, then read nonoverlapping remaining implementation hunks through line3317. No regenerated git diff or duplicate changed-source rereview. Initial batched report/ledger output also clipped; recovered report sections and ledger execution/ruling sections explicitly. No test, race, fixture, high-count run, git-state mutation or nested reviewer was used; no unanswered named source doubt required a new experiment.
- Independently SHA256-compared all28 current canonical manifest entries and both saved binaries: zero mismatches. The27 launcher/helper source entries in each persisted repository test/vet/build record also match current bytes. Earlier HEAD metadata on those records therefore does not mean earlier source content. Current canonical source revision is35f1bc9; later HEADbdfc15f is documentation-only.
- Canonical main SHA256 is `72e61d2a2b5a36ed98b947542f2bbabf9b22be07afe4a001d3361967e2d640fd`; canonical helper is `2d17cd27a1522a0933d891078aec51bd47912170441ee3ebecd52a710c7a6f81`. Focused helper `92d9ded2ad841ecfe5c043c74b5ebfb5771aa7ea604b04200198e046088cd68a` remains a different binary. Root's retained build metadata records the changed embedded VCS revision/time/module pseudo-version with unchanged helper source; no same-binary claim is made.
- Independently counted the entire retained positive canonical log: **1502 PASS / 0 FAIL / 0 SKIP**, final PASS. This includes old tests and subtests, not1502 newly invented scenarios. Read the entire new drain raw block2972–3297 and new confinement/rejection block3376–3624. Actual kernel is Linux7.0.12-linuxkit/aarch64. There are12 additional actual ECHILD oracles,13 management joins and11 zero-residual PID1 fallbacks; canceled monitor cleanup reaps its one live user with raw9 while retaining poison.
- Current confinement evidence independently shows monitor256 seven baseline threads/count1, seven installed/count2 and sixteen later/count2, nine newly observed threads. User273 has seven observed threads, all UID/GID1000/fivecapsets0/NNP1/filter3; ordinary nested exec succeeds. Monitor and user each see13 EACCES probes and clone3 ENOSYS; root cgroup write-open EROFS/user EACCES. These current values intentionally differ from original Task1 monitor72/eight new threads.
- Current drain evidence shows double root79Z plus adopted live leaf89, then wait0/9; subreaper99/109 wait9/9; CLONE_PARENT119/126 direct monitor113; clone-zero child140 under133 with exit_signal0 and ordinary-vs-WALL WNOWAIT contrast, then adopted wait9. Fork fixture completed three observed forks, not its full bound6. SIGCONT was actually delivered to176. Natural200 was explicitly waited before empty Drain. Cancel210 remained live before diagnostic cleanup. B231 and later B252 kept their starttimes while old FDs220/242 returned ESRCH; numeric PID reuse was not forced.
- Read all nine canonical result records: eight exit0 cases and expected inherited securebits-fatal exit2, matching attach/process/wait with wait-command0 and exited/not-running/noOOM. Read recorded creation fields for every mode: private PID, netnone, root, unprivileged, readonly root and both binaries, dropALL with named fourcap contract (deliberate original negative differences),64MiB/128pids/0.5CPU/GOMAXPROCS2 and exact owned labels. Read complete current cleanup:18 exact removals exit0, three empty successful own inventories.
- Read all Root proof JSON records and independently counted all nine focused raw stdout logs: Task1 omission0/1/0, parser0/7/0, M1 RED0/4/0, M1 GREEN30/0/0; Task2 seal52/1/0, loop67/0/0, identity68/0/0, descendant omission0/2/0, native81/0/0. Read focused result state/cleanup/inventory fields: each expected actual exit and every exact removal/query succeeded. Initial missing-symbol RED remains compile-only; later omission RED remains postimplementation. Detailed original Task1 canonical internals remain previous-review/Root-certified evidence, not a claimed fresh reading of every old raw line.
- Read complete persisted final repository test/vet/build stdout/stderr and exits0:30 ok packages,8 no-test packages,25 cached. Read host race output0 and both current Linux compile/vet summaries with actual environment CGO0/GOOSlinux/GOARCHamd64 or arm64 and blank error output. Bash syntax and canonical controller exit0 are retained. No cached repository result is a fresh etcd/FUSE/Redis fixture or complete per-test skip census. An overlong saved PATH field clipped one evidence display; reduced the display to relevant GOOS/GOARCH/CGO fields and recovered the affected records.
- Only this requested report is written. No unrelated Sentinel file content, sibling/deleted scratch, checkout/index/HEAD/branch state or remote publication was touched.

## CannotVerify — precise controller dispositions

- **CV1 — Historical Task1 raw host/static transcripts:** the initial raw transcripts are unavailable independently; the report and Root's earlier tool-output attestation remain the evidence. Root must preserve that attestation and this limitation in the permanent verification artifact; do not regenerate unchanged suites to disguise the historical gap. Current exact-source canonical/Task2 transcripts do not retroactively supply missing historical transcripts.
- **CV2 — Production single-command/sole-wait ownership:** no production caller is delivered. Root must require the next authenticated target unit to serialize the one completed user spawn, bind the exact root/result, prohibit all new trusted spawn once draining starts, exclude unrelated children and ensure no competing os.Process.Wait. The current handle's private mutex and test ownership are reviewed, but cannot enforce external caller behavior.
- **CV3 — Production protected FD/identity/topology contract:** Root must verify actual target child credential/env/workdir/descriptor setup and management/resource-FD closure, trusted unchanged mounts and exact bound cgroup in the next production spawn path. Fixed native modes are not certification for arbitrary payloads or production topology.
- **CV4 — Journal settlement/business End:** the current named seam question is resolved: only unknown passive records exist and no local observation is consumed. Root must still implement and independently verify durable accepted/terminal transitions, both drains, external-write settlement and evidence-gated owner release before a production End can follow local cleanup.
- **CV5 — Physical authenticated target delivery:** the current signature/expected-context seam remains attribution-only. Root must verify live issuer/lease/intent/gate/current boot/activation and transport authentication at actual effect delivery; VerifyExecStartTicket plus a local monitor handle cannot stand in for these checks.
- **CV6 — Poison, crash and production namespace escalation:** Root must retain unknown/closed ownership after failure/lost monitor and implement real PID1-wide cleanup plus remote settlement before release. The test-only fresh-budget fallback preserves poison and proves no production recovery protocol.
- **CV7 — Final controller evidence gate:** this report completes the independent NEW-unit review only. Root must read/dispose every line, permanently preserve full reports, exact raw evidence, original REDs, all12 ordered rulings/costs and every inherited limitation, verify the archive, then mark the separate final checkbox and clean only this unit's own scratch. Continue production phases1–5; do not label this gate overall migration completion.

## Declined-to-judge and remaining evidence boundaries

Every following line is retained individually. These are scope/coverage conclusions with reasons, not parked current defects. The controller must keep the named later obligations and cannot silently turn an unforced branch into a passing claim. The current source and native checks above answer this unit's requirements; they do not certify future consumers.

### Current-unit limits (L1–L26)

- L1: Native execution is Linux arm64 on the recorded LinuxKit kernel; native amd64 is unrun, despite CGO0 amd64 compilation/vet and assembly source inspection.
- L2: Recorded race execution is Darwin host race; native Linux race remains unrun.
- L3: Forced numeric PID reuse is unrun; stale old FD ESRCH with another/fresh surviving process is the actual proof.
- L4: Non-SIGCHLD child type is verified before adoption; native omitted-WALL failure after adoption is not established and must not be claimed.
- L5: Reap/process 4096-limit tests are controlled tests, not actual 4096-process exhaustion.
- L6: Repeated fork adversary observed three completed forks under the existing 128-pid fixture; it is not a 128-task stress/exhaustion result.
- L7: Real resource exhaustion and syscall permission/I/O failures are not exhaustively forced; deterministic private fault seams cover the relevant state-machine outcomes.
- L8: Arbitrary hung kernel I/O, uninterruptible tasks, kernel-lock waits, STW or unhealthy-daemon delays are not preempted or bounded by the context.
- L9: Cancellation is deliberately triggered after actual initial validation; all possible cancellation interleavings are not exercised.
- L10: Assembly parent signal-mask-restoration denial is unforced; the code attempts restoration and reports an error, but cannot promise restoration against syscall denial.
- L11: Full ABI/x32/LSM/kernel/platform and Go-version matrix is unrun; the helper's amd64 path has no native execution in this evidence.
- L12: Foreign/manual/CGO threads remain unsupported, not silently certified by CGO0 tests.
- L13: Actual missing Linux5.9 proc fields and strict seccomp-mode environments remain inherited unforced cases.
- L14: Later-thread seccomp divergence and all-thread setter divergence breadth remain inherited limits; unchanged Task1 fatal-path evidence must be retained separately.
- L15: Exact vanished-thread retry interleavings and exhaustion remain inherited unforced cases.
- L16: Actual 4096 thread/filter resource stress remains inherited unforced coverage.
- L17: Cgroup-v1 topology breadth remains unforced.
- L18: External mount/cgroup mutation remains unforced and is subject to the trusted topology contract and fail-closed observations.
- L19: Filter counts are diagnostics rather than policy authentication; future TSYNC compatibility is not promised.
- L20: Monitor crash recovery and production PID1-wide cleanup remain downstream, as CV6 states.
- L21: Power-loss/restart recovery is not tested by these local drain cases.
- L22: Production idle/active RSS, startup latency, minimum quota and fleet throughput measurements are not established by successful fixture quotas/noOOM.
- L23: Original Task1 host/static raw transcripts were not independently available according to the inherited ledger; Root must preserve the prior attestation/limitation rather than attribute fresh Task2 transcripts to Task1.
- L24: Production target transport/start admission is not delivered here; CV2/CV3/CV5 remain separate requirements.
- L25: Journal business End and external-write settlement are not proved by local ECHILD; CV4/CV5 remain separate requirements.
- L26: Manager/Redis/FUSE migration, production image/configuration changes and final Redis removal remain outside this gate.


### Task1 individual evidence limits retained in full

The ten original Task1 lines below remain applicable, including the real mountinfo size ceiling and precise setter/runtime distinctions. M1 alone was corrected; none of these limits was silently closed by its parser fix or the later canonical pass.

- **Linux race:** native evidence is CGO0 Linux arm64; host race is Darwin arm64. No Linux race conclusion is available. Retain this distinction; if future supported threading behavior changes, require a separately identified native-compatible race strategy. Evidence: `task-1-root-canonical-proof.json:1`, `task-1-report.md:1`.
- **Native amd64/ABI matrix:** amd64 has static compile/vet claims and actual generated-BPF interpreter execution, not native amd64 kernel syscalls. Foreign audit ABI and x32 decisions are interpreter coverage, not process-kill integration evidence. Require native amd64/ABI runs before claiming that expanded dynamic matrix. Evidence: `monitor_linux_test.go:186`, `task-1-native-canonical/positive.log:2884`.
- **Later-thread seccomp installation divergence:** first-thread EPERM is dynamically covered, and all-thread fatal behavior has runtime source support plus the predecessor scalar divergence fixture. A later-thread failure of this particular seccomp install was not forced. Preserve that precise limit; only a safely constructed dedicated process fixture could extend the dynamic claim. Evidence: `monitor_seccomp_linux.go:58`, `task-1-native-canonical/positive.log:3134`.
- **Vanished-thread retries:** the bounded three-attempt path is present; precise disappearance interleavings and exhaustion of all attempts were not forced. A focused controlled filesystem/thread-lifecycle fault seam would be needed to claim deterministic coverage. Evidence: `monitor_inspect_linux.go:110`.
- **Real resource ceilings:** count/parser unit cases cover synthetic limits, but the fixture does not create 4096 real filters/threads or 1 MiB real mountinfo. Preserve this as availability/unknown behavior under exhaustion; do not stress the fixed native quotas merely to relabel the boundary unit tests. Evidence: `monitor_inspect_linux.go:87`, `monitor_linux_test.go:47`, `monitor_linux_test.go:93`.
- **Missing/strict seccomp facilities:** missing fields and strict mode 1 are parser cases; Linux<5.9, missing proc support, and native strict mode 1 were not actual runtime fixtures. Future platform expansion must check required fields and unsupported errors on those environments. Evidence: `monitor_inspect_linux.go:69`, `monitor_linux_test.go:32`.
- **Mount/cgroup mutation and v1 breadth:** synthetic v1/alternate-view/membership cases exist, but external host changes, every v1 topology, and the full permission/I/O/LSM matrix are not dynamically forced. Future integration must retain trusted stable topology and exact membership fail-closed behavior. Evidence: `monitor_linux_test.go:93`, `monitor_linux_test.go:131`, `monitor_linux.go:111`.
- **Foreign/manual/CGO threads:** explicitly outside the supported contract; the Go API returns ENOTSUP with cgo and cannot certify manually created foreign threads. Do not broaden support based on the thread-count observations. Evidence: `monitor_linux.go:20`, `/Users/dysodeng/go/go1.25.6/src/syscall/syscall_linux.go:1117`.
- **Filter identity and later TSYNC:** counts are diagnostics backed by actual trusted installation, not policy attestation. Per-thread installation produces separate trees; later TSYNC compatibility is not promised. Additional layers used by trusted callers must preserve the supported all-thread contract. Evidence: `monitor_seccomp_linux.go:58`, `monitor_native_test.go:499`, `task-1-report.md:1`.
- **Cancellation and downstream delivery:** arbitrary kernel I/O/STW cancellation, monitor-crash recovery, PID1-wide cleanup, fleet costs, production minimum quotas, target/journal admission, business End and remote-write settlement remain outside this local Task 1 result. Required check: carry these to their named later integration/measurement gates; do not interpret the handle or this review as execution permission or completed migration. Evidence: `monitor_types.go:8`, `monitor_types.go:32`, formal spec ownership/drain/cost sections.


### Inherited baseline boundaries (1–64)

Permanent source: `docs/superpowers/plans/2026-10-07-launcher-kernel-boundary-final-review.md`. Verbatim individual boundary list follows, with current interpretation immediately after the inherited lists.

1. Physical Create/Prepare deduplication and crash recovery — mandatory later; local journal storage does not invoke or arbitrate physical runtime creation.
2. Truthful birth/ready observations and receipt issuance — mandatory later; closed file contents and signatures do not establish live mount/gate observations.
3. Physical mount-once and FUSE retry exclusion — mandatory later; no physical mount consumer is delivered.
4. Durable intent with current original operation/task authority — metadata and passive journal advanced; target consumption and independent task authority remain mandatory.
5. Target Begin/End, streams/descendants and terminal receipts — mandatory later; unknown is deliberately not physical terminal proof.
6. CloseData/CloseAll, exclusive barriers, both drains and legal reopen — mandatory later; this close-only journal cannot prove drain or open a new epoch.
7. TTL extension, destroy/task machine and safe owner release — mandatory later; no evidence-gated lifecycle engine is supplied.
8. Certificate install/activation/rotation/revocation and UUID uniqueness lifecycle — mandatory later at targets; this unit does not install or activate authority.
9. Production issuance and root/delegate key custody — mandatory later; test signers and opaque evidence interfaces do not establish operational isolation.
10. Actual trusted PID1/launcher, management UID and IPC/proc/FD/key isolation — mandatory later; UID0 filesystem tests are not a production sandbox boundary.
11. All raw/legacy execution bypass removal and descendant containment — mandatory later; Manager and both existing adapters remain unmigrated as directly checked.
12. Production controlled clock and target-time rechecks — mandatory later; journal intentionally accepts historical diagnostics without a new clock.
13. Atomic UTC expiry at storage commit/external effect — not promised; existing bounded observations and later target rechecks remain the chosen contract.
14. Warm pool, persistent slots/free indexes and recovery accounting — mandatory later; fixed journal point cost does not implement pool/quota coordination.
15. Docker/upload/extract/workspace mutation adapters — mandatory later; passive records do not enforce final payload/options at those boundaries.
16. Partition scheduler, R+1 watches, shared renewal and bounded queues/caches — mandatory later; no replacement orchestration is supplied here.
17. Collector/readiness/autosync and hung FUSE probe slots — mandatory later; no real bounded probe scheduler is implemented.
18. Safe journal/receipt/snapshot GC, history/churn and unknown backpressure — local capacity refusal advanced; safe retention/recovery/global budgeting remain mandatory and unknown cannot be deleted by age.
19. Manager/API/SDK/native-only configuration wiring — mandatory later; the absence of current wiring is intentional for this intermediate passive unit.
20. Old-version drain and complete Redis/Sentinel removal — mandatory later; current production Redis initialization remains, and this review does not approve migration completion.
21. Production mTLS/auth/RBAC/prefix/bootstrap isolation — mandatory later; local native fixtures do not establish deployment controls.
22. Disaster restore epochs and old process/writer/credential quarantine — mandatory later; local exact identity mismatch is only one prerequisite.
23. Actual 10k/100k/1M Pod/FUSE, QPS/p99 and recovery SLOs — mandatory later; synthetic file histories are not real fleet acceptance.
24. Multi-cell routing/cross-cell semantics — phase 6, outside current phases 1–5; no cross-cell guarantee is inferred.
25. Malicious trusted Clock/signer/callback implementations — outside the trusted dependency contract; in-process hostile code isolation is not claimed.
26. Arbitrary Byzantine envelopes across every old generic native path — not newly audited/retrofitted; the unchanged certified baseline and new strict consumer remain separate.
27. Coordinated forgery by an authorized raw etcd writer — outside application capability guarantees; production writer isolation remains mandatory.
28. Early-Fatal join modernization for every old harness — deferred maintenance; new journal workers are reviewed, not a certification of every old test helper.
29. Prior actual-Grant Stage-copy regression M2 — CLOSED in the predecessor unit; this journal does not change that code or reopen the accepted fix.
30. Current dependency/image vulnerability or supply-chain certification — not performed; no dependency/image changes are introduced and no advisory audit was requested.
31. Unrelated Sentinel edits and controller bookkeeping — preserved/excluded; controller must finish its own journal gate checkbox without staging unrelated work.
32. Original remaining monotonic Lease start bound — predecessor producer implemented; delivery and target rechecks remain mandatory, and journal history cannot substitute.
33. Accepted-only renewal and non-start command purposes — separate mandatory protocols; unknown records expose neither accepted nor renew/task/file authority.
34. Final payload reconstruction and credential/env/path/default policies — target enforcement mandatory; digest-only storage deliberately lacks the payload.
35. Standalone registry Load detecting coherent pre-discovery recreation without an original revision — intentionally not promised; no new registry behavior in this delta.
36. Permanent issuer-rotation retention and safe GC — mandatory later; journal capacity does not budget or delete the issuer registry.
37. Provider concurrency/lifetime/exact-signer retention and rotation availability — unchanged trusted operator contract, not reimplemented by passive journal.
38. Generic Stage writes/deletes to command-issuers — CLOSED predecessor hardening retained; journal introduces no generic Stage entry point.
39. Certificate validity at exact storage commit — not a historical-storage authority promise; subsequent authenticated effect delivery must recheck freshness.
40. Source reading gate — SATISFIED for the complete new journal delta; certified old baseline reused under explicit ruling, no fresh 1.8 MB whole-branch EOF claim.
41. Legacy creation-claim decoder strictness — unchanged trusted-storage/corruption classification boundary; no new path adopts its history as authority.
42. Birth-publication delegate/root equality — retained compatibility/key-custody boundary; journal does not change that certificate family or waive production key separation.
43. Exec three-clause versus Renew four-clause operation fences — unchanged predecessor contract/budgets; journal adds no writer that can exploit the difference.
44. Coherent externally forged effect/receipt pair — outside raw-writer protection; local history adds no means to reconstruct a Prepared capability.
45. Historical opaque etcd tickets not freshly verified by Load — intentional diagnostic API; journal accepts opaque verifier evidence, not raw loaded tickets, and grants no live authority.
46. Generic Stage invalidation of exec business history — unchanged trusted mutation surface; no journal call introduces it and safe GC remains separate.
47. Provider rotation during uncertain pre-entry registration — retained provider retry contract; no new journal-side registration/signing behavior.
48. Stage Revoke proof and Begin-failure cleanup context — unchanged metadata-cleanup boundary; neither it nor Journal.Close establishes external termination.
49. Preemptible capability-mutex waiting — unchanged predecessor contract; journal also serializes IO and does not promise prompt cancellation while another operation holds its mutex.
50. Recovery after creator loss/original deadline — remains metadata-only; neither etcd Load nor local unknown/temps can remint payload/capability or replay commands.
51. Conservative fixed ticket-window availability — retained cost; no record retry extends NotAfter or business expiry.
52. Delivery from cached Prepared — still requires future fresh original fences/time/target checks; only diagnostic Reference is public and current code has no transport.
53. Malicious same-management-UID/root mutation of journal/lock/directories — outside the specified filesystem writer boundary; lifetime mutex/flock assumes the protected identity is isolated in deployment.
54. Ancestor-directory trust, ACL/mount/filesystem deployment policy — outside the constructor's explicit owner/mode/no-symlink checks; trusted canonical parent and supported local filesystem provisioning remain required, not proven by POSIX mode alone.
55. Power loss, host failure, filesystem hardware persistence or crash at every machine instruction — not certified by fsync-boundary injection and process hard exit; those tests prove the stated process/filesystem contract only.
56. Immediate cancellation of blocked OS fsync and mutex waiters — not promised; pre/post context checks prevent successful late acknowledgements but cannot universally interrupt the underlying syscall.
57. Physical disk blocks/inodes, idle target process/FD overhead and preservation of user resource quota — later PID1/deployment budgeting mandatory; LogicalBytes excludes block and directory overhead and reserves no 256 MiB upfront.
58. Automatic repair/archive of missing manifests, malformed/incomplete temps or binding/BootID changes — intentionally unavailable; fail closed and retain evidence until a separately reviewed recovery protocol.
59. Always-available close/recovery at hard byte/file limits or disk errors — not promised; gate temp needs real capacity and no unknown evidence may be removed merely to obtain success.
60. Linux race and unsupported-platform execution certification — not performed; actual Linux CGO0 native and host race are distinct, unsupported constructors explicitly reject configuration.
61. Complete retained temp versus committed command identity — passive audit model only; temp files are validated/countable but not promoted or queried as final records, so future recovery must account for uncertain/differing attempts before any physical decision.
62. Arbitrary caller-supplied initial identity and path authority — trusted launcher configuration contract; Create validates shape/current UID and refuses existing targets, but does not prove the supplied runtime binding is a real attested incarnation.
63. Script cleanup when Docker removal/inspection fails — best-effort exact-label cleanup; final reviewed zero inventories establish this run only, not universal cleanup success. No individual rm-exit claim for the canonical final script run.
64. Synthetic hot-path equality as production performance — explicitly not inferred; cold scans grow with this runtime's history, warm-bucket counts omit bucket creation and can vary with EINTR.


### Inherited kernel boundaries (K1–K28)

Each line is a separately considered behavior; it is not an undisclosed defect. Existing rulings are identified; Root must preserve/adjudicate these individual lines when accepting this final report.

K1. Foreign/manual/native-created threads — outside the trusted CGO0 Go-owned-thread contract; AllThreadsSyscall cannot certify arbitrary foreign threads (existing securebits/support ruling).
K2. Actual CGO-linked initializer execution — not dynamically tested here; exact installed syscall source returns ENOTSUP and current supported positive uses CGO0 (Ruling6 retained).
K3. Dynamic Linux race execution — not performed; host race covers model/unsupported paths and cannot be relabeled Linux race (Rulings6/10 retained).
K4. A precisely scheduled thread disappearance during proc reads or exhaustion of all three retries — not forced in native evidence; code/strict parser and existing/new actual thread checks establish only their stated coverage (Ruling6 retained).
K5. Atomic perpetual validity of Snapshot — intentionally not promised; it is the last successful copied diagnostic and failure preserves that last copy, never authority (binding spec).
K6. Immunity to malicious in-process trusted code changing credentials concurrently — outside the trusted startup/caller contract; this library is not an in-process hostile-code isolation boundary (support contract/inherited25).
K7. Rollback or guaranteed ordinary error return after partial all-thread mutation — intentionally unavailable; mutations can remain and mismatched syscall returns can runtime-fatal without boundary (binding spec).
K8. Universal prompt cancellation of initialization or securebits validation — not promised; no context/preemption guarantee exists for runtime STW or underlying syscalls (binding spec).
K9. Survival/availability of a process with divergent securebits — deliberately sacrificed; actual runtime exit2 is fail-closed evidence, not recoverable success (securebits ruling).
K10. Actual production caller exit and external unknown/closed handling after initialization failure — mandatory future integration; there are currently no production callers to exercise (Root prerequisite ruling/inherited10,11).
K11. Test-only fsID audit as a production privilege strategy — not supplied; the exception is narrowly pinned, restored and validated in the fixed helper and does not authorize production raw per-thread setters (Root audit ruling).
K12. Forced fsID-restore failure/dirty-thread-retirement execution — not demonstrated by supplied native success; source keeps the goroutine pinned and helper errors/exits, while actual1000→0 restoration is observed. Retain as an explicit dynamic coverage limit rather than claiming the failure branch ran.
K13. Arbitrary cgroup-v1/layout/runtime-added descriptors — not accepted by this native oracle; the tested exact cgroup-v2 cpu.max/context/flags exception fails on unknown layouts (Task2 retained support boundary).
K14. General production dynamic-FD lifecycle and every possible descriptor leak — not proved by fixed helper pre-exec CLOEXEC/current child audit; future launcher exec wiring needs its own descriptor ownership review (inherited10,34).
K15. Arbitrary command payload/environment/workdir policy enforcement — mandatory later target integration; the current actual exec is a fixed test mode using explicit values, not a public command executor (inherited34).
K16. Every descendant, stream and arbitrary process-tree terminal settlement — not established by one held-pidfd cleanup child and helper proof; full physical supervision/draining remains mandatory (inherited5,11).
K17. Complete namespace/cgroup escape resistance or remote-write isolation — outside this kernel credential acceptance; resource settings/NNP/capability denial are not complete sandbox isolation (binding spec).
K18. Deployment of the transient SETPCAP/bootstrap topology with ordinary/FUSE mounters — mandatory later; current images/capabilities/privileged mounter were directly verified as unmigrated (Root bootstrap ruling).
K19. Original production-image allocated/RSS/FD/PID/inode overhead within unchanged user quota — mandatory later measured acceptance; numbers here come from the fixed test fixture (inherited23,57,64).
K20. Actual 10k/100k/1M idle process cost and fleet latency/recovery SLO — not proven by absence of new library timers or by fixture counters; fleet acceptance remains mandatory (inherited23,64).
K21. General Docker daemon responsiveness of inspect/create/kill/wait/rm/inventory calls — not promised by this shell fix; the repaired bounds cover named attach failure/client-termination branches while daemon calls remain synchronous (Ruling11 retained).
K22. Guaranteed OS termination/reaping of an uninterruptible attach process — not promised; helper records joined=false and exits failure if bounded observation cannot confirm disappearance (Ruling11 retained).
K23. Cleanup success after any arbitrary removal/inspection/inventory failure — not promised; current script fails/reporting preserves that uncertainty, and retained empty inventories certify only actual runs (binding fixture contract).
K24. Latest2378 script full native execution — not performed; priora833 native proof plus focused2378 shell-fault evidence and retained outcome comparison are deliberately distinct (Ruling11 retained).
K25. New native etcd execution or fresh uncached full-repository/per-test skip census — not performed; reused certified baseline and cached host repository checks provide narrower evidence (Rulings9/10 retained).
K26. Other Go versions, other Linux architecture/kernel/LSM combinations or unsupported OS runtime execution — not certified by local Go1.25.6/actual arm64 native proof and unsupported host model checks; wider deployment support requires affected checks (support contract).
K27. Permanent evidence retention and final controller checkbox completion — controller action remains after this report; this review provides the requested decision but does not itself move/archive artifacts or mark the plan complete (Ruling12).
K28. Overall authenticated target, independent birth/BootID/activation, accepted/terminal journal, dual drains, task/lifecycle/scheduler/collector/GC and full Redis removal — each remains individually tracked in inherited1–64; kernel acceptance cannot close those future physical/production obligations (Root prerequisite ruling).


### Current interpretation of inherited tracking entries

- Inherited1–64 are the already-certified earlier baseline's separate declined behaviors and reasons, reused without rereading that old implementation. CLOSED/SATISFIED entries stay closed; they are not newly opened findings. Root must retain their individual prior dispositions from the permanent kernel review.
- K16 and inherited11 advance only for this supported local descendant component: actual confined descendant/adoption drainage is now implemented and tested. Streams, remote writes, physical terminal protocols and every production raw/legacy bypass remain mandatory later work.
- K17 advances for the explicit inherited namespace/ptrace and readonly-cgroup policy tested here. Complete sandbox isolation, external host trust and remote-write isolation are still unproved and outside this local policy.
- K24 is historical kernel-unit evidence attribution. This NEW unit has its own current complete-script canonical execution and digest, so K24 does not create a false claim that today's script lacks native execution; the historicala833/2378 distinction must still remain in prior evidence.
- K27 is closed for the predecessor kernel gate but remains a distinct present controller action as CV7 for this unit. Inherited31/40 similarly retain their historical bookkeeping/source-reading meanings rather than becoming new source defects.
- K25 and L23 remain exact evidence limits: no fresh old native etcd fixture, old full-branch audit, uncached all-suite census or reconstructed historical transcript is claimed.
- Malicious in-process trusted code or external administrators changing protected state remain outside the trust model; this review does not waive the actual production isolation and restricted-writer work listed above.

## Recommendations

Preserve the full individual dispositions and exact-source proof before own-workspace cleanup. Carry the concrete CV2–CV6 checks into the next authenticated target/monitor integration review, especially exact root result ownership, protected FD closure, durable acceptance, failure-to-unknown handling and separation of local ECHILD from remote-write settlement. No additional broad suite or duplicate review is justified for unchanged source at this gate.

## Assessment

**Ready to merge? Yes for acceptance of this NEW prerequisite unit's reviewed code; no overall migration merge/deploy approval is given.**

**Spec PASS / Quality Approved / Critical0 Important0 Minor0.** Confinement and drain enforce the planned bounded, sole-owner local contract and retain uncertainty on every examined failure path, with current native evidence for the principal adversaries. The named existing seams preserve attribution/passive-record boundaries; production target, accepted/terminal journal, End/dual-drain, tasks/lifecycle, shared watches/scheduler, collector/GC and full Redis removal remain unfinished mandatory phases1–5 work.
