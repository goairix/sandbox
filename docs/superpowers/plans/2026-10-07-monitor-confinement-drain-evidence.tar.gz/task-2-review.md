### Spec Compliance

- ✅ Spec compliant for Task 2's implementation and verified local drain scope. Reviewed original `4bc0b9c96f5ad1de3fbed38858be030801249079..35f1bc9e85b774f52cdf132ef8236106875d3554`, including both binding-document amendments and both implementation/test commits. No missing, extra, or misunderstood Task 2 behavior found.
- ✅ `internal/runtime/launcher/monitor_drain_linux.go:21`: fixed production calls use actual `Wait4(-1, WNOHANG|WALL)` and direct-child scan; no public backend or raw start API. The context/receiver/owner guards precede mutation, operational failures poison and return zero, statuses are bounded to 4096, and success follows ECHILD, current validation and live context (`:37`, `:68`, `:82`). Repeated calls actually wait again; observations copy the retained slice.
- ✅ `internal/runtime/launcher/monitor_process_linux.go:31`: strict required identity/policy fields reject duplicate, missing, signed and overflowing values without requiring positive zombie Threads. Identity-only selection precedes full direct-child policy checking. The full file implements bounded page-128/max-4096 proc traversal, bounded openat reads, pinned directory handles, same-FD reread, seal/cgroup checks, pidfd-only SIGKILL and immediate close/error propagation; no transitive production PID map or SIGSTOP premise.
- ✅ `internal/runtime/launcher/monitor_types.go:62`, `monitor_drain_test.go:10`, `monitor_drain_linux_test.go:18`, `monitor_unsupported.go:12`, `monitor_unsupported_test.go:16`: deadline bounds, unsupported/nil/invalid handles, owner rejection, malformed seals, process/reap bounds, EINTR cancellation, operational/final validation failure, vanished rescanning, copying and fresh completion have focused tests. Private fault-seam behavior is not represented as real resource exhaustion.
- ✅ `internal/runtime/launcher/monitor_drain_native_test.go:477`: fixed native modes cover actual exited-root/live-setsid descendant, user subreaper, CLONE_PARENT, pre-adoption non-SIGCHLD child, repeated forks, SIGCONT, zombie/natural cleanup and cancellation; `:552` covers same-UID concurrent monitors and stale held proc FD with a later fresh process. Trusted PID1 reads actual proc state; only the monitor owns its user waits. `:447` registers cleanup before assertions, joins all management wait owners before PID1 fallback, and fails on unexpected residual users.
- ✅ `internal/runtime/launcher/testdata/drainclone/main.go:30`, `clone_linux_amd64.s:4`, `clone_linux_arm64.s:4`: fixed helper modes, child-only raw syscall loops with signals masked, no child RET/CALL/Go-runtime continuation. `main.go:46` independently tests non-consuming ordinary-versus-WALL waitid before adoption. The later monitor observation proves termination/reaping, not a native omitted-WALL counterexample after adoption.
- ✅ `internal/runtime/launcher/kernel_native_test.go:57`, `scripts/test-launcher-kernel.sh:87`: only fixed native dispatcher modes and fixed helper packaging were added; source/assembly and binary manifests, read-only helper mount and required drain marker are present. Existing canonical lifecycle/capability/quota settings are preserved in diff context and actual creation evidence.
- ✅ Required files each have a corresponding diff, with `monitor_linux_test.go` correctly left unchanged under the amended conditional file requirement. Document changes are the controller's binding helper/evidence/cleanup amendments, not unrequested product behavior.

### CannotVerify — individual cross-task obligations

- ⚠️ CV1 — Task 1 construction, all-thread setter correctness, full generated seccomp policy, cgroup parser implementation and complete historical Task 1 validation are inherited, not independently established by this Task 2 diff. `monitor_drain_linux.go:24` consumes that boundary. Root must carry forward the approved Task 1 full-range/scoped review and its original evidence limitations; this review checked only the named validation seam below.
- ⚠️ CV2 — `monitor_drain_linux.go:16` states trusted completed-spawn/sole-wait/no-new-spawn requirements. Fixed test modes establish them for this fixture, but production caller serialization, exact user-root binding and absence of unrelated trusted children are not implemented here. Resolve in authenticated target/monitor integration.
- ⚠️ CV3 — Management/writable resource FD closure and trusted unchanged topology are future production spawn requirements, outside the local API and this diff. `monitor_drain_native_test.go:180` is a fixed test credential/spawn path, not a product transport. Root must verify those requirements in the actual target spawn path.
- ⚠️ CV4 — Passive runtime journal admission/settlement and business End remain unchanged outside the diff. `monitor_drain_linux.go:16` explicitly denies End authority. Root's final named journal seam review must confirm that no local observation alone permits End or ownership release.
- ⚠️ CV5 — Authenticated controlprotocol/target binding and remote-write settlement remain outside this diff. The returned observation at `monitor_drain_linux.go:77` is process-local only; Root's final protocol/target seam review and later implementation must enforce authentication, durable acceptance and remote-write completion separately.
- ⚠️ CV6 — Production PID1 namespace escalation after poison or monitor crash is not this test fallback. `monitor_drain_native_test.go:447` cannot certify a production escalation path. Root must retain closed-gate/unknown requirements until production integration verifies that path.
- ⚠️ CV7 — The final NEW-unit independent review, ordered Root rulings, tracked human-readable evidence preservation and continuing migration are controller deliverables after this task gate (`task-2-brief.md:19`). They are not complete merely because this Task 2 quality gate is approved.

### Strengths

- `internal/runtime/launcher/monitor_drain_linux.go:37`: one synchronous owner and one deferred poison/zero-observation rule make error outcomes auditable; no goroutine exists to outlive return. Final validation and fresh waiting prevent cached diagnostics from becoming terminal authority.
- `internal/runtime/launcher/monitor_process_linux.go:31`: identity-only selection avoids rejecting unrelated processes for irrelevant policy fields while direct children receive complete seal checks. The pinned-FD path and close-error precedence keep disappearance from hiding operational uncertainty.
- `internal/runtime/launcher/monitor_drain_native_test.go:395`: returned observations are compared to parent-observed real processes, terminal statuses and actual disappearance. Independent monitor-side ECHILD and repeated Drain augment the API result. This is substantial behavioral coverage, not marker-only success.
- `internal/runtime/launcher/monitor_drain_native_test.go:447`: failure cleanup preserves wait ownership and poison, and unexpected adopted users fail even when cleanup succeeds. Actual RED retains timeout/poison and successful diagnostic cleanup evidence rather than relabeling it success.
- `internal/runtime/launcher/testdata/drainclone/main.go:46`: evidence carefully distinguishes real non-SIGCHLD type before adoption, adopted termination, stale proc-handle stability, unforced PID-number reuse, native arm64, static amd64 and host race.
- Structure is proportionate: 112-line state machine, 281-line process observation/signal file, portable budget validation, separate Linux fault tests and fixed native fixture. The 602-line native test file has cohesive fixture/adversary/evidence responsibilities; size alone is not a blocking maintenance defect.

### Issues

#### Critical (Must Fix)

- None.

#### Important (Should Fix)

- None.

#### Minor (Nice to Have)

- None.

### Named outside-diff checks

- Validation/lock/seal-consumption risk: read `internal/runtime/launcher/monitor_linux.go:81` through EOF and `kernel_linux.go:1` through `:66` once. Drain's locked validator avoids recursive monitor locking, verifies poison/immutable seals, actually calls `KernelBoundary.ValidateCurrent`, and checks current seccomp/cgroup. Kernel validation actually calls `inspectKernel`, not just its prior diagnostic snapshot. Full inherited kernel/capability implementation remains CV1; kernel mutex/kernel I/O are not claimed preemptible by context.
- Competing-wait/fallback-order risk: read `internal/runtime/launcher/kernel_user_native_test.go:27` through `:160` once. `startNativeProcess` has one management `Cmd.Wait` owner; `stop` waits for its done publication before returning nil. The new group registration therefore prevents PID1 fallback from racing those management waits. User `startDrainCommand` uses actual file streams and `Process.Release`, and creates no monitor-side `Cmd.Wait` goroutine.
- No broader source crawl or unchanged journal/protocol implementation read was performed. Those cross-task checks are explicitly CV4/CV5 for the separate final unit review.

### Evidence checks performed

- Read the supplied 1736-line review package sequentially once through EOF, in four bounded chunks. No rederived git diff, git-state change, duplicate changed-file content read, mid-function source supplement, fixture creation or test execution. Required full brief, constraints, binding spec and implementation report through final canonical section were read. The first batched output truncated part of the report; its first 90 lines were then recovered explicitly. Hashing current source bytes below was evidence comparison, not a second source-code review.
- Read all six `task-2-root-{seal-red,loop-green,identity-green,descendant-red,native-green,canonical}-proof.json` files; checked underlying raw records rather than treating their booleans as sufficient proof.
- `task-2-red-host.json` and `task-2-red-linux.json`: actual exit 1 undefined-symbol/build failures. These are compile RED only. `task-2-seal-red/attach.stdout` has seven actual malformed-seal acceptances and 52 PASS/1 FAIL/0 SKIP after controlled postimplementation guard omission. `task-2-descendant-red/attach.stdout` read through EOF: real root23 zombie/leaf33 alive, omitted scan timeout, poison true, diagnostic wait33 raw9, management exit1 joined, fallback0; 0 PASS/2 FAIL/0 SKIP. Its misleading unconditional marker was historical and is guarded by `!t.Failed()` in the final diff.
- Read stored host race/vet and final repository test/vet/build full stdout/stderr/exits, Linux amd64/arm64 compile/vet command environments, and script syntax result. All GREEN exits were 0 with empty stderr. Final repository output contains 30 ok packages, eight no-test packages and 25 cached results; it proves no newly run etcd/FUSE/Redis fixture. No exact-source suite was repeated by this review.
- Independently hashed all current 28 canonical manifest entries and both saved binaries: no mismatch. All 27 launcher/helper source entries in each final repository test/vet/build record also match current bytes. Their earlier HEAD metadata is therefore compatible with the unchanged final byte set committed at35f1bc9.
- Canonical main digest `72e61d2a2b5a36ed98b947542f2bbabf9b22be07afe4a001d3361967e2d640fd`; canonical helper digest `2d17cd27a1522a0933d891078aec51bd47912170441ee3ebecd52a710c7a6f81`. Focused helper digest is separately `92d9ded2ad841ecfe5c043c74b5ebfb5771aa7ea604b04200198e046088cd68a`; retained build metadata identifies the different embedded VCS revision/time/module version, not a same-binary claim.
- Read `task-2-native-canonical/positive.log:2972` through `:3297` completely for all new adversaries/isolation cases. Actual Linux7.0.12-linuxkit/aarch64 proc observations and monitor statuses support all required native cases: 12 ECHILD oracles, 13 management joins, 11 zero-residual PID1 fallbacks; intentional cancellation cleanup reaps one raw9 while poison stays true. Parent observations check nonzero UID/GID, all zero caps, NNP1, Seccomp2/filter2 and exact cgroup. Numeric reuse was not forced.
- Independently counted whole canonical positive raw log: 1502 PASS/0 FAIL/0 SKIP and final PASS. Includes predecessor/Task1 cases, not 1502 new tests. Read all nine terminal result records: eight exit0 modes, expected inherited securebits-fatal exit2, all exited/not-running/noOOM with successful wait commands. Prior negative-mode internals were not re-reviewed; the inherited expected fatal is neither new warning noise nor an unreported failing suite.
- Read actual canonical positive creation inspection: private PID namespace, network none, user0:0, privileged false, read-only rootfs and both binaries, NNP, dropALL/add KILL/SETGID/SETUID/SETPCAP, memory67108864, pids128, NanoCpus500000000, GOMAXPROCS2 and owned labels. These are fixture settings, not production overhead measurements.
- Read complete canonical cleanup log: nine exact containers and nine exact volumes removed exit0, three owned inventories empty. Read all five focused `result.json` records: ten additional exact resource removals exit0 and every owned container/volume/network inventory successful/empty. Recomputed focused counts from raw logs: seal52/1/0, loop67/0/0, identity68/0/0, descendant0/2/0, native81/0/0. Canonical controller saved command exits0. No live-fixture restart was needed.

### Remaining unforced limitations — individually retained

- L1: Native execution is Linux arm64 on the recorded LinuxKit kernel; native amd64 is unrun, despite CGO0 amd64 compilation/vet and assembly source inspection.
- L2: Recorded race execution is Darwin host race; native Linux race remains unrun.
- L3: Forced numeric PID reuse is unrun; stale old FD ESRCH with another/fresh surviving process is the actual proof.
- L4: Non-SIGCHLD child type is verified before adoption; native omitted-WALL failure after adoption is not established and must not be claimed.
- L5: Reap/process 4096-limit tests are controlled tests, not actual 4096-process exhaustion.
- L6: Repeated fork adversary observed three completed forks under the existing 128-pid fixture; it is not a 128-task stress/exhaustion result.
- L7: Real resource exhaustion and syscall permission/I/O failures are not exhaustively forced; deterministic private fault seams cover the relevant state-machine outcomes.
- L8: Arbitrary hung kernel I/O, uninterruptible tasks, kernel-lock waits, STW or unhealthy-daemon delays are not preempted or bounded by the context.
- L9: Cancellation is deliberately triggered after actual initial validation; all possible cancellation interleavings are not exercised.
- L10: Assembly parent signal-mask-restoration denial is unforced; the code attempts restoration and reports an error, but cannot promise restoration against syscall denial.
- L11: Full ABI/x32/LSM/kernel/platform and Go-version matrix is unrun; the helper's amd64 path has no native execution in this evidence.
- L12: Foreign/manual/CGO threads remain unsupported, not silently certified by CGO0 tests.
- L13: Actual missing Linux5.9 proc fields and strict seccomp-mode environments remain inherited unforced cases.
- L14: Later-thread seccomp divergence and all-thread setter divergence breadth remain inherited limits; unchanged Task1 fatal-path evidence must be retained separately.
- L15: Exact vanished-thread retry interleavings and exhaustion remain inherited unforced cases.
- L16: Actual 4096 thread/filter resource stress remains inherited unforced coverage.
- L17: Cgroup-v1 topology breadth remains unforced.
- L18: External mount/cgroup mutation remains unforced and is subject to the trusted topology contract and fail-closed observations.
- L19: Filter counts are diagnostics rather than policy authentication; future TSYNC compatibility is not promised.
- L20: Monitor crash recovery and production PID1-wide cleanup remain downstream, as CV6 states.
- L21: Power-loss/restart recovery is not tested by these local drain cases.
- L22: Production idle/active RSS, startup latency, minimum quota and fleet throughput measurements are not established by successful fixture quotas/noOOM.
- L23: Original Task1 host/static raw transcripts were not independently available according to the inherited ledger; Root must preserve the prior attestation/limitation rather than attribute fresh Task2 transcripts to Task1.
- L24: Production target transport/start admission is not delivered here; CV2/CV3/CV5 remain separate requirements.
- L25: Journal business End and external-write settlement are not proved by local ECHILD; CV4/CV5 remain separate requirements.
- L26: Manager/Redis/FUSE migration, production image/configuration changes and final Redis removal remain outside this gate.

### Assessment

**Task quality:** Approved.

**Spec verdict:** ✅ Compliant within Task 2; CV1–CV7 remain explicit controller/integration verification obligations.

**Counts:** Critical 0 / Important 0 / Minor 0.

**Reasoning:** The bounded synchronous drainer has a clear sole-owner success condition and fails closed on operational uncertainty. The retained raw native evidence exercises the intended descendant/adoption and identity behavior without overstating architecture, resource, recovery or business-terminal guarantees; no task-scoped repair is required.
