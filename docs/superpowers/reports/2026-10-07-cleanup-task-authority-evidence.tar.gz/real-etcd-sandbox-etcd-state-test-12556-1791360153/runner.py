#!/usr/bin/env python3
"""One owned, targeted real-etcd metadata gate with full raw outcomes."""
import datetime,hashlib,json,os,pathlib,re,subprocess,sys,time
OWN=pathlib.Path(__file__).resolve().parent
ROOT=OWN.parents[2]
GO=pathlib.Path('/Users/dysodeng/go/go1.25.6/bin/go')
IMAGE='gcr.io/etcd-development/etcd:v3.6.15@sha256:5ed4e32061aa061f970d6500629213e8579ef17571dcf9789074966acb9afad1'
selector=sys.argv[1]
manifest=pathlib.Path(sys.argv[2]).resolve()
assert manifest.parent==OWN and selector.startswith('^TestTask') and selector.endswith('$')
source=json.loads(manifest.read_text())
assert source['selector']==selector
project='sandbox-etcd-state-test-'+str(os.getpid())+'-'+str(int(time.time()))
RUN=OWN/('real-etcd-'+project);RUN.mkdir()
COMPOSE=['docker','compose','--env-file','/dev/null','-p',project,'-f',str(ROOT/'testdata/etcd-state/compose.yaml'),'-f',str(OWN/'metadata-fixture.override.yaml')]
records=[];ids=[];volumes=[];networks=[];fail=None
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
 for f,h in source['sources'].items():assert sha(ROOT/f)==h, 'source changed: '+f
 assert sha(GO)==source['go_sha256']
def run(args,timeout=15,env=None,allow=False):
 start=utc(); outcome='completed'
 try:
  r=subprocess.run(args,cwd=ROOT,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
  code=r.returncode;out=r.stdout;err=r.stderr
 except subprocess.TimeoutExpired as e:
  code=None;out=e.stdout or b'';err=e.stderr or b'';out=out.decode(errors='replace') if isinstance(out,bytes) else out;err=err.decode(errors='replace') if isinstance(err,bytes) else err;outcome='timeout'
 d={'command':args,'start_utc':start,'end_utc':utc(),'exit':code,'outcome':outcome,'stdout':out,'stderr':err,'timeout_seconds':timeout}
 path=RUN/('raw-'+str(len(records)+1).zfill(3)+'.json');path.write_text(json.dumps(d,indent=2)+'\n');records.append({'path':path.name,'sha256':sha(path),'exit':code,'outcome':outcome})
 if not allow:assert code==0 and outcome=='completed', str(args)+' failed; '+str(path)
 return d
try:
 verify();(RUN/'source-manifest.json').write_bytes(manifest.read_bytes());(RUN/'runner.py').write_bytes(pathlib.Path(__file__).read_bytes());(RUN/'metadata-fixture.override.yaml').write_bytes((OWN/'metadata-fixture.override.yaml').read_bytes())
 image=json.loads(run(['docker','image','inspect',IMAGE])['stdout']);assert len(image)==1
 run(COMPOSE+['config','--format','json'])
 run(COMPOSE+['up','-d','--pull','never','--wait','--wait-timeout','90'],timeout=105)
 endpoints=[]
 for member in ['etcd-1','etcd-2','etcd-3','foreign']:
  address=run(COMPOSE+['port',member,'2379'])['stdout'].strip();assert re.fullmatch(r'127\.0\.0\.1:[0-9]+',address)
  cid=run(COMPOSE+['ps','-q',member])['stdout'].strip();assert re.fullmatch('[a-f0-9]{12,64}',cid);ids.append(cid)
  if member!='foreign':endpoints.append('http://'+address)
  else:foreign='http://'+address
 inventory=json.loads(run(['docker','inspect']+ids)['stdout']);assert len(inventory)==4
 for index,c in enumerate(inventory):
  hc=c['HostConfig'];labels=c['Config']['Labels'];ports=c['NetworkSettings']['Ports']['2379/tcp'];service=['etcd-1','etcd-2','etcd-3','foreign'][index]
  assert c['State']['Running'] and not c['State']['OOMKilled'] and labels['com.docker.compose.project']==project and labels['com.docker.compose.service']==service
  assert c['Config']['Image']==IMAGE and hc['Memory']==67108864 and hc['MemorySwap']==67108864 and hc['PidsLimit']==128 and hc['NanoCpus']==500000000
  assert hc['ReadonlyRootfs'] and not hc['Privileged'] and hc['CapDrop']==['ALL'] and not hc.get('CapAdd') and 'no-new-privileges:true' in hc['SecurityOpt']
  assert len(ports)==1 and ports[0]['HostIp']=='127.0.0.1' and not hc.get('Devices')
  expected_volume=project+'_'+service+'-data'
  assert hc.get('Binds') in (None,[],[expected_volume+':/etcd-data:rw'])
  assert len(c['Mounts'])==1
  for m in c['Mounts']:
   assert m['Type']=='volume' and m['Destination']=='/etcd-data' and m['Name']==expected_volume and m['RW'] and m['Driver']=='local';volumes.append(m['Name'])
  networks.extend(c['NetworkSettings']['Networks'])
 observed_volumes=json.loads(run(['docker','volume','inspect']+sorted(set(volumes)))['stdout'])
 assert len(observed_volumes)==4
 for v in observed_volumes:assert v['Labels']['com.docker.compose.project']==project and v['Name'] in volumes and v['Driver']=='local'
 env=os.environ.copy();env.update({'TEST_ETCD_ENDPOINTS':','.join(endpoints),'TEST_ETCD_CONTAINERS':','.join(ids[:3]),'TEST_ETCD_FOREIGN_ENDPOINT':foreign,'TEST_ETCD_FIXTURE_PROJECT':project,'GOMAXPROCS':'2','GOFLAGS':''})
 (RUN/'gate-environment.json').write_text(json.dumps({k:env[k] for k in ['TEST_ETCD_ENDPOINTS','TEST_ETCD_CONTAINERS','TEST_ETCD_FOREIGN_ENDPOINT','TEST_ETCD_FIXTURE_PROJECT','GOMAXPROCS','GOFLAGS']},indent=2)+'\n')
 run([str(GO),'env','GOOS','GOARCH','GOVERSION','CGO_ENABLED','GOFLAGS'],env=env)
 verify();d=run([str(GO),'test','-race','-count=1','-timeout=90s','-run',selector,'-v','./internal/storage/state/etcd'],timeout=110,env=env)
 assert '--- SKIP:' not in d['stdout'] and '--- FAIL:' not in d['stdout'] and '--- PASS:' in d['stdout'], 'gate must actually execute without skips'
 verify()
except BaseException as e:
 fail=repr(e)
finally:
 run(COMPOSE+['logs','--no-color'],timeout=20,allow=True)
 if ids:run(['docker','inspect']+ids,allow=True)
 cleanup=run(COMPOSE+['down','--volumes','--remove-orphans'],timeout=30,allow=True)
 if cleanup['exit']!=0:fail=fail or 'owned compose cleanup failed'
 # Verify only this exact project; never prune or inspect unrelated fixtures.
 for command in [['docker','ps','-aq','--filter','label=com.docker.compose.project='+project],['docker','volume','ls','-q','--filter','label=com.docker.compose.project='+project],['docker','network','ls','-q','--filter','label=com.docker.compose.project='+project]]:
  empty=run(command,allow=True)
  if empty['exit']!=0 or empty['stdout'].strip():fail=fail or 'own project inventory not empty'
 result={'project':project,'failure':fail,'source_manifest_sha256':sha(manifest),'records':records,'owned_ids':ids,'owned_volumes':sorted(set(volumes)),'owned_networks':sorted(set(networks)),'scope':'Darwin arm64 host Go race against actual three-member Linux etcd plus isolated foreign member; no PID1/FUSE/native Linux race or production TLS/RBAC claim'}
 (RUN/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'run':str(RUN),'failure':fail,'raw_count':len(records)},indent=2),flush=True)
if fail:sys.exit(1)
