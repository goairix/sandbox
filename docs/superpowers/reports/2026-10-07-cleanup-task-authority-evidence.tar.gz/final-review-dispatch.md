Subagent (general-purpose):
  description: "Review code changes"
  prompt: |
    You are a Senior Code Reviewer with expertise in software architecture,
    design patterns, and best practices. Your job is to review completed work
    against its plan or requirements and identify issues before they cascade.

    ## What Was Implemented

    Strict permanent cleanup records and diagnostic loads, atomic active→destroying control admission with permanent intent, original-Lease non-revivable TaskClaim and conservative checkpoint CAS. Metadata authority only; one approved master-migration unit, not full Redis replacement.

    ## Requirements / Plan

    Read docs/superpowers/specs/2026-10-07-cleanup-task-authority-design.md and docs/superpowers/plans/2026-10-07-cleanup-task-authority.md. These are this completed unit’s binding requirements. Master migration remains ongoing; for a broader interaction inspect only the named corresponding master-spec section and name the concrete risk.

    ## Git Range to Review

    **Base:** 23e4337
    **Head:** 9f31ae55319cbf8f6b69cdb7b20165a69e859ccc

    ```bash
    git diff --stat 23e4337..9f31ae55319cbf8f6b69cdb7b20165a69e859ccc
    git diff 23e4337..9f31ae55319cbf8f6b69cdb7b20165a69e859ccc
    ```

    ## The spec is a vision document

    The spec says what the software must do. It does not enumerate every
    input, environment, or condition the software will meet. For behavior
    the spec is silent on, judge by what a reasonable person using this
    software would expect: a reasonable person's expectation is a
    requirement, and a spec's silence is not permission. Grade such
    findings by their effect on that person, not by whether the spec
    mentions the trigger.

    ## Declined to judge

    Before your verdict, list every behavior you considered and set aside
    as outside the plan or spec, one line each, with the reason. The
    executor rules on each line; nothing you set aside is dropped
    silently. An empty list means you set nothing aside.

    ## Read-Only Review

    Your review is read-only on this checkout. Do not mutate the working tree, the index, HEAD, or branch state in any way. Use tools like `git show`, `git diff`, and `git log` to inspect history. If you need a working copy of a different revision, check it out into a separate temporary directory (e.g. `git worktree add /tmp/review-[SHA] [SHA]`) — never move HEAD on this checkout.

    ## You Do Not Dispatch Subagents

    Do all of this review yourself. Never spawn a subagent to review part
    of the diff, and never spawn another reviewer for a second opinion.
    This process already provides every review seat the work gets; a
    reviewer you spawn duplicates one of them at full cost, and its
    verdict counts for nothing. If the diff feels too large for one
    pass, review it in passes yourself and say so in your report.

    ## What to Check

    **Plan alignment:**
    - Does the implementation match the plan / requirements?
    - Are deviations justified improvements, or problematic departures?
    - Is all planned functionality present?

    **Code quality:**
    - Clean separation of concerns?
    - Proper error handling?
    - Type safety where applicable?
    - DRY without premature abstraction?
    - Edge cases handled?

    **Architecture:**
    - Sound design decisions?
    - Reasonable scalability and performance?
    - Security concerns?
    - Integrates cleanly with surrounding code?

    **Testing:**
    - Tests verify real behavior, not mocks?
    - Edge cases covered?
    - Integration tests where they matter?
    - All tests passing?

    **Production readiness:**
    - Migration strategy if schema changed?
    - Backward compatibility considered?
    - Documentation complete?
    - No obvious bugs?

    ## Calibration

    Categorize issues by actual severity. Not everything is Critical.
    Acknowledge what was done well before listing issues — accurate praise
    helps the implementer trust the rest of the feedback.

    If you find significant deviations from the plan, flag them specifically
    so the implementer can confirm whether the deviation was intentional.
    If you find issues with the plan itself rather than the implementation,
    say so.

    ## Output Format

    ### Strengths
    [What's well done? Be specific.]

    ### Issues

    #### Critical (Must Fix)
    [Bugs, security issues, data loss risks, broken functionality]

    #### Important (Should Fix)
    [Architecture problems, missing features, poor error handling, test gaps]

    #### Minor (Nice to Have)
    [Code style, optimization opportunities, documentation polish]

    For each issue:
    - File:line reference
    - What's wrong
    - Why it matters
    - How to fix (if not obvious)

    ### Recommendations
    [Improvements for code quality, architecture, or process]

    ### Assessment

    **Ready to merge?** [Yes | No | With fixes]

    **Reasoning:** [1-2 sentence technical assessment]

    ## Critical Rules

    **DO:**
    - Categorize by actual severity
    - Be specific (file:line, not vague)
    - Explain WHY each issue matters
    - Acknowledge strengths
    - Give a clear verdict

    **DON'T:**
    - Say "looks good" without checking
    - Mark nitpicks as Critical
    - Give feedback on code you didn't actually read
    - Be vague ("improve error handling")
    - Avoid giving a clear verdict
ACTIVE whole-new-unit review. Reused independent seat /root/launcher_kernel_bootstrap_implementation under platform-cap Ruling2, inherited most-capable model gpt-6-astra; you authored NONE of this new-unit range.
Review package: /Users/dysodeng/project/go/cloud/sandbox/.superpowers/sdd/2026-10-07-cleanup-task-authority/review-23e4337..9f31ae5.diff; contains original whole-unit BASE23e4337..wholeHead commit list/stat/full contextual diff. Consume it once rather than regenerate history. Outside-diff checks only for concrete named dependencies; do not crawl repository. Do not replay tests, launch Docker, regenerate native evidence, or use nested agents. Reports and original evidence are current unit OWN only; older completed-unit evidence must use tracked permanent artifacts, not sibling scratch.
Current OWN .superpowers/sdd/2026-10-07-cleanup-task-authority contains task-1/2/3-report.md, task-1/2/3-review.md, root-task-N-real-etcd-audit.json, raw outputs named therein. Consume full reports, exact stdout/stderr and every error/warning required to assess a finding. Source/platform/fixture ownership and cleanup gates have already run; failed history remains evidence, not a reason to regenerate passed suites.
Triage each deferred Minor from this OWN progress.md individually, plus any Task3 additions: Task1 M1 two canceled-Txn warnings, M2 eighteen metadata warnings plus one startup storage-version-update error with retired recovery/source-binary property unverified; Task2 M1 three expected LeaseRevokeNotFound client warnings plus nine matching member apply warnings, M2 sixteen configuration warnings plus one startup schema warning. Task3 actual batch warnings and initial full-run OOM/error history plus any Task3 reviewer Minors require individual triage. Three fresh same-quota batches total6top97sub/95native+2host,75raw all0; initial full run remains failed with3OOM137/3unavailable own member statuses. Read root-task-3-real-etcd-audit.json and root-task-3-log-classification.json; Ruling8 records costs and no sustained capacity proof. No severity prejudging or warning suppression. Ruling7 defines original Stage versus new TaskClaim exact fencing/deadline scope; judge implementation against spec and surface any concrete protocol gap.
Return complete report to .superpowers/sdd/2026-10-07-cleanup-task-authority/final-review.md. Every cannot-verify/declined behavior needs its own numbered statement and reason for Root disposal; no silent grouping/discard. Include explicit verdict and C/I/M counts. Physical gate closure/dual drain/remote settlement/exact termination/final owner release, production wiring/Redis removal, deployment and N-scale acceptance remain mandatory later; the current unit does not certify those. Report any interaction concern with evidence and severity, not as automatically waived.

Task3 C0/I0/M3 accepted with CV1–8 individually disposed in progress.md and tracked cleanup-task-claim-verification.md. Final triage must individually address Task3 M1 failed uninterrupted capacity, M2 11client+33apply expectedRevoke warnings, M3 48fixture baseline warnings. Read root-task-3-host-source-history-audit.json: some precommit host records differ in2later changed test files; final fault-host/vet/diff117 hashes match candidate, native gates consumed exact frozen candidate, product/build source unchanged. No test evidence is regenerated.
