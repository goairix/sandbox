import hashlib,json,pathlib,subprocess
own=pathlib.Path('.superpowers/sdd/2026-10-07-cleanup-task-authority')
worker=json.loads((own/'task-1-freeze-001/manifest.json').read_text())
root=json.loads((own/'task-1-root-freeze-002.json').read_text())
errors=[]
def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
for p,entry in worker['sources'].items():
 if sha(p)!=entry['sha256']: errors.append(['current',p])
 if sha(own/'task-1-freeze-001/sources'/p)!=entry['sha256']: errors.append(['copy',p])
 if subprocess.check_output(['git','hash-object',p],text=True).strip()!=entry['git_blob']: errors.append(['git_blob',p])
for p,expected in root['sources'].items():
 if sha(p)!=expected: errors.append(['root_current',p])
for p,expected in worker['compiler'].items():
 if sha(p)!=expected: errors.append(['compiler',p])
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
if head!=worker['head']:errors.append(['HEAD',head])
print(json.dumps({'head':head,'worker_current_copy_git_count':len(worker['sources']),'root_current_count':len(root['sources']),'compiler_count':len(worker['compiler']),'mismatches':errors},indent=2))
raise SystemExit(bool(errors))
