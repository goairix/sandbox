#!/usr/bin/env python3
"""Verify current/copied/exact-Git source and compiler custody before a gate."""
import datetime,hashlib,json,pathlib,subprocess,sys
OWN=pathlib.Path(__file__).resolve().parent;ROOT=OWN.parents[2]
MANIFEST=pathlib.Path(sys.argv[1]).resolve();assert MANIFEST.parent==OWN or MANIFEST.parent.parent==OWN
OUT=OWN/sys.argv[2];assert OUT.parent==OWN and not OUT.exists()
d=json.loads(MANIFEST.read_text());sha=lambda data:hashlib.sha256(data).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==d['head']
keys=list(d['sources']);requests=''.join(d['head']+':'+f+'\n' for f in keys).encode()
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,input=requests)
pos=0
for f in keys:
 assert not (ROOT/f).is_symlink() and not (MANIFEST.parent/'sources'/f).is_symlink()
 want=d['sources'][f];current=(ROOT/f).read_bytes();copy_path=pathlib.Path(want['copied']) if 'copied' in want else MANIFEST.parent/'sources'/f;assert copy_path.is_relative_to(OWN);copied=copy_path.read_bytes()
 end=raw.index(b'\n',pos);header=raw[pos:end].decode().split();assert len(header)==3 and header[1]=='blob',f
 size=int(header[2]);data=raw[end+1:end+1+size];pos=end+1+size;assert raw[pos:pos+1]==b'\n';pos+=1
 assert sha(data)==sha(current)==sha(copied)==want['sha256'],f
 if 'git_blob' in want:assert header[0]==want['git_blob'],f
 if 'git_sha256' in want:assert sha(data)==want['git_sha256'],f
assert pos==len(raw)
for path,v in d['compiler'].items():
 h=v['sha256'] if isinstance(v,dict) else v
 assert sha(pathlib.Path(path).read_bytes())==h,path
 if isinstance(v,dict):
  copy=pathlib.Path(v['copied']);assert copy.is_relative_to(OWN) and sha(copy.read_bytes())==h,path
expected=d.get('expected',{'top_level_pass':d.get('expected_top_pass'),'subtest_pass':d.get('expected_sub_pass'),'fail':d.get('expected_fail'),'skip':d.get('expected_skip')})
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':str(MANIFEST.relative_to(ROOT)),'manifest_sha256':sha(MANIFEST.read_bytes()),'head':d['head'],'base':d['base'],'current_copy_exact_git_sources_matched':len(keys),'compiler_matched':len(d['compiler']),'expected':expected,'command':d.get('command',d.get('suggested_command')),'go_env':d.get('go_env',d.get('environment')),'mismatches':[],'scope':'Custody only; no suite, native run or outcome regenerated.'}
OUT.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
