import subprocess,json,time,pathlib,hashlib,sys
name,*cmd=sys.argv[1:]
root=pathlib.Path.cwd();own=root/'.superpowers/sdd/2026-10-07-cleanup-task-authority'
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','internal/storage/state/etcd','go.mod','go.sum'],text=True).splitlines()
r={'command':cmd,'base':'edcbf2ff609f8542ccc5a85941bd93085c7a1971','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'go_env':subprocess.check_output(['go','env','-json','GOOS','GOARCH','GOVERSION','CGO_ENABLED','GOFLAGS'],text=True),'sources':{p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in paths if pathlib.Path(p).is_file()}}
result=subprocess.run(cmd,capture_output=True,text=True);r.update(exit=result.returncode,stdout=result.stdout,stderr=result.stderr,end_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()));(own/(name+'.json')).write_text(json.dumps(r,indent=2));print(result.stdout+result.stderr);sys.exit(result.returncode)
