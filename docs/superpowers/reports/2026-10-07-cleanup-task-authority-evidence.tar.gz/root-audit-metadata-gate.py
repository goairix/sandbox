#!/usr/bin/env python3
"""Consume a completed owned gate, preserving every raw outcome and limitation."""
import datetime, hashlib, json, pathlib, re, subprocess, sys
OWN = pathlib.Path(__file__).resolve().parent
ROOT = OWN.parents[2]
RUN = pathlib.Path(sys.argv[1]).resolve()
assert RUN.parent == OWN and RUN.name.startswith('real-etcd-sandbox-etcd-state-test-')
name = sys.argv[2]
assert re.fullmatch(r'root-task-[0-9]+(?:-batch-[a-z])?-real-etcd-audit.json', name)
expected = json.loads(pathlib.Path(sys.argv[3]).read_text())['expected']
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
result = json.loads((RUN / 'result.json').read_text())
assert result['failure'] is None
source = json.loads((RUN / 'source-manifest.json').read_text())
assert sha(RUN / 'source-manifest.json') == result['source_manifest_sha256']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == source['head']
for f, h in source['sources'].items():
    assert sha(ROOT / f) == h, f
assert sha(pathlib.Path(source['go_path'])) == source['go_sha256']
for c in source['compiler_tools'].values():
    assert sha(pathlib.Path(c['path'])) == c['sha256']
records = []
raws = []
for r in result['records']:
    p = RUN / r['path']
    assert sha(p) == r['sha256']
    d = json.loads(p.read_text())
    assert d['exit'] == r['exit'] == 0 and d['outcome'] == r['outcome'] == 'completed'
    assert isinstance(d['stdout'], str) and isinstance(d['stderr'], str)
    records.append({'file': p.name, 'sha256': sha(p), 'command': d['command'], 'start_utc': d['start_utc'], 'end_utc': d['end_utc'], 'stdout_bytes': len(d['stdout'].encode()), 'stderr_bytes': len(d['stderr'].encode())})
    raws.append(d)
assert len(list(RUN.glob('raw-*.json'))) == len(records)
tests = [d for d in raws if d['command'][1:2] == ['test']]
assert len(tests) == 1
test = tests[0]
passes = re.findall(r'^\s*--- PASS: (\S+)', test['stdout'], re.M)
tops = [s for s in passes if '/' not in s]
subs = [s for s in passes if '/' in s]
assert len(tops) == expected['top_level_pass'] and len(subs) == expected['subtest_pass']
assert not re.search(r'^\s*--- (?:FAIL|SKIP):', test['stdout'], re.M)
def structured_messages(text):
    output = []
    for line in text.splitlines():
        start = line.find('{')
        if start < 0:
            continue
        try:
            d = json.loads(line[start:])
        except json.JSONDecodeError:
            continue
        if isinstance(d, dict) and d.get('level') in ('warn', 'error', 'fatal', 'panic'):
            output.append({'original_line': line, 'message': d})
    return output
warnings = structured_messages(test['stdout'] + '\n' + test['stderr'])
logs = [d for d in raws if 'logs' in d['command']]
assert len(logs) == 1
metadata = structured_messages(logs[0]['stdout'] + '\n' + logs[0]['stderr'])
image = 'gcr.io/etcd-development/etcd:v3.6.15@sha256:5ed4e32061aa061f970d6500629213e8579ef17571dcf9789074966acb9afad1'
inspects = [d for d in raws if d['command'][:2] == ['docker', 'inspect']]
assert len(inspects) == 2
custody = []
for d in inspects:
    objects = json.loads(d['stdout'])
    assert len(objects) == 4
    for i, c in enumerate(objects):
        service = ['etcd-1', 'etcd-2', 'etcd-3', 'foreign'][i]
        hc, labels = c['HostConfig'], c['Config']['Labels']
        assert c['Id'] == result['owned_ids'][i]
        assert labels['com.docker.compose.project'] == result['project'] and labels['com.docker.compose.service'] == service
        assert c['State']['Running'] and not c['State']['OOMKilled'] and c['State']['Health']['Status'] == 'healthy'
        assert c['Config']['Image'] == image
        assert hc['Memory'] == hc['MemorySwap'] == 67108864 and hc['PidsLimit'] == 128 and hc['NanoCpus'] == 500000000
        assert hc['ReadonlyRootfs'] and not hc['Privileged'] and hc['CapDrop'] == ['ALL'] and not hc.get('CapAdd') and 'no-new-privileges:true' in hc['SecurityOpt'] and not hc.get('Devices')
        ports = c['NetworkSettings']['Ports']['2379/tcp']
        assert len(ports) == 1 and ports[0]['HostIp'] == '127.0.0.1'
        v = result['project'] + '_' + service + '-data'
        assert hc.get('Binds') in (None, [], [v + ':/etcd-data:rw'])
        assert len(c['Mounts']) == 1
        m = c['Mounts'][0]
        assert m['Type'] == 'volume' and m['Name'] == v and m['Destination'] == '/etcd-data' and m['RW'] and m['Driver'] == 'local'
        custody.append({'service': service, 'id': c['Id'], 'health': c['State']['Health']['Status'], 'OOMKilled': c['State']['OOMKilled'], 'quota': {'memory': hc['Memory'], 'cpu': hc['NanoCpus'], 'pids': hc['PidsLimit']}, 'owned_volume': v})
volumes = [d for d in raws if d['command'][:3] == ['docker', 'volume', 'inspect']]
assert len(volumes) == 1
volume_objects = json.loads(volumes[0]['stdout'])
assert len(volume_objects) == 4
for v in volume_objects:
    assert v['Name'] in result['owned_volumes'] and v['Labels']['com.docker.compose.project'] == result['project'] and v['Driver'] == 'local'
status_raws = [d for d in raws if d['command'][:2] == ['docker', 'exec']]
assert len(status_raws) == 4
statuses = []
for i, d in enumerate(status_raws):
    assert d['command'][2] == result['owned_ids'][i]
    parsed = json.loads(d['stdout'])
    assert len(parsed) == 1 and parsed[0]['Endpoint'] == 'http://127.0.0.1:2379'
    status = parsed[0]['Status']
    assert status['version'] == '3.6.15' and status['header']['member_id'] > 0 and status['header']['cluster_id'] > 0
    statuses.append({'container_id': d['command'][2], 'observed': status})
assert len({s['observed']['header']['cluster_id'] for s in statuses[:3]}) == 1
assert len({s['observed']['header']['member_id'] for s in statuses[:3]}) == 3
assert statuses[3]['observed']['header']['cluster_id'] != statuses[0]['observed']['header']['cluster_id']
cleanup = [d for d in raws if 'down' in d['command']]
assert len(cleanup) == 1
for d in raws[-3:]:
    assert d['stdout'] == d['stderr'] == '' and 'label=com.docker.compose.project=' + result['project'] in d['command']
out = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'run': str(RUN.relative_to(ROOT)), 'head': source['head'], 'raw_records': records, 'all_raw_exit0': True, 'source_manifest_sha256': result['source_manifest_sha256'], 'all_current_source_hashes_match': len(source['sources']), 'compiler_hashes_match': 3, 'top_level_pass': tops, 'subtest_pass': subs, 'fail': 0, 'skip': 0, 'test_warnings': warnings, 'metadata_warnings': metadata, 'test_stderr': test['stderr'], 'metadata_stderr': logs[0]['stderr'], 'actual_member_statuses': statuses, 'status_limit': 'These observed fresh fixture members only. Does not retroactively certify retired Task1 recovery, source/binary mapping, snapshot/upgrade/downgrade correctness, production security/failover or whole cluster health.', 'custody_pre_post': custody, 'exact_project_cleanup_exit0': True, 'exact_project_container_volume_network_empty': True, 'scope': result['scope']}
p = OWN / name
assert not p.exists()
p.write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'audit': str(p), 'sha256': sha(p), 'raw_count': len(records), 'sources': len(source['sources']), 'top_pass': len(tops), 'sub_pass': len(subs), 'test_warnings': len(warnings), 'metadata_warnings': len(metadata), 'storageVersions': [s['observed'].get('storageVersion') for s in statuses], 'cleanup_empty': True}, indent=2))
