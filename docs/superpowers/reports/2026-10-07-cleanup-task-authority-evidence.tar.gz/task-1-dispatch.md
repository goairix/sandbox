You are implementing Task 1: Strict permanent cleanup task records and owned diagnostic reads

## Task Description

Read your task brief first: /Users/dysodeng/project/go/cloud/sandbox/.superpowers/sdd/2026-10-07-cleanup-task-authority/task-1-brief.md
It contains the full task text from the plan.

## Context

This is the first task of the approved master migration’s next required cleanup metadata unit. BASE edcbf2f. Your current author role is new and fully scoped despite retaining a completed seat; platform cap/model inherited cost is recorded in Ruling2. You implement only the five named Task1 files, strict records/keys and readonly loads. Task2 will close admission and Task3 will claim/update; do not implement those now. No Root product edit or nested agent.

The brief is your full Task1 requirements with exact interfaces. Do not read the whole plan or any previous/sibling/deleted scratch. Existing relevant seams: domain_records.go strict codec, preparation_records.go/strictPreparationMetadata (locate actual helper via rg), stage_attempt.go StageAttemptLocator, domain_read.go readDomain/identity, namespace.go. No existing production codec relaxation. Self-review before each prompt coherent commit. “Full suite once” in general template is scoped to necessary checks for this task, not repeating unchanged kernel/native/prior repository gates. Preserve every warning/failed run as attributed; not-pristine evidence is disclosed, not suppressed.

Root owns actual fixture launch. Focused host tests may report actual integration SKIP when no endpoints, but do not call them real-etcd acceptance. Once source/test scope is ready, propose exact current source snapshot/covering real3member selectors to Root, remain frozen until its consumed gate/cleanup. Root will run only targeted selectors, including existing relevant checks if new changes actually justify them. Never launch Docker, read .env/secrets, broaden endpoints, weaken three-member checks, install dependencies, or fake a capability. Go1.25.6 already installed. Full raw argv/UTC/environment/stdout/stderr/exit/source hashes in OWN, behavioral RED not compile-only; all reports through EOF.

Binding constraints verbatim:

- Branch `codex/etcd-state-management`; small verified/self-reviewed commits promptly; no push/merge/deploy. Never read/touch/stage unrelated `docs/superpowers/plans/2026-09-17-sentinel-kubernetes-129-compatibility.md`.
- Own scratch `.superpowers/sdd/2026-10-07-cleanup-task-authority/` only; completed predecessor evidence via tracked artifacts only, never sibling/deleted scratch.
- Only actually claimed tasks acquire Lease; no per-idle-sandbox client/goroutine/timer/ticker/Watch, no control/owner TTL, no new dependencies or production Manager/backend selection changes.
- Permanent records Lease0; task/intent/link immutable CreateRevision==ModRevision, mutable checkpoint ModRevision>=CreateRevision>0; current restore identity and exact original runtime/owner/control must be compared. Claim/guard use original Lease and exact value/LeaseValue/CreateRevision/ModRevision; never rebuild an old claim or manufacture authority from diagnostic references.
- Existing Stage transaction budget64 operations, record64KiB and mutation256KiB remain; new task/intent4096, link2048, checkpoint4096 and claim4096-byte hard limits. Strict JSON rejects unknown/duplicate/omitted/null/trailing/nonUTF8 fields atomically.
- ttl in(0,24h], rounded up seconds; conservative monotonic grant/renew send-time deadline. Unknown/cancel/loss remains fail closed; permanent state is retained.
- Metadata checkpoint only pending/needs_reconciliation. No runtime call, closed-gate/remote settlement/End authority, owner/index/control deletion, legal reopen or age-only GC.
- Real etcd evidence uses owned isolated pinned local fixtures; worker never launches Docker or reads real .env/secrets. Root coordinates exact fixture inventory/cleanup and frozen-source consumption. Host static/compile/skip results must not be called real etcd or Linux runtime evidence.


Selected Task1 binding spec, verbatim:

所有 key 均在当前 Namespace/cell，partition 来自 workspace hash 首字节。使用：

- `p/<partition>/tasks/<canonical-task-UUID>`：不可改写的 TaskRecord。
- `p/<partition>/cleanup-intents/<canonical-task-UUID>`：不可改写的 CleanupIntentRecord。
- `p/<partition>/sandboxes/<sandboxID>/cleanup-task`：不可改写的 TaskLinkRecord，阻止一个 runtime 并行创建两个 cleanup 意图。
- `p/<partition>/tasks/<taskID>/claim`：当前 task Lease 下的固定 claim。
- `p/<partition>/tasks/<taskID>/guards/<claimID>`：同一 Lease 下不可重建的固定 guard。
- `p/<partition>/tasks/<taskID>/checkpoint`：永久元数据 checkpoint，不能承载实际输出或自行证明物理阶段。

TaskReference 包含 Namespace、RestoreEpoch、TaskID、Partition、SandboxID，仅供定位/诊断。TaskRecord 固定 version1、kind=`cleanup`，绑定 WorkspaceHash、CreationIntentID、Generation、DataGateEpoch、完整 RuntimeReference、SnapshotReference、ExpiresAt 与销毁前 ControlRevision。CleanupIntentRecord 绑定同一 TaskReference 和同一 tuple；TaskLinkRecord 绑定完整 TaskReference。所有记录必须严格 UTF-8/JSON，拒绝未知、重复、遗漏字段、null、尾随 JSON、错误租约/身份/版本与大小超限。TaskRecord/intent 各4096字节，link2048字节；这三个不可改写的永久记录 Lease0、CreateRevision>0、ModRevision==CreateRevision。checkpoint 同为永久 Lease0，但可由合法 CAS 更新，因此 CreateRevision>0、ModRevision>=CreateRevision，硬上限4096字节。decode 失败不改写调用者目标。LoadTask 只返回拥有的副本，不返回 live capability。


Root clarifications: Task/intent/link must be immutable unleased with Mod==Create, checkpoint allows Mod>=Create and remains unleased. Strict validation of nested attempt binds its Namespace/RestoreEpoch/Partition to the reference. Initial checkpoint emptyClaimID/DetailDigest; subsequent diagnostic record requires canonicalUUID+SHA256, still no authority. TaskRecord runtime field is a value and returned records independently owned. New LoadTask/Checkpoint identity is current Backend namespace/restore, absent result nil only exact successful coherent read. No claim/replay/destroy/release/update API in Task1. Report actual integration gaps explicitly pendingRootfixture, never DONE claim of missing realgate.


## Before You Begin

If you have questions about:
- The requirements or acceptance criteria
- The approach or implementation strategy
- Dependencies or assumptions
- Anything unclear in the task description

**Ask them now.** Raise any concerns before starting work.

## Your Job

Once you're clear on requirements:
1. Implement exactly what the task specifies
2. Write tests (following TDD if task says to)
3. Verify implementation works
4. Commit your work
5. Self-review (see below)
6. Report back

Work from: /Users/dysodeng/project/go/cloud/sandbox

**While you work:** If you encounter something unexpected or unclear, **ask questions**.
It's always OK to pause and clarify. Don't guess or make assumptions.

While iterating, run the focused test for what you're changing; run the
full suite once before committing, not after every edit.

## You Do Not Dispatch Subagents

Do all of this task's work yourself. Never spawn a subagent to
implement part of the task, and above all never spawn a reviewer to
check your work. Self-review (below) means reading your own diff.
Review is the controller's job: after you report, it dispatches a
fresh reviewer against your diff. A reviewer you spawn duplicates
that review at full cost, and its approval counts for nothing in
the process. If you catch yourself thinking "an independent review
would strengthen my report" — that review is already scheduled.
Report instead.

## Code Organization

You reason best about code you can hold in context at once, and your edits are more
reliable when files are focused. Keep this in mind:
- Follow the file structure defined in the plan
- Each file should have one clear responsibility with a well-defined interface
- If a file you're creating is growing beyond the plan's intent, stop and report
  it as DONE_WITH_CONCERNS — don't split files on your own without plan guidance
- If an existing file you're modifying is already large or tangled, work carefully
  and note it as a concern in your report
- In existing codebases, follow established patterns. Improve code you're touching
  the way a good developer would, but don't restructure things outside your task.

## When You're in Over Your Head

It is always OK to stop and say "this is too hard for me." Bad work is worse than
no work. You will not be penalized for escalating.

**STOP and escalate when:**
- The task requires architectural decisions with multiple valid approaches
- You need to understand code beyond what was provided and can't find clarity
- You feel uncertain about whether your approach is correct
- The task involves restructuring existing code in ways the plan didn't anticipate
- You've been reading file after file trying to understand the system without progress

**How to escalate:** Report back with status BLOCKED or NEEDS_CONTEXT. Describe
specifically what you're stuck on, what you've tried, and what kind of help you need.
The controller can provide more context, re-dispatch with a more capable model,
or break the task into smaller pieces.

## Before Reporting Back: Self-Review

Review your work with fresh eyes. Ask yourself:

**Completeness:**
- Did I fully implement everything in the spec?
- Did I miss any requirements?
- Are there edge cases I didn't handle?

**Quality:**
- Is this my best work?
- Are names clear and accurate (match what things do, not how they work)?
- Is the code clean and maintainable?

**Discipline:**
- Did I avoid overbuilding (YAGNI)?
- Did I only build what was requested?
- Did I follow existing patterns in the codebase?

**Testing:**
- Do tests actually verify behavior (not just mock behavior)?
- Did I follow TDD if required?
- Are tests comprehensive?
- Is the test output pristine (no stray warnings or noise)?

If you find issues during self-review, fix them now before reporting.

## After Review Findings

If the task review finds issues, you will be resumed with the findings.
Fix them, re-run the tests that cover the amended code, and append a fix
report to your report file: what you changed, the covering tests you
ran, the command, and the output. Reviewers will not re-run tests for
you — your report is the test evidence. Then reply with the same short
status contract as your first report.

## Report Format

Write your full report to /Users/dysodeng/project/go/cloud/sandbox/.superpowers/sdd/2026-10-07-cleanup-task-authority/task-1-report.md:
- What you implemented (or what you attempted, if blocked)
- What you tested and test results
- **TDD Evidence** (if TDD was required for this task):
  - RED: command run, relevant failing output before implementation, and why the failure was expected
  - GREEN: command run and relevant passing output after implementation
- Files changed
- Self-review findings (if any)
- Any issues or concerns

Then report back with ONLY (under 15 lines — the detail lives in the
report file):
- **Status:** DONE | DONE_WITH_CONCERNS | BLOCKED | NEEDS_CONTEXT
- Commits created (short SHA + subject)
- One-line test summary (e.g. "14/14 passing, output pristine")
- Your concerns, if any
- The report file path

If BLOCKED or NEEDS_CONTEXT, put the specifics in the final message
itself — the controller acts on it directly.

Use DONE_WITH_CONCERNS if you completed the work but have doubts about correctness.
Use BLOCKED if you cannot complete the task. Use NEEDS_CONTEXT if you need
information that wasn't provided. Never silently produce work you're unsure about.