#!/usr/bin/env python3
"""Seal completed unit evidence; no workspace deletion or Git mutation."""
import hashlib,io,json,pathlib,subprocess,tarfile
OWN=pathlib.Path(__file__).resolve().parent
ROOT=OWN.parents[2]
DEST=ROOT/'docs/superpowers/reports/2026-10-07-cleanup-task-authority-evidence.tar.gz'
assert not DEST.exists()
for name in ['task-1-report.md','task-2-report.md','task-3-report.md','task-1-review.md','task-2-review.md','task-3-review.md','final-review.md']:
 assert (OWN/name).is_file(),name
ledger=(OWN/'progress.md').read_text()
for task in [1,2,3]:
 assert f'Task {task}: complete' in ledger,task
assert 'Final unit gate: accepted' in ledger
files=sorted(p for p in OWN.rglob('*') if p.is_file())
assert not any(p.is_symlink() for p in OWN.rglob('*'))
def sha(data):return hashlib.sha256(data).hexdigest()
manifest={str(p.relative_to(OWN)):{'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files}
assert 'ARCHIVE-MANIFEST.json' not in manifest
raw=json.dumps({'unit':'cleanup-task-authority','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'members':manifest},sort_keys=True,indent=2).encode()+b'\n'
with tarfile.open(DEST,'w:gz') as tar:
 for p in files:
  data=p.read_bytes();assert sha(data)==manifest[str(p.relative_to(OWN))]['sha256']
  tar.add(p,arcname=str(p.relative_to(OWN)),recursive=False)
 info=tarfile.TarInfo('ARCHIVE-MANIFEST.json');info.size=len(raw);info.mode=0o644
 tar.addfile(info,io.BytesIO(raw))
with tarfile.open(DEST,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(manifest)+1
 assert {m.name for m in members}==set(manifest)|{'ARCHIVE-MANIFEST.json'}
 for m in members:
  assert m.isfile()
  data=tar.extractfile(m).read()
  if m.name=='ARCHIVE-MANIFEST.json':assert data==raw
  else:assert len(data)==manifest[m.name]['size'] and sha(data)==manifest[m.name]['sha256']
print(json.dumps({'archive':str(DEST),'sha256':sha(DEST.read_bytes()),'bytes':DEST.stat().st_size,'verified_members':len(manifest)+1,'manifest_sha256':sha(raw),'workspace_retained_until_exhaustive_human_rulings_publication':True},indent=2))
