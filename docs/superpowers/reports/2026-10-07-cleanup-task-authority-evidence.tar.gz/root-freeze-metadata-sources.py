#!/usr/bin/env python3
import datetime,hashlib,json,pathlib,subprocess,sys
OWN=pathlib.Path(__file__).resolve().parent;ROOT=OWN.parents[2];GO=pathlib.Path('/Users/dysodeng/go/go1.25.6/bin/go')
selector=sys.argv[1];name=sys.argv[2];assert name.startswith('task-') and name.endswith('.json') and '/' not in name
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\x00');files={f for f in tracked if f and (f.endswith('.go') or f in ['go.mod','go.sum','testdata/etcd-state/compose.yaml','scripts/test-etcd-state.sh'])}
files.update(str(f.relative_to(ROOT)) for f in (ROOT/'internal/storage/state/etcd').glob('task*.go'))
if len(sys.argv)>3:
 worker=pathlib.Path(sys.argv[3]).resolve();assert worker.parent==OWN or worker.parent.parent==OWN
 files.update(json.loads(worker.read_text())['sources'])
files.update(str(f.relative_to(ROOT)) for f in [OWN/'root-metadata-gate.py',OWN/'metadata-fixture.override.yaml'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
toolenv=subprocess.check_output([str(GO),'env','GOOS','GOARCH','GOVERSION','GOROOT','CGO_ENABLED','GOFLAGS'],text=True,cwd=ROOT)
goroot=pathlib.Path(toolenv.splitlines()[3]);toolchain={}
for tool in ['compile','link']:
 path=goroot/'pkg/tool/darwin_arm64'/tool;toolchain[tool]={'path':str(path),'sha256':sha(path)}
out={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'selector':selector,'go_path':str(GO),'go_sha256':sha(GO),'go_env':toolenv,'compiler_tools':toolchain,'sources':{f:sha(ROOT/f) for f in sorted(files)},'scope':'host Darwin arm64 race against real owned3member etcd; original immutable source freeze, no runtime ELF/nativeLinux claim'}
path=OWN/name;assert not path.exists();path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'manifest':str(path),'sha256':sha(path),'head':out['head'],'sources':len(files)},indent=2))
