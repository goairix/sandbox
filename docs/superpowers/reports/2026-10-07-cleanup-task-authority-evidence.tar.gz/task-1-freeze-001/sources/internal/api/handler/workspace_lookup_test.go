package handler

import (
	"fmt"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/goairix/sandbox/internal/sandbox"
	"github.com/stretchr/testify/require"
)

func TestWorkspaceLookupErrorCodes(t *testing.T) {
	for _, tc := range []struct {
		err    error
		status int
		code   string
	}{
		{sandbox.ErrWorkspaceLookupConflict, 409, "WORKSPACE_SANDBOX_CONFLICT"},
		{sandbox.ErrWorkspaceLookupAmbiguous, 409, "WORKSPACE_SANDBOX_AMBIGUOUS"},
		{sandbox.ErrWorkspaceLookupUnavailable, 503, "WORKSPACE_LOOKUP_UNAVAILABLE"},
	} {
		t.Run(tc.code, func(t *testing.T) {
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			c.Request = httptest.NewRequest("GET", "/api/v1/sandboxes/by-workspace", nil)
			internalError(c, fmt.Errorf("lookup: %w", tc.err))
			require.Equal(t, tc.status, w.Code)
			require.Contains(t, w.Body.String(), tc.code)
		})
	}
}

func TestWorkspaceLookupConflictDetails(t *testing.T) {
	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	c.Request = httptest.NewRequest("GET", "/api/v1/sandboxes/by-workspace", nil)
	internalError(c, &sandbox.WorkspaceLookupConflict{Reason: "sandbox_record_missing", SandboxID: "sandbox-old"})
	require.Equal(t, 409, w.Code)
	require.Contains(t, w.Body.String(), `"reason":"sandbox_record_missing"`)
	require.Contains(t, w.Body.String(), `"sandbox_id":"sandbox-old"`)
	require.Contains(t, w.Body.String(), `"code":"WORKSPACE_SANDBOX_CONFLICT"`)
}

func TestWorkspaceRecoveryIsAnOperationalFailure(t *testing.T) {
	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	c.Request = httptest.NewRequest("POST", "/api/v1/sandboxes", nil)
	err := fmt.Errorf("%w: %w", sandbox.ErrWorkspaceRecoveryRequired, &sandbox.WorkspaceLookupConflict{Reason: "sandbox_record_missing", SandboxID: "sandbox-old"})
	internalError(c, err)
	require.Equal(t, 503, w.Code)
	require.Contains(t, w.Body.String(), `"code":"WORKSPACE_RECOVERY_REQUIRED"`)
	require.Contains(t, w.Body.String(), `"reason":"sandbox_record_missing"`)
	require.Contains(t, w.Body.String(), `"sandbox_id":"sandbox-old"`)
}
