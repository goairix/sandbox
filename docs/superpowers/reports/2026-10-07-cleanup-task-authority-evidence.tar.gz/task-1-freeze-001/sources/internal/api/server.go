package api

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
)

// Server wraps the HTTP server with graceful shutdown.
type Server struct {
	engine     *gin.Engine
	httpServer *http.Server
}

// NewServer creates a new API server.
func NewServer(engine *gin.Engine, host string, port int) *Server {
	return &Server{
		engine: engine,
		httpServer: &http.Server{
			Addr:              fmt.Sprintf("%s:%d", host, port),
			Handler:           engine,
			ReadTimeout:       30 * time.Second,
			WriteTimeout:      120 * time.Second, // longer for SSE
			ReadHeaderTimeout: 10 * time.Second,
			IdleTimeout:       120 * time.Second,
		},
	}
}

// Start starts the HTTP server.
func (s *Server) Start() error {
	return s.httpServer.ListenAndServe()
}

// Stop gracefully shuts down the server.
func (s *Server) Stop(ctx context.Context) error {
	shutdownCtx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	if err := s.httpServer.Shutdown(shutdownCtx); err != nil {
		return errors.Join(err, s.httpServer.Close())
	}
	return nil
}
