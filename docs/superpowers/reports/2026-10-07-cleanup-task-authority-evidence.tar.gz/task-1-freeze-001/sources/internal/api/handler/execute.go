package handler

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"

	"github.com/goairix/sandbox/internal/logger"
	"github.com/goairix/sandbox/internal/runtime"
	"github.com/goairix/sandbox/internal/sandbox"
	"github.com/goairix/sandbox/internal/telemetry/trace"
	"github.com/goairix/sandbox/pkg/types"
)

func (h *Handler) ExecuteOneShot(c *gin.Context) {
	spanCtx, span := trace.Tracer().Start(trace.Gin(c), "api.execute.ExecuteOneShot")
	defer span.End()

	var req types.ExecuteRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, types.ErrorResponse{
			Message: err.Error(),
		})
		return
	}

	if !isValidLanguage(req.Language) {
		c.JSON(http.StatusBadRequest, types.ErrorResponse{
			Message: "invalid language, must be one of: python, nodejs, bash",
		})
		return
	}

	ctx := spanCtx

	// Create ephemeral sandbox
	cfg := sandbox.SandboxConfig{
		Mode:    sandbox.ModeEphemeral,
		Timeout: req.Timeout,
	}
	if req.Resources != nil {
		cfg.Resources = resourceLimitsFromRequest(req.Resources)
	}
	if req.Network != nil {
		cfg.Network = sandbox.NetworkConfig{
			Enabled:   req.Network.Enabled,
			Whitelist: req.Network.Whitelist,
		}
	}
	for _, dep := range req.Dependencies {
		cfg.Dependencies = append(cfg.Dependencies, sandbox.Dependency{
			Name:    dep.Name,
			Version: dep.Version,
			Manager: dep.Manager,
		})
	}

	sb, err := h.manager.Create(ctx, cfg)
	if err != nil {
		internalError(c, err)
		return
	}
	defer func() { _ = h.scheduleOneShotCleanup(ctx, sb.ID) }()

	// Build command from language and code
	command, err := buildCommand(sandbox.Language(req.Language), req.Code)
	if err != nil {
		c.JSON(http.StatusBadRequest, types.ErrorResponse{
			Message: err.Error(),
		})
		return
	}

	// Execute
	result, err := h.manager.Exec(ctx, sb.ID, runtime.ExecRequest{
		Command:         command,
		Stdin:           req.Stdin,
		Timeout:         req.Timeout,
		Env:             req.Env,
		LineBuffered:    req.LineBuffered,
		RequiresNetwork: req.RequiresNetwork,
	})
	if err != nil {
		if errors.Is(err, sandbox.ErrNetworkRequired) {
			c.JSON(http.StatusForbidden, types.ErrorResponse{Message: err.Error()})
			return
		}
		internalError(c, err)
		return
	}

	if err := h.scheduleOneShotCleanup(ctx, sb.ID); err != nil {
		internalError(c, errors.Join(sandbox.ErrSandboxCleanupPending, err))
		return
	}
	c.JSON(http.StatusOK, types.ExecResponse{
		ExitCode: result.ExitCode,
		Stdout:   result.Stdout,
		Stderr:   result.Stderr,
		Duration: result.Duration.Seconds(),
	})
}

func (h *Handler) ExecuteOneShotStream(c *gin.Context) {
	spanCtx, span := trace.Tracer().Start(trace.Gin(c), "api.execute.ExecuteOneShotStream")
	defer span.End()

	var req types.ExecuteRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, types.ErrorResponse{
			Message: err.Error(),
		})
		return
	}

	if !isValidLanguage(req.Language) {
		c.JSON(http.StatusBadRequest, types.ErrorResponse{
			Message: "invalid language, must be one of: python, nodejs, bash",
		})
		return
	}

	ctx := spanCtx

	cfg := sandbox.SandboxConfig{
		Mode:    sandbox.ModeEphemeral,
		Timeout: req.Timeout,
	}
	if req.Resources != nil {
		cfg.Resources = resourceLimitsFromRequest(req.Resources)
	}

	sb, err := h.manager.Create(ctx, cfg)
	if err != nil {
		internalError(c, err)
		return
	}
	defer func() { _ = h.scheduleOneShotCleanup(ctx, sb.ID) }()

	// Build command from language and code
	command2, err := buildCommand(sandbox.Language(req.Language), req.Code)
	if err != nil {
		c.JSON(http.StatusBadRequest, types.ErrorResponse{
			Message: err.Error(),
		})
		return
	}

	ch, err := h.manager.ExecStream(ctx, sb.ID, runtime.ExecRequest{
		Command:         command2,
		Stdin:           req.Stdin,
		Timeout:         req.Timeout,
		Env:             req.Env,
		LineBuffered:    req.LineBuffered,
		RequiresNetwork: req.RequiresNetwork,
	})
	if err != nil {
		if errors.Is(err, sandbox.ErrNetworkRequired) {
			c.JSON(http.StatusForbidden, types.ErrorResponse{Message: err.Error()})
			return
		}
		internalError(c, err)
		return
	}

	c.Header("Content-Type", "text/event-stream")
	c.Header("Cache-Control", "no-cache")
	c.Header("Connection", "keep-alive")
	c.Header("X-Accel-Buffering", "no")

	start := time.Now()
	flusher, _ := c.Writer.(http.Flusher)
	rc := http.NewResponseController(c.Writer)
	// net/http writes the final chunk after this handler returns. A deadline
	// used for heartbeats must not leak into HTTP stream finalization.
	defer func() { _ = rc.SetWriteDeadline(time.Time{}) }()

	// Heartbeat ticker to prevent timeout during silent periods
	heartbeatInterval := 10 * time.Second
	writeDeadline := 2 * heartbeatInterval
	ticker := time.NewTicker(heartbeatInterval)
	defer ticker.Stop()

	// Extend write deadline before first wait
	_ = rc.SetWriteDeadline(time.Now().Add(writeDeadline))

	for {
		select {
		case <-c.Request.Context().Done():
			// Client disconnected
			return
		case <-ticker.C:
			// Extend write deadline before sending heartbeat
			_ = rc.SetWriteDeadline(time.Now().Add(writeDeadline))
			// Send heartbeat ping event
			pingData := types.SSEPingData{Timestamp: time.Now().Unix()}
			jsonData, _ := json.Marshal(pingData)
			if _, err := fmt.Fprintf(c.Writer, "event: ping\ndata: %s\n\n", jsonData); err != nil {
				return
			}
			if flusher != nil {
				flusher.Flush()
			}
		case event, ok := <-ch:
			if !ok {
				// Channel closed
				return
			}

			var eventType string
			var data any

			switch event.Type {
			case runtime.StreamStdout:
				eventType = "stdout"
				data = types.SSEStdoutData{Content: event.Content}
			case runtime.StreamStderr:
				eventType = "stderr"
				data = types.SSEStderrData{Content: event.Content}
			case runtime.StreamDone:
				eventType = "done"
				exitCode, err := strconv.Atoi(event.Content)
				if err != nil {
					logger.Warn(c.Request.Context(), "failed to parse exit code",
						logger.AddField("raw_value", event.Content),
						logger.ErrorField(err),
					)
					exitCode = -1
				}
				data = types.SSEDoneData{
					ExitCode: exitCode,
					Elapsed:  time.Since(start).Seconds(),
				}
				if cleanupErr := h.scheduleOneShotCleanup(ctx, sb.ID); cleanupErr != nil {
					eventType = "error"
					data = types.SSEErrorData{Error: "cleanup_pending", Message: "execution finished but durable cleanup could not be confirmed"}
				}
			case runtime.StreamError:
				eventType = "error"
				data = streamErrorData(event.Content)
			default:
				// Unknown event type, skip
				logger.Warn(c.Request.Context(), "unknown stream event type",
					logger.AddField("event_type", event.Type),
				)
				continue
			}

			// Extend write deadline before sending event
			_ = rc.SetWriteDeadline(time.Now().Add(writeDeadline))

			jsonData, err := json.Marshal(data)
			if err != nil {
				logger.Error(c.Request.Context(), "failed to marshal SSE data",
					logger.AddField("event_type", eventType),
					logger.ErrorField(err),
				)
				errData := types.SSEErrorData{Error: "marshal_error", Message: "failed to serialize event"}
				jsonData, _ = json.Marshal(errData)
				eventType = "error"
			}
			if _, err := fmt.Fprintf(c.Writer, "event: %s\ndata: %s\n\n", eventType, jsonData); err != nil {
				return
			}
			if flusher != nil {
				flusher.Flush()
			}
			if event.Type == runtime.StreamDone || event.Type == runtime.StreamError {
				return
			}
		}
	}
}

func (h *Handler) scheduleOneShotCleanup(ctx context.Context, id string) error {
	cleanupCtx := context.WithoutCancel(ctx)
	if err := h.manager.ScheduleDestroy(cleanupCtx, id); err != nil {
		logger.Error(cleanupCtx, "one-shot cleanup could not be scheduled",
			logger.AddField("sandbox_id", id), logger.ErrorField(err))
		return err
	}
	return nil
}
