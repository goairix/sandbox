package docker

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"sort"
	"strings"
	"time"

	"github.com/docker/docker/api/types/container"
	"github.com/docker/docker/api/types/filters"
	dnetwork "github.com/docker/docker/api/types/network"
	dockerclient "github.com/docker/docker/client"

	"github.com/goairix/sandbox/internal/imageref"
	"github.com/goairix/sandbox/internal/runtime"
)

// createFUSESandboxPair creates the fail-closed Docker network used by a
// prepared FUSE runtime. The sandbox-facing bridge must remain routable because
// Docker internal bridges drop transit packets before they enter a container
// acting as a layer-3 gateway. The gateway policy is loaded before the trusted
// versioned runtime starts; its default route is then replaced with the
// gateway address before any workspace authorization or public exec.
func createFUSESandboxPair(ctx context.Context, cli dockerAPI, sandboxID, openNetworkID, gatewayImage, secretRoot, caSecretKey string, system runtime.SystemEgressSpec) (pairNetworkID, gatewayID, gatewayIP string, err error) {
	if system.Mode != runtime.SystemEgressCIDR {
		return "", "", "", fmt.Errorf("docker workspace FUSE supports only CIDR system egress")
	}
	if !imageref.IsRelease(gatewayImage) {
		return "", "", "", fmt.Errorf("docker gateway image must use a vMAJOR.MINOR.PATCH tag or valid sha256 digest")
	}
	if !validDockerWorkspaceSecretRoot(secretRoot) {
		return "", "", "", fmt.Errorf("docker workspace FUSE secret root is invalid")
	}
	command, err := buildFUSEGatewayIptablesCmd(system, false, nil, false)
	if err != nil {
		return "", "", "", err
	}
	pairNetName := dockerFUSEPairNetworkName(sandboxID)
	ipv6Disabled := false
	netResp, err := createManagedPairNetwork(ctx, cli, pairNetName, dnetwork.CreateOptions{
		Driver: "bridge", Attachable: true, EnableIPv6: &ipv6Disabled,
		Labels: map[string]string{"sandbox.managed": "true", "sandbox.id": sandboxID, "sandbox.role": "fuse-pair", dockerSecretRootLabel: secretRoot, dockerCASecretKeyLabel: caSecretKey},
	}, time.Now())
	if err != nil {
		return "", "", "", fmt.Errorf("create FUSE pair network: %w", err)
	}
	pairNetworkID = netResp.ID
	cleanup := func() {
		if gatewayID != "" {
			_ = cli.ContainerRemove(ctx, gatewayID, container.RemoveOptions{Force: true})
		}
		_ = cli.NetworkRemove(ctx, pairNetworkID)
	}
	gwName := dockerFUSEGatewayName(sandboxID)
	gwResp, err := cli.ContainerCreate(ctx, &container.Config{
		Image: gatewayImage, Cmd: []string{"sleep", "infinity"},
		Labels: map[string]string{"sandbox.managed": "true", "sandbox.id": sandboxID, "sandbox.role": "gateway", "sandbox.gateway.contract": "fuse-v1", dockerSecretRootLabel: secretRoot, dockerCASecretKeyLabel: caSecretKey},
	}, &container.HostConfig{
		CapDrop: []string{"ALL"}, CapAdd: []string{"NET_ADMIN", "NET_RAW"},
		SecurityOpt: []string{"no-new-privileges=true"}, ReadonlyRootfs: true,
		Tmpfs:     map[string]string{"/run": "size=4194304,mode=0755", "/tmp": "size=4194304"},
		Sysctls:   map[string]string{"net.ipv4.ip_forward": "1"},
		Resources: container.Resources{Memory: 32 * 1024 * 1024, PidsLimit: int64Ptr(20)},
	}, &dnetwork.NetworkingConfig{EndpointsConfig: map[string]*dnetwork.EndpointSettings{pairNetName: {}}}, nil, gwName)
	if err != nil {
		cleanup()
		return "", "", "", fmt.Errorf("create FUSE gateway: %w", err)
	}
	gatewayID = gwResp.ID
	if err := cli.ContainerStart(ctx, gatewayID, container.StartOptions{}); err != nil {
		cleanup()
		return "", "", "", fmt.Errorf("start FUSE gateway: %w", err)
	}
	if err := cli.NetworkConnect(ctx, openNetworkID, gatewayID, nil); err != nil {
		cleanup()
		return "", "", "", fmt.Errorf("connect FUSE gateway to open network: %w", err)
	}
	if err := runGatewayPolicy(ctx, cli, gatewayID, command); err != nil {
		cleanup()
		return "", "", "", err
	}
	gatewayIP, err = getContainerIP(ctx, cli, gatewayID, pairNetName)
	if err != nil {
		cleanup()
		return "", "", "", fmt.Errorf("get FUSE gateway IP: %w", err)
	}
	return pairNetworkID, gatewayID, gatewayIP, nil
}

func runGatewayPolicy(ctx context.Context, cli dockerAPI, gatewayID, command string) error {
	execResponse, err := cli.ContainerExecCreate(ctx, gatewayID, container.ExecOptions{Cmd: []string{"sh", "-c", command}, User: "root"})
	if err != nil {
		return fmt.Errorf("create FUSE gateway policy exec: %w", err)
	}
	if err := cli.ContainerExecStart(ctx, execResponse.ID, container.ExecStartOptions{}); err != nil {
		return fmt.Errorf("start FUSE gateway policy exec: %w", err)
	}
	if err := waitExecDone(ctx, cli, execResponse.ID); err != nil {
		return fmt.Errorf("FUSE gateway policy failed: %w", err)
	}
	return nil
}

const (
	fusePermanentChain = "SBOX_PERMANENT"
	fuseSystemChain    = "SBOX_SYSTEM"
	fuseUserChain      = "SBOX_USER"
)

var permanentlyDeniedDockerIPv4 = []string{
	"0.0.0.0/8",      // unspecified/current network
	"127.0.0.0/8",    // loopback
	"169.254.0.0/16", // link-local and cloud metadata
	"224.0.0.0/4",    // multicast
}

func buildFUSEGatewayIptablesCmd(system runtime.SystemEgressSpec, userEnabled bool, userCIDRs []string, blockPrivate bool) (string, error) {
	if system.Mode != runtime.SystemEgressCIDR || len(system.EndpointCIDRs) == 0 || len(system.EndpointPorts) == 0 || len(system.EndpointFQDNs) != 0 || system.ProxyURL != "" {
		return "", fmt.Errorf("invalid Docker FUSE system egress contract")
	}
	var dnsCIDRs []string
	var err error
	if len(system.Hosts) == 0 {
		dnsPorts, err := canonicalDockerPorts(system.DNSPorts)
		if err != nil || len(dnsPorts) != 1 || dnsPorts[0] != 53 {
			return "", fmt.Errorf("docker FUSE DNS ports must be exactly 53")
		}
		dnsCIDRs, err = canonicalDockerDNSCIDRs(system.DNSCIDRs)
		if err != nil {
			return "", err
		}
	} else if len(system.DNSCIDRs) != 0 || len(system.DNSPorts) != 0 {
		return "", fmt.Errorf("resolved Docker FUSE system egress must not require DNS")
	}
	endpointCIDRs, err := canonicalDockerIPv4CIDRs(system.EndpointCIDRs, true)
	if err != nil {
		return "", err
	}
	endpointPorts, err := canonicalDockerPorts(system.EndpointPorts)
	if err != nil {
		return "", err
	}
	userRules, err := dockerFUSEUserRules(userEnabled, userCIDRs, blockPrivate)
	if err != nil {
		return "", err
	}
	filter := []string{
		"*filter",
		"-F FORWARD", "-P FORWARD DROP",
		"-F " + fusePermanentChain, "-F " + fuseSystemChain, "-F " + fuseUserChain,
		"-A FORWARD -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT",
		"-A FORWARD -j " + fusePermanentChain,
		"-A FORWARD -j " + fuseSystemChain,
		"-A FORWARD -j " + fuseUserChain,
	}
	for _, cidr := range permanentlyDeniedDockerIPv4 {
		filter = append(filter, fmt.Sprintf("-A %s -d %s -j DROP", fusePermanentChain, cidr))
	}
	for _, cidr := range dnsCIDRs {
		for _, protocol := range []string{"udp", "tcp"} {
			filter = append(filter, fmt.Sprintf("-A %s -d %s -p %s --dport 53 -j ACCEPT", fuseSystemChain, cidr, protocol))
		}
	}
	for _, cidr := range endpointCIDRs {
		for _, port := range endpointPorts {
			filter = append(filter, fmt.Sprintf("-A %s -d %s -p tcp --dport %d -j ACCEPT", fuseSystemChain, cidr, port))
		}
	}
	filter = append(filter, userRules...)
	filter = append(filter, "COMMIT")
	parts := []string{
		`OUT_IF=$(ip -4 route show default | awk 'NR == 1 {print $5}')`,
		`test -n "$OUT_IF"`,
		`(iptables -t nat -C POSTROUTING -o "$OUT_IF" -j MASQUERADE 2>/dev/null || iptables -t nat -A POSTROUTING -o "$OUT_IF" -j MASQUERADE)`,
		"(iptables -N " + fusePermanentChain + " 2>/dev/null || true)",
		"(iptables -N " + fuseSystemChain + " 2>/dev/null || true)",
		"(iptables -N " + fuseUserChain + " 2>/dev/null || true)",
		dockerIptablesRestoreCommand(filter),
	}
	return strings.Join(parts, " && "), nil
}

// buildFUSEGatewayUserIptablesCmd atomically replaces only the request-scoped
// USER chain. The immutable SYSTEM and PERMANENT chains are never flushed or
// regenerated by an Acquire-time network update.
func buildFUSEGatewayUserIptablesCmd(enabled bool, cidrs []string, blockPrivate bool) (string, error) {
	rules, err := dockerFUSEUserRules(enabled, cidrs, blockPrivate)
	if err != nil {
		return "", err
	}
	lines := []string{"*filter", "-F " + fuseUserChain}
	lines = append(lines, rules...)
	lines = append(lines, "COMMIT")
	return dockerIptablesRestoreCommand(lines), nil
}

func dockerFUSEUserRules(enabled bool, values []string, blockPrivate bool) ([]string, error) {
	cidrs, err := canonicalDockerIPv4CIDRs(values, false)
	if err != nil {
		return nil, err
	}
	if !enabled {
		return nil, nil
	}
	rules := make([]string, 0, len(cidrs)+len(privateRanges)+1)
	for _, cidr := range cidrs {
		rules = append(rules, fmt.Sprintf("-A %s -d %s -j ACCEPT", fuseUserChain, cidr))
	}
	if blockPrivate {
		for _, cidr := range privateRanges {
			rules = append(rules, fmt.Sprintf("-A %s -d %s -j DROP", fuseUserChain, cidr))
		}
		rules = append(rules, "-A "+fuseUserChain+" -j ACCEPT")
	} else if len(cidrs) == 0 {
		rules = append(rules, "-A "+fuseUserChain+" -j ACCEPT")
	}
	return rules, nil
}

func canonicalDockerIPv4CIDRs(values []string, rejectPermanent bool) ([]string, error) {
	unique := make(map[string]struct{}, len(values))
	for _, value := range values {
		prefix, err := netip.ParsePrefix(value)
		if err != nil || !prefix.Addr().Is4() || prefix.Addr().Is4In6() || prefix.Addr().Zone() != "" || prefix.String() != value || prefix != prefix.Masked() {
			return nil, fmt.Errorf("invalid canonical Docker FUSE IPv4 CIDR")
		}
		if rejectPermanent {
			for _, deniedRaw := range permanentlyDeniedDockerIPv4 {
				denied, _ := netip.ParsePrefix(deniedRaw)
				if prefix.Overlaps(denied) {
					return nil, fmt.Errorf("docker FUSE system egress overlaps a permanently denied CIDR")
				}
			}
		}
		unique[value] = struct{}{}
	}
	result := make([]string, 0, len(unique))
	for value := range unique {
		result = append(result, value)
	}
	sort.Strings(result)
	return result, nil
}

func canonicalDockerDNSCIDRs(values []string) ([]string, error) {
	result, err := canonicalDockerIPv4CIDRs(values, false)
	if err != nil || len(result) < 1 || len(result) > 3 {
		return nil, fmt.Errorf("docker FUSE must configure between one and three public IPv4 DNS resolvers")
	}
	for _, raw := range result {
		prefix, _ := netip.ParsePrefix(raw)
		if prefix.Bits() != prefix.Addr().BitLen() || !runtime.IsPublicDNSAddress(prefix.Addr()) {
			return nil, fmt.Errorf("docker FUSE DNS resolver must be a public IPv4 host prefix")
		}
	}
	return result, nil
}

func canonicalDockerPorts(values []int32) ([]int32, error) {
	unique := make(map[int32]struct{}, len(values))
	for _, value := range values {
		if value < 1 || value > 65535 {
			return nil, fmt.Errorf("invalid Docker FUSE egress port")
		}
		unique[value] = struct{}{}
	}
	result := make([]int32, 0, len(unique))
	for value := range unique {
		result = append(result, value)
	}
	sort.Slice(result, func(i, j int) bool { return result[i] < result[j] })
	return result, nil
}

func containsDockerPort(values []int32, target int32) bool {
	for _, value := range values {
		if value == target {
			return true
		}
	}
	return false
}

func dockerIptablesRestoreCommand(lines []string) string {
	payload := strings.Join(lines, "\n") + "\n"
	return "printf '%s' '" + strings.ReplaceAll(payload, "'", `'\''`) + "' | iptables-restore --noflush"
}

const (
	isolatedNetworkName = "sandbox-isolated"
	openNetworkName     = "sandbox-open"
	pairNetworkPrefix   = "sandbox-pair-"
	gatewayNamePrefix   = "sandbox-gw-"

	defaultGatewayImage = "sandbox-gateway:latest"
)

// ensureNetworks creates the two static sandbox networks if they don't exist:
//   - sandbox-isolated (internal=true): no external access
//   - sandbox-open (internal=false): full external access
func ensureNetworks(ctx context.Context, cli dockerAPI) (isolatedID, openID string, err error) {
	isolatedID, err = ensureOneNetwork(ctx, cli, isolatedNetworkName, true)
	if err != nil {
		return "", "", err
	}
	openID, err = ensureOneNetwork(ctx, cli, openNetworkName, false)
	if err != nil {
		return "", "", err
	}
	return isolatedID, openID, nil
}

func ensureOneNetwork(ctx context.Context, cli dockerAPI, name string, internal bool) (string, error) {
	networks, err := cli.NetworkList(ctx, dnetwork.ListOptions{})
	if err != nil {
		return "", fmt.Errorf("list networks: %w", err)
	}
	for _, n := range networks {
		if n.Name == name {
			return n.ID, nil
		}
	}

	resp, err := cli.NetworkCreate(ctx, name, dnetwork.CreateOptions{
		Driver:     "bridge",
		Internal:   internal,
		Attachable: true,
	})
	if err != nil {
		// Handle race: another instance might have created it
		if strings.Contains(err.Error(), "already exists") {
			networks2, err2 := cli.NetworkList(ctx, dnetwork.ListOptions{})
			if err2 != nil {
				return "", fmt.Errorf("list networks after conflict: %w", err2)
			}
			for _, n := range networks2 {
				if n.Name == name {
					return n.ID, nil
				}
			}
		}
		return "", fmt.Errorf("create network %s: %w", name, err)
	}
	return resp.ID, nil
}

// createSandboxPair creates a per-sandbox network pair:
//  1. An internal bridge network (sandbox-pair-<id>) where sandbox and gateway coexist
//  2. A gateway container connected to both the pair network and sandbox-open
//
// The gateway container performs NAT + whitelist filtering via iptables.
// Returns the pair network ID, gateway container ID, and gateway IP on the pair network.
func createSandboxPair(ctx context.Context, cli dockerAPI, sandboxID, openNetworkID, gatewayImage string, whitelist []string, blockPrivate bool) (pairNetworkID, gatewayID, gatewayIP string, err error) {
	// Resolve whitelist entries: IPs/CIDRs pass through, domain names are resolved to IPs
	resolved, err := resolveWhitelist(whitelist)
	if err != nil {
		return "", "", "", err
	}

	pairNetName := pairNetworkPrefix + sandboxID

	// 1. Create the pair network.
	// Not marked as internal so Docker's embedded DNS (127.0.0.11) can resolve
	// external domains. Network isolation is enforced by routing all traffic
	// through the gateway via ip route replace.
	netResp, err := createManagedPairNetwork(ctx, cli, pairNetName, dnetwork.CreateOptions{
		Driver:     "bridge",
		Attachable: true,
		Labels: map[string]string{
			"sandbox.managed": "true",
			"sandbox.id":      sandboxID,
		},
	}, time.Now())
	if err != nil {
		return "", "", "", fmt.Errorf("create pair network: %w", err)
	}
	pairNetworkID = netResp.ID

	// Cleanup helper for rollback
	cleanup := func() {
		if gatewayID != "" {
			_ = cli.ContainerRemove(ctx, gatewayID, container.RemoveOptions{Force: true})
		}
		_ = cli.NetworkRemove(ctx, pairNetworkID)
	}

	// 2. Create gateway container on the pair network
	if gatewayImage == "" {
		gatewayImage = defaultGatewayImage
	}
	gwName := gatewayNamePrefix + sandboxID

	gwResp, err := cli.ContainerCreate(ctx, &container.Config{
		Image: gatewayImage,
		Cmd:   []string{"sleep", "infinity"},
		Labels: map[string]string{
			"sandbox.managed": "true",
			"sandbox.id":      sandboxID,
			"sandbox.role":    "gateway",
		},
	}, &container.HostConfig{
		CapDrop: []string{"ALL"},
		CapAdd:  []string{"NET_ADMIN", "NET_RAW"},
		Sysctls: map[string]string{
			"net.ipv4.ip_forward": "1",
		},
		Resources: container.Resources{
			Memory:    32 * 1024 * 1024, // 32Mi
			PidsLimit: int64Ptr(20),
		},
	}, &dnetwork.NetworkingConfig{
		EndpointsConfig: map[string]*dnetwork.EndpointSettings{
			pairNetName: {},
		},
	}, nil, gwName)
	if err != nil {
		cleanup()
		return "", "", "", fmt.Errorf("create gateway container: %w", err)
	}
	gatewayID = gwResp.ID

	// 3. Start gateway
	if err := cli.ContainerStart(ctx, gatewayID, container.StartOptions{}); err != nil {
		cleanup()
		return "", "", "", fmt.Errorf("start gateway: %w", err)
	}

	// 4. Connect gateway to the open network (this becomes the second interface with default route)
	if err := cli.NetworkConnect(ctx, openNetworkID, gatewayID, nil); err != nil {
		cleanup()
		return "", "", "", fmt.Errorf("connect gateway to open network: %w", err)
	}

	// 5. Configure NAT + whitelist rules inside the gateway
	iptablesCmd := buildGatewayIptablesCmd(resolved, blockPrivate)
	execCfg := container.ExecOptions{
		Cmd:  []string{"sh", "-c", iptablesCmd},
		User: "root",
	}
	execResp, err := cli.ContainerExecCreate(ctx, gatewayID, execCfg)
	if err != nil {
		cleanup()
		return "", "", "", fmt.Errorf("create gateway exec: %w", err)
	}
	if err := cli.ContainerExecStart(ctx, execResp.ID, container.ExecStartOptions{}); err != nil {
		cleanup()
		return "", "", "", fmt.Errorf("start gateway exec: %w", err)
	}
	// Wait for exec to complete
	if err := waitExecDone(ctx, cli, execResp.ID); err != nil {
		cleanup()
		return "", "", "", fmt.Errorf("gateway iptables setup failed: %w", err)
	}

	// 6. Get gateway IP on the pair network
	gatewayIP, err = getContainerIP(ctx, cli, gatewayID, pairNetName)
	if err != nil {
		cleanup()
		return "", "", "", fmt.Errorf("get gateway IP: %w", err)
	}

	return pairNetworkID, gatewayID, gatewayIP, nil
}

// buildGatewayIptablesCmd builds the shell command to configure NAT and filtering
// rules inside the gateway container.
//
// Three modes:
//  1. whitelist (len(whitelist)>0, !blockPrivate): default deny, allow only whitelist destinations
//  2. open (!blockPrivate, len(whitelist)==0): allow all forwarding
//  3. block-private (blockPrivate): allow all external traffic, block RFC1918 private ranges;
//     whitelist entries are accepted before the private-range DROP rules (internal allowlist)
func buildGatewayIptablesCmd(whitelist []string, blockPrivate bool) string {
	var parts []string

	// Find the outbound interface (the one with the default route, from sandbox-open)
	parts = append(parts, `OUT_IF=$(ip route | grep default | awk '{print $5}')`)
	// NAT outbound traffic through the open network interface
	parts = append(parts, "iptables -t nat -A POSTROUTING -o $OUT_IF -j MASQUERADE")

	switch {
	case blockPrivate:
		// Allow established/related and DNS first
		parts = append(parts, "iptables -P FORWARD DROP")
		parts = append(parts, "iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT")
		parts = append(parts, "iptables -A FORWARD -p udp --dport 53 -j ACCEPT")
		parts = append(parts, "iptables -A FORWARD -p tcp --dport 53 -j ACCEPT")
		// Internal whitelist: split by address family
		for _, dest := range whitelist {
			if isIPv6(dest) {
				parts = append(parts, fmt.Sprintf("ip6tables -A FORWARD -d %s -j ACCEPT", dest))
			} else {
				parts = append(parts, fmt.Sprintf("iptables -A FORWARD -d %s -j ACCEPT", dest))
			}
		}
		// Block IPv4 private ranges
		for _, cidr := range privateRanges {
			parts = append(parts, fmt.Sprintf("iptables -A FORWARD -d %s -j DROP", cidr))
		}
		// Allow everything else (external IPv4 traffic)
		parts = append(parts, "iptables -A FORWARD -j ACCEPT")
		// IPv6: same structure via ip6tables
		parts = append(parts, "ip6tables -P FORWARD DROP")
		parts = append(parts, "ip6tables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT")
		parts = append(parts, "ip6tables -A FORWARD -p udp --dport 53 -j ACCEPT")
		parts = append(parts, "ip6tables -A FORWARD -p tcp --dport 53 -j ACCEPT")
		for _, cidr := range privateRangesIPv6 {
			parts = append(parts, fmt.Sprintf("ip6tables -A FORWARD -d %s -j DROP", cidr))
		}
		parts = append(parts, "ip6tables -A FORWARD -j ACCEPT")

	case len(whitelist) > 0:
		// Whitelist mode: default deny, allow only specified destinations
		parts = append(parts, "iptables -P FORWARD DROP")
		parts = append(parts, "iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT")
		parts = append(parts, "iptables -A FORWARD -p udp --dport 53 -j ACCEPT")
		parts = append(parts, "iptables -A FORWARD -p tcp --dport 53 -j ACCEPT")
		for _, dest := range whitelist {
			parts = append(parts, fmt.Sprintf("iptables -A FORWARD -d %s -j ACCEPT", dest))
		}
		parts = append(parts, "ip6tables -P FORWARD DROP")

	default:
		// Full access mode: allow all forwarding, but always block the cloud metadata
		// endpoint regardless of mode — it must never be reachable from sandbox code.
		parts = append(parts, "iptables -A FORWARD -d 169.254.0.0/16 -j DROP")
		parts = append(parts, "iptables -P FORWARD ACCEPT")
		parts = append(parts, "ip6tables -A FORWARD -d fe80::/10 -j DROP")
		parts = append(parts, "ip6tables -P FORWARD ACCEPT")
	}

	return strings.Join(parts, " && ")
}

// privateRanges contains RFC1918 private IP ranges, loopback, and link-local (IPv4 only).
// IPv6 private ranges are handled separately via ip6tables.
var privateRanges = []string{
	"10.0.0.0/8",
	"172.16.0.0/12",
	"192.168.0.0/16",
	"127.0.0.0/8",
	"169.254.0.0/16",
}

// privateRangesIPv6 contains IPv6 private/ULA ranges for ip6tables rules.
var privateRangesIPv6 = []string{
	"fc00::/7",  // ULA
	"::1/128",   // loopback
	"fe80::/10", // link-local
}

// isIPv6 reports whether addr is an IPv6 address or CIDR.
func isIPv6(addr string) bool {
	if ip := net.ParseIP(addr); ip != nil {
		return ip.To4() == nil
	}
	if ip, _, err := net.ParseCIDR(addr); err == nil {
		return ip.To4() == nil
	}
	return false
}

// removeSandboxPair removes the gateway container and pair network for a sandbox.
func removeSandboxPair(ctx context.Context, cli dockerAPI, sandboxID string) error {
	return removeSandboxPairWithName(ctx, cli, sandboxID, pairNetworkPrefix+sandboxID)
}

func removeFUSESandboxPair(ctx context.Context, cli dockerAPI, preparationID string) error {
	return removeSandboxPairWithName(ctx, cli, preparationID, dockerFUSEPairNetworkName(preparationID))
}

func removeSandboxPairWithName(ctx context.Context, cli dockerAPI, sandboxID, pairNetName string) error {
	// Find and remove gateway container by label
	gwContainers, err := cli.ContainerList(ctx, container.ListOptions{
		All: true,
		Filters: filters.NewArgs(
			filters.Arg("label", "sandbox.id="+sandboxID),
			filters.Arg("label", "sandbox.role=gateway"),
		),
	})
	if err == nil {
		for _, gw := range gwContainers {
			_ = cli.ContainerRemove(ctx, gw.ID, container.RemoveOptions{Force: true})
		}
	}

	// Remove pair network
	err = cli.NetworkRemove(ctx, pairNetName)
	if err != nil && !dockerclient.IsErrNotFound(err) {
		return fmt.Errorf("remove pair network: %w", err)
	}
	return nil
}

func dockerFUSEPairNetworkName(preparationID string) string {
	return pairNetworkPrefix + dockerFUSEResourceSuffix(preparationID)
}

func dockerFUSEGatewayName(preparationID string) string {
	return gatewayNamePrefix + dockerFUSEResourceSuffix(preparationID)
}

// setupSandboxRoute configures the default route inside the sandbox container
// to point to the gateway IP. Executed as root via Docker exec.
func setupSandboxRoute(ctx context.Context, cli dockerAPI, containerID, gatewayIP string) error {
	execCfg := container.ExecOptions{
		Cmd:  []string{"ip", "route", "replace", "default", "via", gatewayIP},
		User: "root",
	}
	execResp, err := cli.ContainerExecCreate(ctx, containerID, execCfg)
	if err != nil {
		return fmt.Errorf("create route exec: %w", err)
	}
	if err := cli.ContainerExecStart(ctx, execResp.ID, container.ExecStartOptions{}); err != nil {
		return fmt.Errorf("start route exec: %w", err)
	}
	return waitExecDone(ctx, cli, execResp.ID)
}

// getContainerIP returns the container's IP address on the given network.
func getContainerIP(ctx context.Context, cli dockerAPI, containerID, networkName string) (string, error) {
	info, err := cli.ContainerInspect(ctx, containerID)
	if err != nil {
		return "", fmt.Errorf("inspect container: %w", err)
	}
	if info.NetworkSettings == nil || info.NetworkSettings.Networks == nil {
		return "", fmt.Errorf("container has no network settings")
	}
	netInfo, ok := info.NetworkSettings.Networks[networkName]
	if !ok {
		return "", fmt.Errorf("container not connected to network %s", networkName)
	}
	if netInfo.IPAddress == "" {
		return "", fmt.Errorf("container has no IP on network %s", networkName)
	}
	return netInfo.IPAddress, nil
}

// waitExecDone polls until a Docker exec completes and returns an error if
// the exit code is non-zero. Enforces a 30-second hard timeout to prevent
// indefinite blocking if the caller's context has no deadline.
func waitExecDone(ctx context.Context, cli dockerAPI, execID string) error {
	ctx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()

	ticker := time.NewTicker(100 * time.Millisecond)
	defer ticker.Stop()
	for {
		inspect, err := cli.ContainerExecInspect(ctx, execID)
		if err != nil {
			return fmt.Errorf("inspect exec: %w", err)
		}
		if !inspect.Running {
			if inspect.ExitCode != 0 {
				return fmt.Errorf("exec failed with exit code %d", inspect.ExitCode)
			}
			return nil
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
		}
	}
}

// hasExistingGateway checks if a gateway sidecar exists for the given sandbox.
func hasExistingGateway(ctx context.Context, cli dockerAPI, sandboxID string) bool {
	gwContainers, err := cli.ContainerList(ctx, container.ListOptions{
		Filters: filters.NewArgs(
			filters.Arg("label", "sandbox.id="+sandboxID),
			filters.Arg("label", "sandbox.role=gateway"),
		),
	})
	return err == nil && len(gwContainers) > 0
}

// findGatewayID returns the container ID of the gateway for the given sandbox.
func findGatewayID(ctx context.Context, cli dockerAPI, sandboxID string) (string, error) {
	gwContainers, err := cli.ContainerList(ctx, container.ListOptions{
		Filters: filters.NewArgs(
			filters.Arg("label", "sandbox.id="+sandboxID),
			filters.Arg("label", "sandbox.role=gateway"),
		),
	})
	if err != nil {
		return "", fmt.Errorf("list gateway containers: %w", err)
	}
	if len(gwContainers) == 0 {
		return "", fmt.Errorf("no gateway found for sandbox %s", sandboxID)
	}
	return gwContainers[0].ID, nil
}

// resolveWhitelist processes whitelist entries: IPs and CIDRs pass through unchanged,
// domain names are resolved to their IP addresses.
func resolveWhitelist(entries []string) ([]string, error) {
	var resolved []string
	for _, entry := range entries {
		if net.ParseIP(entry) != nil {
			resolved = append(resolved, entry)
			continue
		}
		if _, _, err := net.ParseCIDR(entry); err == nil {
			resolved = append(resolved, entry)
			continue
		}
		// Treat as domain name, resolve to IPs
		ips, err := net.LookupIP(entry)
		if err != nil {
			return nil, fmt.Errorf("resolve whitelist domain %q: %w", entry, err)
		}
		for _, ip := range ips {
			if ip.To4() != nil {
				resolved = append(resolved, ip.String())
			}
		}
	}
	return resolved, nil
}

// resolveFUSEWhitelist resolves only IPv4 destinations. Explicit IPv6 input
// and IPv6-only names fail closed; a failed/empty resolution must never be
// mistaken for the deliberate "network enabled without a whitelist" mode.
func resolveFUSEWhitelist(entries []string) ([]string, error) {
	var resolved []string
	for _, entry := range entries {
		if address, err := netip.ParseAddr(entry); err == nil {
			if !address.Is4() || address.Is4In6() || address.String() != entry {
				return nil, fmt.Errorf("docker FUSE user network supports IPv4 only")
			}
			resolved = append(resolved, entry+"/32")
			continue
		}
		if prefix, err := netip.ParsePrefix(entry); err == nil {
			if !prefix.Addr().Is4() || prefix.Addr().Is4In6() || prefix.Addr().Zone() != "" || prefix.String() != entry || prefix != prefix.Masked() {
				return nil, fmt.Errorf("docker FUSE user network supports canonical IPv4 CIDRs only")
			}
			resolved = append(resolved, entry)
			continue
		}
		ips, err := net.LookupIP(entry)
		if err != nil {
			return nil, fmt.Errorf("resolve FUSE whitelist domain %q: %w", entry, err)
		}
		before := len(resolved)
		for _, ip := range ips {
			if ipv4 := ip.To4(); ipv4 != nil {
				resolved = append(resolved, ipv4.String()+"/32")
			}
		}
		if len(resolved) == before {
			return nil, fmt.Errorf("docker FUSE whitelist domain %q has no IPv4 address", entry)
		}
	}
	return canonicalDockerStrings(resolved), nil
}

const staleSandboxNetworkAge = 5 * time.Minute

func cleanupStaleSandboxNetworkResources(ctx context.Context, cli dockerAPI, now time.Time) (int, error) {
	if err := cleanupStaleOrphanGateways(ctx, cli, now); err != nil {
		return 0, err
	}
	return cleanupStaleEmptySandboxNetworks(ctx, cli, now)
}

func cleanupStaleOrphanGateways(ctx context.Context, cli dockerAPI, now time.Time) error {
	containers, err := cli.ContainerList(ctx, container.ListOptions{
		All: true, Filters: filters.NewArgs(filters.Arg("label", "sandbox.managed=true")),
	})
	if err != nil {
		return fmt.Errorf("list managed sandbox containers: %w", err)
	}
	activeRuntimeIDs := make(map[string]struct{}, len(containers))
	for _, item := range containers {
		if item.Labels["sandbox.role"] == "gateway" {
			continue
		}
		for _, name := range item.Names {
			if currentID := strings.TrimPrefix(name, "/"); currentID != "" {
				activeRuntimeIDs[currentID] = struct{}{}
			}
		}
		if item.Labels["sandbox.role"] == "fuse-runtime" {
			if preparationID := item.Labels["sandbox.id"]; preparationID != "" {
				activeRuntimeIDs[preparationID] = struct{}{}
			}
		}
	}
	for _, item := range containers {
		if item.Labels["sandbox.role"] != "gateway" || item.Created <= 0 {
			continue
		}
		preparationID := item.Labels["sandbox.id"]
		if preparationID == "" || now.Sub(time.Unix(item.Created, 0)) < staleSandboxNetworkAge {
			continue
		}
		if _, active := activeRuntimeIDs[preparationID]; active {
			continue
		}
		if removeErr := cli.ContainerRemove(ctx, item.ID, container.RemoveOptions{Force: true}); removeErr != nil && !dockerclient.IsErrNotFound(removeErr) {
			return fmt.Errorf("remove stale sandbox gateway %s: %w", item.ID, removeErr)
		}
	}
	return nil
}

func cleanupStaleEmptySandboxNetworks(ctx context.Context, cli dockerAPI, now time.Time) (int, error) {
	networks, err := cli.NetworkList(ctx, dnetwork.ListOptions{Filters: filters.NewArgs(filters.Arg("label", "sandbox.managed=true"))})
	if err != nil {
		return 0, fmt.Errorf("list managed sandbox networks: %w", err)
	}
	removed := 0
	for _, n := range networks {
		if n.Labels["sandbox.managed"] != "true" || !isSandboxPairNetworkName(n.Name) {
			continue
		}
		inspect, inspectErr := cli.NetworkInspect(ctx, n.ID, dnetwork.InspectOptions{})
		if inspectErr != nil {
			if dockerclient.IsErrNotFound(inspectErr) {
				continue
			}
			return removed, fmt.Errorf("inspect managed sandbox network %s: %w", n.Name, inspectErr)
		}
		if inspect.Labels["sandbox.managed"] != "true" || !isSandboxPairNetworkName(inspect.Name) || inspect.Created.IsZero() || now.Sub(inspect.Created) < staleSandboxNetworkAge || len(inspect.Containers) != 0 {
			continue
		}
		if removeErr := cli.NetworkRemove(ctx, inspect.ID); removeErr != nil && !dockerclient.IsErrNotFound(removeErr) {
			return removed, fmt.Errorf("remove stale sandbox network %s: %w", inspect.Name, removeErr)
		}
		removed++
	}
	return removed, nil
}

func isSandboxPairNetworkName(name string) bool {
	return strings.HasPrefix(name, pairNetworkPrefix) || strings.HasPrefix(name, "sandbox-net-") || name == "sandbox-network"
}

func createManagedPairNetwork(ctx context.Context, cli dockerAPI, name string, options dnetwork.CreateOptions, now time.Time) (dnetwork.CreateResponse, error) {
	response, err := cli.NetworkCreate(ctx, name, options)
	if err == nil || !isDockerAddressPoolExhausted(err) {
		return response, err
	}
	if _, cleanupErr := cleanupStaleSandboxNetworkResources(ctx, cli, now); cleanupErr != nil {
		return dnetwork.CreateResponse{}, errors.Join(err, cleanupErr)
	}
	return cli.NetworkCreate(ctx, name, options)
}

func isDockerAddressPoolExhausted(err error) bool {
	return err != nil && strings.Contains(err.Error(), "could not find an available, non-overlapping IPv4 address pool")
}
