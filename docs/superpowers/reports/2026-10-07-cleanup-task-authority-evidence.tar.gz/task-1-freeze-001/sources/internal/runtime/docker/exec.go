package docker

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"strings"
	"time"

	"github.com/docker/docker/api/types/container"
	"github.com/docker/docker/pkg/stdcopy"

	"github.com/goairix/sandbox/internal/runtime"
)

func (r *Runtime) Exec(ctx context.Context, id string, req runtime.ExecRequest) (*runtime.ExecResult, error) {
	start := time.Now()

	// Enforce timeout
	if req.Timeout > 0 {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, time.Duration(req.Timeout)*time.Second)
		defer cancel()
	}

	workDir := req.WorkDir
	if workDir == "" {
		workDir = "/workspace"
	}

	// Build command
	cmd := []string{"sh", "-c", req.Command}

	// Build env
	var env []string
	for k, v := range req.Env {
		env = append(env, fmt.Sprintf("%s=%s", k, v))
	}

	user, err := r.publicExecUser(ctx, id)
	if err != nil {
		return nil, err
	}
	execConfig := container.ExecOptions{
		Cmd:          cmd,
		User:         user,
		AttachStdout: true,
		AttachStderr: true,
		AttachStdin:  req.Stdin != "",
		Tty:          req.LineBuffered,
		WorkingDir:   workDir,
		Env:          env,
	}

	execResp, err := r.cli.ContainerExecCreate(ctx, id, execConfig)
	if err != nil {
		return nil, fmt.Errorf("exec create: %w", err)
	}

	attachResp, err := r.cli.ContainerExecAttach(ctx, execResp.ID, container.ExecAttachOptions{})
	if err != nil {
		return nil, fmt.Errorf("exec attach: %w", err)
	}
	defer attachResp.Close()
	stopWatch := watchDockerAttachContext(ctx, attachResp.Close)
	defer stopWatch()

	// Send stdin if provided
	if req.Stdin != "" {
		_, _ = io.Copy(attachResp.Conn, strings.NewReader(req.Stdin))
		_ = attachResp.CloseWrite()
	}

	// Read stdout/stderr
	// In TTY mode, stdout and stderr are merged into a single stream (no stdcopy multiplexing).
	var stdout, stderr bytes.Buffer
	if req.LineBuffered {
		_, err = io.Copy(&stdout, attachResp.Reader)
	} else {
		_, err = stdcopy.StdCopy(&stdout, &stderr, attachResp.Reader)
	}
	if err != nil {
		return nil, fmt.Errorf("read output: %w", err)
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}

	// Get exit code
	inspectResp, err := r.cli.ContainerExecInspect(ctx, execResp.ID)
	if err != nil {
		return nil, fmt.Errorf("exec inspect: %w", err)
	}

	return &runtime.ExecResult{
		ExitCode: inspectResp.ExitCode,
		Stdout:   stdout.String(),
		Stderr:   stderr.String(),
		Duration: time.Since(start),
	}, nil
}

func (r *Runtime) ExecPipe(ctx context.Context, id string, cmd []string, stdin io.Reader) error {
	user, err := r.publicExecUser(ctx, id)
	if err != nil {
		return err
	}
	execConfig := container.ExecOptions{
		Cmd:          cmd,
		User:         user,
		AttachStdin:  true,
		AttachStdout: true,
		AttachStderr: true,
	}

	execResp, err := r.cli.ContainerExecCreate(ctx, id, execConfig)
	if err != nil {
		return fmt.Errorf("exec create: %w", err)
	}

	attachResp, err := r.cli.ContainerExecAttach(ctx, execResp.ID, container.ExecAttachOptions{})
	if err != nil {
		return fmt.Errorf("exec attach: %w", err)
	}
	defer attachResp.Close()
	stopWatch := watchDockerAttachContext(ctx, attachResp.Close)
	defer stopWatch()

	// Capture stdout/stderr in background to prevent the exec from blocking
	// and to include stderr in error messages when the command fails.
	var stdout, stderr bytes.Buffer
	doneCh := make(chan struct{})
	go func() {
		defer close(doneCh)
		_, _ = stdcopy.StdCopy(&stdout, &stderr, attachResp.Reader)
	}()

	// Stream stdin to the exec process.
	_, _ = io.Copy(attachResp.Conn, stdin)
	_ = attachResp.CloseWrite()

	<-doneCh
	if err := ctx.Err(); err != nil {
		return err
	}

	inspectResp, err := r.cli.ContainerExecInspect(ctx, execResp.ID)
	if err != nil {
		return fmt.Errorf("exec inspect: %w", err)
	}
	if inspectResp.ExitCode != 0 {
		errMsg := strings.TrimSpace(stderr.String())
		if errMsg != "" {
			return fmt.Errorf("exec exited with code %d: %s", inspectResp.ExitCode, errMsg)
		}
		return fmt.Errorf("exec exited with code %d", inspectResp.ExitCode)
	}
	return nil
}

func (r *Runtime) ExecStream(ctx context.Context, id string, req runtime.ExecRequest) (<-chan runtime.StreamEvent, error) {
	// Enforce timeout
	var cancel context.CancelFunc
	if req.Timeout > 0 {
		ctx, cancel = context.WithTimeout(ctx, time.Duration(req.Timeout)*time.Second)
	} else {
		ctx, cancel = context.WithCancel(ctx)
	}

	workDir := req.WorkDir
	if workDir == "" {
		workDir = "/workspace"
	}

	cmd := []string{"sh", "-c", req.Command}

	var env []string
	for k, v := range req.Env {
		env = append(env, fmt.Sprintf("%s=%s", k, v))
	}

	user, err := r.publicExecUser(ctx, id)
	if err != nil {
		cancel()
		return nil, err
	}
	execConfig := container.ExecOptions{
		Cmd:          cmd,
		User:         user,
		AttachStdout: true,
		AttachStderr: true,
		Tty:          req.LineBuffered,
		WorkingDir:   workDir,
		Env:          env,
	}

	execResp, err := r.cli.ContainerExecCreate(ctx, id, execConfig)
	if err != nil {
		cancel()
		return nil, fmt.Errorf("exec create: %w", err)
	}

	attachResp, err := r.cli.ContainerExecAttach(ctx, execResp.ID, container.ExecAttachOptions{
		Tty: req.LineBuffered,
	})
	if err != nil {
		cancel()
		return nil, fmt.Errorf("exec attach: %w", err)
	}

	ch := make(chan runtime.StreamEvent, 64)

	go func() {
		defer cancel()
		defer close(ch)
		defer attachResp.Close()
		stopWatch := watchDockerAttachContext(ctx, attachResp.Close)
		defer stopWatch()

		if req.LineBuffered {
			// TTY mode: stdout and stderr are merged into a single raw stream.
			// Read directly without stdcopy demuxing.
			buf := make([]byte, 4096)
			for {
				n, readErr := attachResp.Reader.Read(buf)
				if n > 0 {
					if !sendDockerStreamEvent(ctx, ch, runtime.StreamEvent{
						Type:    runtime.StreamStdout,
						Content: string(buf[:n]),
					}) {
						return
					}
				}
				if readErr != nil {
					break
				}
			}
		} else {
			// Non-TTY mode: use stdcopy to demux stdout/stderr.
			stdoutPR, stdoutPW := io.Pipe()
			stderrPR, stderrPW := io.Pipe()
			defer func() { _ = stdoutPR.Close() }()
			defer func() { _ = stderrPR.Close() }()

			go func() {
				_, _ = stdcopy.StdCopy(stdoutPW, stderrPW, attachResp.Reader)
				_ = stdoutPW.Close()
				_ = stderrPW.Close()
			}()

			done := make(chan struct{})
			go func() {
				defer close(done)
				buf := make([]byte, 4096)
				for {
					n, readErr := stderrPR.Read(buf)
					if n > 0 {
						if !sendDockerStreamEvent(ctx, ch, runtime.StreamEvent{
							Type:    runtime.StreamStderr,
							Content: string(buf[:n]),
						}) {
							return
						}
					}
					if readErr != nil {
						break
					}
				}
			}()

			buf := make([]byte, 4096)
			for {
				n, readErr := stdoutPR.Read(buf)
				if n > 0 {
					if !sendDockerStreamEvent(ctx, ch, runtime.StreamEvent{
						Type:    runtime.StreamStdout,
						Content: string(buf[:n]),
					}) {
						return
					}
				}
				if readErr != nil {
					break
				}
			}

			<-done
		}

		if ctx.Err() != nil {
			return
		}
		inspectResp, inspectErr := r.cli.ContainerExecInspect(ctx, execResp.ID)
		if inspectErr != nil {
			_ = sendDockerStreamEvent(ctx, ch, runtime.StreamEvent{
				Type:    runtime.StreamError,
				Content: inspectErr.Error(),
			})
			return
		}

		_ = sendDockerStreamEvent(ctx, ch, runtime.StreamEvent{
			Type:    runtime.StreamDone,
			Content: fmt.Sprintf("%d", inspectResp.ExitCode),
		})
	}()

	return ch, nil
}

func sendDockerStreamEvent(ctx context.Context, ch chan<- runtime.StreamEvent, event runtime.StreamEvent) bool {
	select {
	case ch <- event:
		return true
	case <-ctx.Done():
		return false
	}
}
