package docker

import (
	"archive/tar"
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/docker/docker/api/types/container"
	"github.com/docker/docker/errdefs"
	"github.com/docker/docker/pkg/stdcopy"
	"github.com/google/uuid"

	"github.com/goairix/sandbox/internal/runtime"
)

// shellEscape wraps a string in single quotes with proper escaping
// to prevent shell injection.
func shellEscape(s string) string {
	return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'"
}

func (r *Runtime) UploadFile(ctx context.Context, id, destPath string, size int64, reader io.Reader) error {
	if size < 0 {
		return fmt.Errorf("%w: size must be non-negative", runtime.ErrInvalidUploadSize)
	}
	if _, err := r.isFUSEContainer(ctx, id); err != nil {
		return err
	}

	dir := filepath.Dir(destPath)
	mkdirResult, err := r.Exec(ctx, id, runtime.ExecRequest{
		Command: fmt.Sprintf("mkdir -p %s", shellEscape(dir)),
	})
	if err := uploadExecResult("create directory "+dir, mkdirResult, err); err != nil {
		return err
	}

	// Manager-created sandboxes run as UID/GID 1000. The staging object must
	// belong to that user so publish and cleanup also work in sticky directories
	// such as /tmp.
	const uid, gid = 1000, 1000
	tempPath := filepath.Join(dir, ".sandbox-upload-"+uuid.NewString())
	pr, pw := io.Pipe()
	writeDone := make(chan error, 1)
	go func() {
		writeErr := writeSizedTar(pw, filepath.Base(tempPath), 0o644, uid, gid, size, reader)
		_ = pw.CloseWithError(writeErr)
		writeDone <- writeErr
	}()
	consumeErr := r.ExecPipe(ctx, id, []string{"tar", "xf", "-", "-C", dir}, pr)
	_ = pr.CloseWithError(consumeErr)
	writeErr := <-writeDone
	if errors.Is(writeErr, runtime.ErrInvalidUploadSize) {
		return r.uploadFailureWithCleanup(ctx, id, tempPath, writeErr)
	}
	if writeErr != nil {
		return r.uploadFailureWithCleanup(ctx, id, tempPath, writeErr)
	}
	if consumeErr != nil {
		return r.uploadFailureWithCleanup(ctx, id, tempPath, consumeErr)
	}
	publishResult, err := r.Exec(ctx, id, runtime.ExecRequest{Command: uploadPublishCommand(tempPath, destPath)})
	if err := uploadExecResult("publish uploaded file", publishResult, err); err != nil {
		return r.uploadFailureWithCleanup(ctx, id, tempPath, err)
	}
	return nil
}

func uploadPublishCommand(tempPath, destPath string) string {
	return fmt.Sprintf("test ! -d %s && mv -f -- %s %s", shellEscape(destPath), shellEscape(tempPath), shellEscape(destPath))
}

func uploadExecResult(action string, result *runtime.ExecResult, err error) error {
	if err != nil {
		return fmt.Errorf("%s: %w", action, err)
	}
	if result == nil {
		return fmt.Errorf("%s: runtime returned no result", action)
	}
	if result.ExitCode != 0 {
		detail := strings.TrimSpace(result.Stderr)
		if detail == "" {
			detail = fmt.Sprintf("exit code %d", result.ExitCode)
		}
		return fmt.Errorf("%s: %s", action, detail)
	}
	return nil
}

func (r *Runtime) uploadFailureWithCleanup(ctx context.Context, id, tempPath string, uploadErr error) error {
	cleanupErr := r.removePartialUpload(ctx, id, tempPath)
	if cleanupErr == nil {
		return uploadErr
	}
	return errors.Join(uploadErr, cleanupErr)
}

func (r *Runtime) removePartialUpload(ctx context.Context, id, tempPath string) error {
	result, err := r.Exec(ctx, id, runtime.ExecRequest{Command: "rm -f -- " + shellEscape(tempPath)})
	return uploadExecResult("cleanup partial upload", result, err)
}

func writeSizedTar(dst io.Writer, name string, mode int64, uid, gid int, size int64, reader io.Reader) error {
	if size < 0 {
		return fmt.Errorf("%w: size must be non-negative", runtime.ErrInvalidUploadSize)
	}
	tw := tar.NewWriter(dst)
	if err := tw.WriteHeader(&tar.Header{Name: name, Mode: mode, Size: size, ModTime: time.Now(), Uid: uid, Gid: gid}); err != nil {
		return fmt.Errorf("write tar header: %w", err)
	}
	if _, err := io.CopyN(tw, reader, size); err != nil {
		return fmt.Errorf("%w: body shorter than declared size: %v", runtime.ErrInvalidUploadSize, err)
	}
	var extra [1]byte
	n, err := reader.Read(extra[:])
	if n != 0 || err == nil {
		return fmt.Errorf("%w: body exceeds declared size", runtime.ErrInvalidUploadSize)
	}
	if err != io.EOF {
		return fmt.Errorf("read upload trailer: %w", err)
	}
	if err := tw.Close(); err != nil {
		return fmt.Errorf("close tar: %w", err)
	}
	return nil
}

func (r *Runtime) DownloadFile(ctx context.Context, id string, srcPath string) (io.ReadCloser, error) {
	fuseContainer, err := r.isFUSEContainer(ctx, id)
	if err != nil {
		return nil, err
	}
	if fuseContainer {
		if err := r.preflightDownloadFile(ctx, id, srcPath); err != nil {
			return nil, err
		}
		return r.downloadFile(ctx, id, srcPath)
	}
	tarReader, _, err := r.cli.CopyFromContainer(ctx, id, srcPath)
	if err != nil {
		if errdefs.IsNotFound(err) && strings.HasSuffix(err.Error(), "Could not find the file "+srcPath+" in container "+id) {
			return nil, fmt.Errorf("download file: %w", runtime.ErrFileNotFound)
		}
		return nil, err
	}
	return tarReader, nil
}

func (r *Runtime) ReadFileContent(ctx context.Context, id string, srcPath string) (io.ReadCloser, error) {
	if err := r.FileExists(ctx, id, srcPath); err != nil {
		return nil, err
	}

	user, err := r.publicExecUser(ctx, id)
	if err != nil {
		return nil, err
	}
	execResp, err := r.cli.ContainerExecCreate(ctx, id, container.ExecOptions{
		Cmd:          []string{"cat", srcPath},
		User:         user,
		AttachStdout: true,
		AttachStderr: true,
	})
	if err != nil {
		return nil, fmt.Errorf("create exec: %w", err)
	}

	attachResp, err := r.cli.ContainerExecAttach(ctx, execResp.ID, container.ExecAttachOptions{})
	if err != nil {
		return nil, fmt.Errorf("attach exec: %w", err)
	}

	pr, pw := io.Pipe()
	stopWatch := watchDockerAttachContext(ctx, attachResp.Close)
	go func() {
		defer stopWatch()
		_, err := stdcopy.StdCopy(pw, io.Discard, attachResp.Reader)
		attachResp.Close()
		pw.CloseWithError(err)
	}()

	return pr, nil
}

func (r *Runtime) FileExists(ctx context.Context, id string, filePath string) error {
	result, err := r.Exec(ctx, id, runtime.ExecRequest{
		Command: fmt.Sprintf("test -f %s", shellEscape(filePath)),
	})
	if err != nil {
		return err
	}
	if result.ExitCode != 0 {
		return runtime.ErrFileNotFound
	}
	return nil
}

func (r *Runtime) UploadArchive(ctx context.Context, id string, destDir string, archive io.Reader) error {
	fuseContainer, err := r.isFUSEContainer(ctx, id)
	if err != nil {
		return err
	}
	if fuseContainer {
		return r.ExecPipe(ctx, id, []string{"tar", "xf", "-", "-C", destDir}, archive)
	}
	return r.cli.CopyToContainer(ctx, id, destDir, archive, container.CopyToContainerOptions{})
}

func (r *Runtime) DownloadDir(ctx context.Context, id string, dirPath string) (io.ReadCloser, error) {
	fuseContainer, err := r.isFUSEContainer(ctx, id)
	if err != nil {
		return nil, err
	}
	if fuseContainer {
		return r.downloadFile(ctx, id, dirPath)
	}
	reader, _, err := r.cli.CopyFromContainer(ctx, id, dirPath)
	if err != nil {
		return nil, err
	}
	return reader, nil
}

func (r *Runtime) ListFiles(ctx context.Context, id string, dirPath string) ([]runtime.FileInfo, error) {
	result, err := r.Exec(ctx, id, runtime.ExecRequest{
		Command: fmt.Sprintf("find %s -maxdepth 1 -mindepth 1 -printf '%%f\\t%%s\\t%%Y\\t%%T@\\n'", shellEscape(dirPath)),
		WorkDir: "/workspace",
	})
	if err != nil {
		return nil, err
	}

	var files []runtime.FileInfo
	for _, line := range strings.Split(strings.TrimSpace(result.Stdout), "\n") {
		if line == "" {
			continue
		}
		parts := strings.SplitN(line, "\t", 4)
		if len(parts) < 4 || parts[0] == "." {
			continue
		}

		size, modTime, err := runtime.ParseFileMetadata(parts[1], parts[3])
		if err != nil {
			return nil, err
		}
		isDir := parts[2] == "d"

		fullPath := dirPath + "/" + parts[0]

		files = append(files, runtime.FileInfo{
			Name:    parts[0],
			Path:    fullPath,
			Size:    size,
			IsDir:   isDir,
			ModTime: modTime,
		})
	}

	return files, nil
}

func (r *Runtime) ListFilesRecursive(ctx context.Context, id string, dirPath string, maxDepth int, page int, pageSize int) (*runtime.FileListResult, error) {
	// Normalise page before computing offset
	if page < 1 {
		page = 1
	}

	// Build find command args
	maxDepthArg := ""
	if maxDepth > 0 {
		maxDepthArg = fmt.Sprintf("-maxdepth %d ", maxDepth)
	}

	// Get total count (exclude root dir with -mindepth 1)
	countResult, err := r.Exec(ctx, id, runtime.ExecRequest{
		Command: fmt.Sprintf("find %s -mindepth 1 %s\\( -type f -o -type d \\) | wc -l", shellEscape(dirPath), maxDepthArg),
		WorkDir: "/workspace",
	})
	if err != nil {
		return nil, err
	}
	totalCount, err := runtime.ParseFileCount(countResult.Stdout)
	if err != nil {
		return nil, err
	}

	// Build paginated listing command (exclude root dir with -mindepth 1)
	listCmd := fmt.Sprintf(
		"find %s -mindepth 1 %s\\( -type f -o -type d \\) -printf '%%P\\t%%s\\t%%Y\\t%%T@\\n'",
		shellEscape(dirPath), maxDepthArg,
	)
	if pageSize > 0 {
		offset := (page - 1) * pageSize
		listCmd = fmt.Sprintf("%s | tail -n +%d | head -n %d", listCmd, offset+1, pageSize)
	}

	listResult, err := r.Exec(ctx, id, runtime.ExecRequest{
		Command: listCmd,
		WorkDir: "/workspace",
	})
	if err != nil {
		return nil, err
	}

	var files []runtime.FileInfo
	for _, line := range strings.Split(strings.TrimSpace(listResult.Stdout), "\n") {
		if line == "" {
			continue
		}
		parts := strings.SplitN(line, "\t", 4)
		if len(parts) < 4 || parts[0] == "" {
			continue
		}

		size, modTime, err := runtime.ParseFileMetadata(parts[1], parts[3])
		if err != nil {
			return nil, err
		}
		isDir := parts[2] == "d"

		name := filepath.Base(parts[0])
		fullPath := dirPath + "/" + parts[0]

		files = append(files, runtime.FileInfo{
			Name:    name,
			Path:    fullPath,
			Size:    size,
			IsDir:   isDir,
			ModTime: modTime,
		})
	}

	return &runtime.FileListResult{
		Files:      files,
		TotalCount: totalCount,
		Page:       page,
		PageSize:   pageSize,
	}, nil
}

func (r *Runtime) GlobFiles(ctx context.Context, id string, baseDir string, pattern string, page int, pageSize int) (*runtime.FileListResult, error) {
	if page < 1 {
		page = 1
	}

	findArgs, maxDepth1 := runtime.GlobToFindArgs(pattern)
	depthArg := ""
	if maxDepth1 {
		depthArg = "-maxdepth 1 "
	}

	countCmd := fmt.Sprintf("find %s -mindepth 1 %s%s -type f | wc -l", shellEscape(baseDir), depthArg, findArgs)
	countResult, err := r.Exec(ctx, id, runtime.ExecRequest{
		Command: countCmd,
		WorkDir: "/workspace",
	})
	if err != nil {
		return nil, err
	}
	totalCount, err := runtime.ParseFileCount(countResult.Stdout)
	if err != nil {
		return nil, err
	}

	listCmd := fmt.Sprintf(
		"find %s -mindepth 1 %s%s -type f -printf '%%P\\t%%s\\t%%Y\\t%%T@\\n'",
		shellEscape(baseDir), depthArg, findArgs,
	)
	if pageSize > 0 {
		offset := (page - 1) * pageSize
		listCmd = fmt.Sprintf("%s | tail -n +%d | head -n %d", listCmd, offset+1, pageSize)
	}

	listResult, err := r.Exec(ctx, id, runtime.ExecRequest{
		Command: listCmd,
		WorkDir: "/workspace",
	})
	if err != nil {
		return nil, err
	}

	var files []runtime.FileInfo
	for _, line := range strings.Split(strings.TrimSpace(listResult.Stdout), "\n") {
		if line == "" {
			continue
		}
		parts := strings.SplitN(line, "\t", 4)
		if len(parts) < 4 || parts[0] == "" {
			continue
		}

		size, modTime, err := runtime.ParseFileMetadata(parts[1], parts[3])
		if err != nil {
			return nil, err
		}

		name := filepath.Base(parts[0])
		fullPath := baseDir + "/" + parts[0]

		files = append(files, runtime.FileInfo{
			Name:    name,
			Path:    fullPath,
			Size:    size,
			IsDir:   false,
			ModTime: modTime,
		})
	}

	return &runtime.FileListResult{
		Files:      files,
		TotalCount: totalCount,
		Page:       page,
		PageSize:   pageSize,
	}, nil
}

// CountReservedFiles returns the exact number of reserved FUSE probe
// basenames in the same scope as ListFilesRecursive (empty globPattern) or
// GlobFiles (non-empty globPattern), without materialising matching paths.
func (r *Runtime) CountReservedFiles(ctx context.Context, id, baseDir string, maxDepth int, globPattern string) (int, error) {
	command := reservedFileCountCommand(baseDir, maxDepth, globPattern)
	result, err := r.Exec(ctx, id, runtime.ExecRequest{Command: command, WorkDir: "/workspace"})
	if err := uploadExecResult("count reserved FUSE files", result, err); err != nil {
		return 0, err
	}
	count, err := runtime.ParseFileCount(result.Stdout)
	if err != nil {
		return 0, fmt.Errorf("count reserved FUSE files: %w", err)
	}
	return count, nil
}

func reservedFileCountCommand(baseDir string, maxDepth int, globPattern string) string {
	depthArg := ""
	predicate := "\\( -type f -o -type d \\)"
	if globPattern == "" {
		if maxDepth > 0 {
			depthArg = fmt.Sprintf("-maxdepth %d ", maxDepth)
		}
	} else {
		findArgs, maxDepth1 := runtime.GlobToFindArgs(globPattern)
		if maxDepth1 {
			depthArg = "-maxdepth 1 "
		}
		predicate = fmt.Sprintf("\\( %s \\) -type f", findArgs)
	}
	findCommand := fmt.Sprintf(
		"find %s -mindepth 1 %s%s -name %s -printf '.\\n'",
		shellEscape(baseDir), depthArg, predicate, shellEscape(runtime.ReservedProbeObjectFindPattern()),
	)
	return fmt.Sprintf(
		"{ %s; sandbox_find_status=$?; printf 'sandbox-find-status:%%d\\n' \"$sandbox_find_status\"; } | "+
			"awk '/^sandbox-find-status:/ { status=$0; sub(/^sandbox-find-status:/, \"\", status); seen=1; if (status != 0) exit status; print count+0; next } { count++ } END { if (!seen) exit 125 }'",
		findCommand,
	)
}

func (r *Runtime) ReadFileLines(ctx context.Context, id string, filePath string, startLine int, endLine int) (*runtime.FileLineResult, error) {
	if err := r.FileExists(ctx, id, filePath); err != nil {
		return nil, err
	}

	if startLine < 1 {
		startLine = 1
	}

	// Get total line count
	countResult, err := r.Exec(ctx, id, runtime.ExecRequest{
		Command: fmt.Sprintf("wc -l < %s", shellEscape(filePath)),
		WorkDir: "/workspace",
	})
	if err != nil {
		return nil, err
	}
	totalLines, err := runtime.ParseFileCount(countResult.Stdout)
	if err != nil {
		return nil, err
	}

	// Build sed range: endLine 0 means read to end of file
	var sedRange string
	if endLine <= 0 || endLine > totalLines {
		endLine = totalLines
		sedRange = fmt.Sprintf("%d,$p", startLine)
	} else {
		sedRange = fmt.Sprintf("%d,%dp", startLine, endLine)
	}

	readResult, err := r.Exec(ctx, id, runtime.ExecRequest{
		Command: fmt.Sprintf("sed -n %s %s", shellEscape(sedRange), shellEscape(filePath)),
		WorkDir: "/workspace",
	})
	if err != nil {
		return nil, err
	}

	var lines []string
	if strings.TrimSpace(readResult.Stdout) != "" {
		lines = strings.Split(readResult.Stdout, "\n")
		// Remove trailing empty string from final newline
		if len(lines) > 0 && lines[len(lines)-1] == "" {
			lines = lines[:len(lines)-1]
		}
	}

	return &runtime.FileLineResult{
		Lines:      lines,
		StartLine:  startLine,
		EndLine:    endLine,
		TotalLines: totalLines,
	}, nil
}

func (r *Runtime) EditFile(ctx context.Context, id string, filePath string, oldStr string, newStr string, replaceAll bool) error {
	if err := r.FileExists(ctx, id, filePath); err != nil {
		return err
	}

	// Read the file content from the container.
	readResult, err := r.Exec(ctx, id, runtime.ExecRequest{
		Command: fmt.Sprintf("cat %s", shellEscape(filePath)),
		WorkDir: "/workspace",
	})
	if err != nil {
		return fmt.Errorf("read file: %w", err)
	}
	if readResult.ExitCode != 0 {
		return fmt.Errorf("read file: %s", strings.TrimSpace(readResult.Stderr))
	}

	content := readResult.Stdout

	// Check that oldStr exists in the file.
	if !strings.Contains(content, oldStr) {
		return fmt.Errorf("string not found in file: %s", oldStr)
	}

	// Perform the replacement in Go — supports multiline strings naturally.
	var newContent string
	if replaceAll {
		newContent = strings.ReplaceAll(content, oldStr, newStr)
	} else {
		newContent = strings.Replace(content, oldStr, newStr, 1)
	}

	// Write the result back via stdin pipe to avoid shell escaping issues.
	tmpFile := fmt.Sprintf("/tmp/sandbox-edit-%d", time.Now().UnixNano())
	if err := r.ExecPipe(ctx, id, []string{"sh", "-c", fmt.Sprintf("cat > %s", shellEscape(tmpFile))}, strings.NewReader(newContent)); err != nil {
		return fmt.Errorf("write temp file: %w", err)
	}

	_, err = r.Exec(ctx, id, runtime.ExecRequest{
		Command: fmt.Sprintf("mv %s %s", shellEscape(tmpFile), shellEscape(filePath)),
		WorkDir: "/workspace",
	})
	return err
}

func (r *Runtime) EditFileLines(ctx context.Context, id string, filePath string, startLine int, endLine int, newContent string) error {
	if err := r.FileExists(ctx, id, filePath); err != nil {
		return err
	}

	if startLine < 1 {
		startLine = 1
	}

	tmpEdit := fmt.Sprintf("/tmp/sandbox-edit-%d", time.Now().UnixNano())
	tmpContent := fmt.Sprintf("/tmp/sandbox-content-%d", time.Now().UnixNano())

	// Stream new content into a temp file via stdin to avoid ARG_MAX limits
	if err := r.ExecPipe(ctx, id, []string{"sh", "-c", fmt.Sprintf("cat > %s", shellEscape(tmpContent))}, strings.NewReader(newContent)); err != nil {
		return fmt.Errorf("write content: %w", err)
	}

	// Build the replacement command:
	// 1. Write lines before startLine to tmpEdit
	// 2. Append new content
	// 3. Append lines after endLine (if endLine > 0)
	// 4. Move tmpEdit back to filePath
	var buildCmd string
	if startLine > 1 {
		buildCmd = fmt.Sprintf("head -n %d %s > %s", startLine-1, shellEscape(filePath), shellEscape(tmpEdit))
	} else {
		buildCmd = fmt.Sprintf("> %s", shellEscape(tmpEdit))
	}
	buildCmd += fmt.Sprintf(" && cat %s >> %s", shellEscape(tmpContent), shellEscape(tmpEdit))

	if endLine > 0 {
		buildCmd += fmt.Sprintf(" && tail -n +%d %s >> %s", endLine+1, shellEscape(filePath), shellEscape(tmpEdit))
	}

	buildCmd += fmt.Sprintf(" && mv %s %s", shellEscape(tmpEdit), shellEscape(filePath))

	_, err := r.Exec(ctx, id, runtime.ExecRequest{
		Command: buildCmd,
		WorkDir: "/workspace",
	})
	return err
}

func (r *Runtime) GlobInfo(ctx context.Context, id string, pattern string) ([]runtime.FileContent, error) {
	// Find the first wildcard to determine the search root (no wildcards in baseDir).
	firstStar := strings.Index(pattern, "*")
	if firstStar == -1 {
		return nil, fmt.Errorf("invalid pattern: must contain wildcard")
	}
	lastSlashBeforeStar := strings.LastIndex(pattern[:firstStar], "/")
	if lastSlashBeforeStar == -1 {
		return nil, fmt.Errorf("invalid pattern: must contain directory path")
	}
	baseDir := pattern[:lastSlashBeforeStar]
	relPattern := pattern[lastSlashBeforeStar+1:]

	user, err := r.publicExecUser(ctx, id)
	if err != nil {
		return nil, err
	}
	execResp, err := r.cli.ContainerExecCreate(ctx, id, container.ExecOptions{
		Cmd:          []string{"find", baseDir, "-path", baseDir + "/" + relPattern, "-type", "f"},
		User:         user,
		AttachStdout: true,
		AttachStderr: true,
	})
	if err != nil {
		return nil, fmt.Errorf("create exec: %w", err)
	}

	attachResp, err := r.cli.ContainerExecAttach(ctx, execResp.ID, container.ExecStartOptions{})
	if err != nil {
		return nil, fmt.Errorf("attach exec: %w", err)
	}
	defer attachResp.Close()
	stopWatch := watchDockerAttachContext(ctx, attachResp.Close)
	defer stopWatch()

	var stdout bytes.Buffer
	if _, err := stdcopy.StdCopy(&stdout, io.Discard, attachResp.Reader); err != nil {
		return nil, fmt.Errorf("read exec output: %w", err)
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}

	lines := strings.Split(strings.TrimSpace(stdout.String()), "\n")
	if len(lines) == 1 && lines[0] == "" {
		return []runtime.FileContent{}, nil
	}

	results := make([]runtime.FileContent, len(lines))
	var wg sync.WaitGroup
	sem := make(chan struct{}, 10)

	for i, line := range lines {
		wg.Add(1)
		go func(idx int, fullPath string) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			reader, err := r.downloadFile(ctx, id, fullPath)
			results[idx] = runtime.FileContent{
				Path:    fullPath,
				Content: reader,
				Error:   err,
			}
		}(i, line)
	}
	wg.Wait()

	return results, nil
}

func (r *Runtime) DownloadFiles(ctx context.Context, id string, paths []string) ([]runtime.FileContent, error) {
	results := make([]runtime.FileContent, len(paths))
	var wg sync.WaitGroup
	sem := make(chan struct{}, 10)

	for i, path := range paths {
		wg.Add(1)
		go func(idx int, filePath string) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			reader, err := r.downloadFile(ctx, id, filePath)
			results[idx] = runtime.FileContent{
				Path:    filePath,
				Content: reader,
				Error:   err,
			}
		}(i, path)
	}
	wg.Wait()

	return results, nil
}

func (r *Runtime) downloadFile(ctx context.Context, id string, srcPath string) (io.ReadCloser, error) {
	user, err := r.publicExecUser(ctx, id)
	if err != nil {
		return nil, err
	}
	execResp, err := r.cli.ContainerExecCreate(ctx, id, container.ExecOptions{
		Cmd:          []string{"tar", "cf", "-", srcPath},
		User:         user,
		AttachStdout: true,
		AttachStderr: true,
	})
	if err != nil {
		return nil, fmt.Errorf("create exec: %w", err)
	}

	attachResp, err := r.cli.ContainerExecAttach(ctx, execResp.ID, container.ExecAttachOptions{})
	if err != nil {
		return nil, fmt.Errorf("attach exec: %w", err)
	}

	pr, pw := io.Pipe()
	stopWatch := watchDockerAttachContext(ctx, attachResp.Close)
	go func() {
		defer stopWatch()
		stderr := &limitedControlBuffer{limit: 4 << 10}
		_, err := stdcopy.StdCopy(pw, stderr, attachResp.Reader)
		attachResp.Close()
		if err == nil {
			err = ctx.Err()
		}
		if err == nil {
			if inspectErr := waitExecDone(ctx, r.cli, execResp.ID); inspectErr != nil {
				err = fmt.Errorf("download tar: %w: %s", inspectErr, strings.TrimSpace(stderr.String()))
			}
		}
		_ = pw.CloseWithError(err)
	}()

	return pr, nil
}

func (r *Runtime) preflightDownloadFile(ctx context.Context, id, srcPath string) error {
	result, err := r.Exec(ctx, id, runtime.ExecRequest{
		Command: "LC_ALL=C stat -L -c '%F' -- " + shellEscape(srcPath),
		WorkDir: "/",
	})
	if err != nil {
		return fmt.Errorf("stat download file: %w", err)
	}
	if result == nil {
		return fmt.Errorf("stat download file returned no result")
	}
	if result.ExitCode != 0 {
		if result.ExitCode == 1 && strings.HasSuffix(strings.TrimSpace(result.Stderr), ": No such file or directory") {
			return runtime.ErrFileNotFound
		}
		return fmt.Errorf("stat download file exited %d: %s", result.ExitCode, strings.TrimSpace(result.Stderr))
	}
	if strings.TrimSpace(result.Stdout) != "regular file" && strings.TrimSpace(result.Stdout) != "regular empty file" {
		return fmt.Errorf("download path is not a regular file")
	}
	return nil
}

func (r *Runtime) isFUSEContainer(ctx context.Context, id string) (bool, error) {
	info, err := r.cli.ContainerInspect(ctx, id)
	if err != nil {
		return false, fmt.Errorf("inspect container before file transfer: %w", err)
	}
	if info.Config == nil {
		return false, runtime.ErrInvalidRuntimeRef
	}
	isFUSE := info.Config.Labels["sandbox.managed"] == "true" && info.Config.Labels["sandbox.role"] == "fuse-runtime"
	if isFUSE && info.ID != id {
		return false, runtime.ErrInvalidRuntimeRef
	}
	return isFUSE, nil
}

func (r *Runtime) publicExecUser(ctx context.Context, id string) (string, error) {
	isFUSE, err := r.isFUSEContainer(ctx, id)
	if err != nil {
		return "", err
	}
	if isFUSE {
		return dockerPublicUser, nil
	}
	return "", nil
}
