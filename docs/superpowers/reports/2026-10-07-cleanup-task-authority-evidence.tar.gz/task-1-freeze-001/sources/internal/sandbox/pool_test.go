package sandbox

import (
	"context"
	"errors"
	"fmt"
	"io"
	"maps"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/goairix/sandbox/internal/runtime"
)

// mockRuntime is a simple mock for testing pool logic.
type mockRuntime struct {
	mu                sync.Mutex
	created           int
	removed           int
	sandboxes         map[string]*runtime.SandboxInfo
	execContext       context.Context
	execRequest       runtime.ExecRequest
	execFunc          func(context.Context, string, runtime.ExecRequest) (*runtime.ExecResult, error)
	streamContext     context.Context
	streamRequest     runtime.ExecRequest
	execStreamFunc    func(context.Context, string, runtime.ExecRequest) (<-chan runtime.StreamEvent, error)
	execPipeCalls     int
	createdSpec       runtime.SandboxSpec
	uploadSize        int64
	uploadCalls       int
	listFiles         []runtime.FileInfo
	listRecursiveFunc func(page, pageSize int) *runtime.FileListResult
	reservedFileCount int
	quiesceCalls      int
	flushCalls        int
	resumeCalls       int
	quiesceErr        error
	flushErr          error
	resumeErr         error
	quiesceToken      runtime.WorkspaceQuiesceToken
	workspaceOps      []string
	prepareSeq        int
	prepareErr        error
	prepareEntered    chan struct{}
	prepareRelease    chan struct{}
	prepareSignal     sync.Once
	healthFailures    map[string]error
	removeFailures    map[string]error
	removedIDs        map[string]int
	removeEntered     chan string
	removeRelease     chan struct{}
	downloadDirErr    error
	listedSandboxes   []runtime.SandboxInfo
	listSandboxesErr  error
	listLabels        map[string]string
	updateLabelsErr   error
	updateLabelsID    string
	updateLabelsCalls int
	updatedLabels     map[string]*string
}

func newMockRuntime() *mockRuntime {
	return &mockRuntime{
		sandboxes:      make(map[string]*runtime.SandboxInfo),
		healthFailures: make(map[string]error),
		removeFailures: make(map[string]error),
		removedIDs:     make(map[string]int),
	}
}

func (m *mockRuntime) CreateSandbox(_ context.Context, spec runtime.SandboxSpec) (*runtime.SandboxInfo, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.created++
	m.createdSpec = spec
	info := &runtime.SandboxInfo{
		ID:         spec.ID,
		RuntimeID:  "container-" + spec.ID,
		RuntimeUID: "container-" + spec.ID,
		State:      "running",
		CreatedAt:  time.Now(),
	}
	m.sandboxes[info.RuntimeID] = info
	return info, nil
}

func (m *mockRuntime) lastCreatedSpec() runtime.SandboxSpec {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.createdSpec
}

func (m *mockRuntime) StartSandbox(_ context.Context, _ string) error { return nil }
func (m *mockRuntime) StopSandbox(_ context.Context, _ string) error  { return nil }

func (m *mockRuntime) RemoveSandbox(_ context.Context, id string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.removeFailures[id]; err != nil {
		return err
	}
	m.removed++
	m.removedIDs[id]++
	delete(m.sandboxes, id)
	return nil
}

func (m *mockRuntime) RemovePreparedSandbox(ctx context.Context, runtimeID, runtimeUID string) error {
	m.mu.Lock()
	info, ok := m.sandboxes[runtimeID]
	if ok && info.RuntimeUID != runtimeUID {
		m.mu.Unlock()
		return runtime.ErrNotFound
	}
	entered, release := m.removeEntered, m.removeRelease
	m.mu.Unlock()
	if entered != nil {
		select {
		case entered <- runtimeID:
		case <-ctx.Done():
			return ctx.Err()
		}
		select {
		case <-release:
		case <-ctx.Done():
			return ctx.Err()
		}
	}
	return m.RemoveSandbox(ctx, runtimeID)
}

func (m *mockRuntime) blockPreparedRemovals(count int) (<-chan string, chan struct{}) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.removeEntered = make(chan string, count)
	m.removeRelease = make(chan struct{})
	return m.removeEntered, m.removeRelease
}

func (m *mockRuntime) GetSandbox(_ context.Context, id string) (*runtime.SandboxInfo, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	info, ok := m.sandboxes[id]
	if !ok {
		return nil, nil
	}
	return info, nil
}

func (m *mockRuntime) Exec(ctx context.Context, id string, req runtime.ExecRequest) (*runtime.ExecResult, error) {
	m.mu.Lock()
	m.execContext = ctx
	m.execRequest = req
	execFunc := m.execFunc
	m.mu.Unlock()
	if execFunc != nil {
		return execFunc(ctx, id, req)
	}
	return &runtime.ExecResult{}, nil
}

func (m *mockRuntime) ExecStream(ctx context.Context, id string, req runtime.ExecRequest) (<-chan runtime.StreamEvent, error) {
	m.mu.Lock()
	m.streamContext = ctx
	m.streamRequest = req
	execStreamFunc := m.execStreamFunc
	m.mu.Unlock()
	if execStreamFunc != nil {
		return execStreamFunc(ctx, id, req)
	}
	ch := make(chan runtime.StreamEvent)
	close(ch)
	return ch, nil
}

func (m *mockRuntime) lastExec() (context.Context, runtime.ExecRequest) {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.execContext, m.execRequest
}

func (m *mockRuntime) lastStream() (context.Context, runtime.ExecRequest) {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.streamContext, m.streamRequest
}

func (m *mockRuntime) ExecPipe(_ context.Context, _ string, _ []string, input io.Reader) error {
	_, err := io.Copy(io.Discard, input)
	m.mu.Lock()
	m.execPipeCalls++
	m.mu.Unlock()
	return err
}

func (m *mockRuntime) UpdateLabels(_ context.Context, id string, labels map[string]*string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.updateLabelsCalls++
	m.updateLabelsID = id
	m.updatedLabels = labels
	return m.updateLabelsErr
}

func (m *mockRuntime) PrepareSandbox(ctx context.Context, spec runtime.SandboxSpec) (*runtime.SandboxInfo, error) {
	m.mu.Lock()
	if m.prepareErr != nil {
		err := m.prepareErr
		m.mu.Unlock()
		return nil, err
	}
	entered, release := m.prepareEntered, m.prepareRelease
	m.mu.Unlock()
	if entered != nil {
		m.prepareSignal.Do(func() { close(entered) })
		select {
		case <-release:
		case <-ctx.Done():
			return nil, ctx.Err()
		}
	}
	m.mu.Lock()
	m.prepareSeq++
	seq := m.prepareSeq
	m.created++
	m.createdSpec = spec
	info := &runtime.SandboxInfo{
		ID:         spec.ID,
		RuntimeID:  fmt.Sprintf("prepared-runtime-%d", seq),
		RuntimeUID: fmt.Sprintf("prepared-uid-%d", seq),
		State:      "running",
		CreatedAt:  time.Now(),
	}
	m.sandboxes[info.RuntimeID] = info
	m.mu.Unlock()
	return info, nil
}

func (m *mockRuntime) blockPrepare() (<-chan struct{}, chan<- struct{}) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.prepareEntered = make(chan struct{})
	m.prepareRelease = make(chan struct{})
	return m.prepareEntered, m.prepareRelease
}

func (m *mockRuntime) AuthorizeWorkspaceMount(context.Context, runtime.RuntimeRef, runtime.WorkspaceMountAuthorization) error {
	return nil
}

func (m *mockRuntime) WaitSandboxReady(_ context.Context, ref runtime.RuntimeRef, _ int64) (*runtime.SandboxInfo, error) {
	return &runtime.SandboxInfo{RuntimeID: ref.ID, RuntimeUID: ref.UID, State: "running"}, nil
}

func (m *mockRuntime) PreparedSandboxHealth(_ context.Context, ref runtime.RuntimeRef, _ string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.healthFailures[ref.ID]
}

func (m *mockRuntime) failPreparedHealth(id string, err error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.healthFailures[id] = err
}

func (m *mockRuntime) failRemove(id string, err error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.removeFailures[id] = err
}

func (m *mockRuntime) wasRemoved(id string) bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.removedIDs[id] > 0
}

func (m *mockRuntime) prepareCount() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.prepareSeq
}

func (m *mockRuntime) WorkspaceHealth(context.Context, runtime.RuntimeRef) (*runtime.WorkspaceHealth, error) {
	return &runtime.WorkspaceHealth{Ready: true}, nil
}

func (m *mockRuntime) QuiesceWorkspace(context.Context, runtime.RuntimeRef, int64) (runtime.WorkspaceQuiesceToken, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.quiesceCalls++
	m.workspaceOps = append(m.workspaceOps, "quiesce")
	if m.quiesceErr != nil {
		return runtime.WorkspaceQuiesceToken{}, m.quiesceErr
	}
	if m.quiesceToken.Opaque != "" {
		return m.quiesceToken, nil
	}
	return runtime.WorkspaceQuiesceToken{RuntimeUID: "prepared-uid-1", Generation: 1, Opaque: "token-1"}, nil
}

func (m *mockRuntime) ResumeWorkspace(context.Context, runtime.RuntimeRef, runtime.WorkspaceQuiesceToken) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.resumeCalls++
	m.workspaceOps = append(m.workspaceOps, "resume")
	return m.resumeErr
}

func (m *mockRuntime) FlushWorkspace(context.Context, runtime.RuntimeRef, int64) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.flushCalls++
	m.workspaceOps = append(m.workspaceOps, "flush")
	return m.flushErr
}

func (m *mockRuntime) UploadFile(_ context.Context, _ string, _ string, size int64, _ io.Reader) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.uploadCalls++
	m.uploadSize = size
	return nil
}

func (m *mockRuntime) lastUploadSize() int64 {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.uploadSize
}

func (m *mockRuntime) DownloadFile(_ context.Context, _ string, _ string) (io.ReadCloser, error) {
	return nil, nil
}

func (m *mockRuntime) ListFiles(context.Context, string, string) ([]runtime.FileInfo, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	return append([]runtime.FileInfo(nil), m.listFiles...), nil
}

func (m *mockRuntime) UploadArchive(context.Context, string, string, io.Reader) error {
	return nil
}

func (m *mockRuntime) DownloadDir(context.Context, string, string) (io.ReadCloser, error) {
	m.mu.Lock()
	err := m.downloadDirErr
	m.mu.Unlock()
	if err != nil {
		return nil, err
	}
	return io.NopCloser(strings.NewReader("")), nil
}

func (m *mockRuntime) UpdateNetwork(context.Context, string, bool, []string, bool) error {
	return nil
}

func (m *mockRuntime) UpdateFUSENetwork(context.Context, runtime.RuntimeRef, bool, []string, bool) error {
	return nil
}

func (m *mockRuntime) RenameSandbox(context.Context, string, string) error {
	return nil
}

func (m *mockRuntime) ListSandboxes(_ context.Context, labels map[string]string) ([]runtime.SandboxInfo, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.listLabels = maps.Clone(labels)
	if m.listSandboxesErr != nil {
		return nil, m.listSandboxesErr
	}
	return append([]runtime.SandboxInfo(nil), m.listedSandboxes...), nil
}

func (m *mockRuntime) IsStateful() bool { return false }

type sharedPoolRuntime struct{ *mockRuntime }

func (m *sharedPoolRuntime) RemoveOrdinarySandbox(ctx context.Context, ref runtime.RuntimeRef) error {
	return m.RemovePreparedSandbox(ctx, ref.ID, ref.UID)
}

func (m *sharedPoolRuntime) CleanupOrdinarySandboxPolicies(ctx context.Context, ref runtime.RuntimeRef, _ string) error {
	if _, err := m.GetSandbox(ctx, ref.ID); !errors.Is(err, runtime.ErrNotFound) {
		return errors.Join(runtime.ErrTerminationUnconfirmed, err)
	}
	return nil
}

func newSharedPoolRuntime() *sharedPoolRuntime {
	return &sharedPoolRuntime{mockRuntime: newMockRuntime()}
}

func (m *sharedPoolRuntime) GetSandbox(_ context.Context, id string) (*runtime.SandboxInfo, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	info := m.sandboxes[id]
	if info == nil {
		return nil, runtime.ErrNotFound
	}
	copy := *info
	copy.Labels = maps.Clone(info.Labels)
	return &copy, nil
}

func (m *sharedPoolRuntime) CreateSandbox(ctx context.Context, spec runtime.SandboxSpec) (*runtime.SandboxInfo, error) {
	info, err := m.mockRuntime.CreateSandbox(ctx, spec)
	if err != nil {
		return nil, err
	}
	m.mu.Lock()
	info.Labels = maps.Clone(spec.Labels)
	m.mu.Unlock()
	return info, nil
}

func (m *sharedPoolRuntime) UpdateLabels(_ context.Context, id string, labels map[string]*string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	info := m.sandboxes[id]
	if info == nil {
		return runtime.ErrNotFound
	}
	if info.Labels == nil {
		info.Labels = make(map[string]string)
	}
	for key, value := range labels {
		if value == nil {
			delete(info.Labels, key)
		} else {
			info.Labels[key] = *value
		}
	}
	if poolValue, removesPool := labels["sandbox.pool"]; removesPool && poolValue == nil {
		delete(info.Labels, "sandbox.pool.state")
		delete(info.Labels, "sandbox.pool.key")
		delete(info.Labels, "sandbox.pool.instance")
	}
	return nil
}

func (m *sharedPoolRuntime) PublishOrdinaryPoolPrepared(_ context.Context, ref runtime.RuntimeRef, poolKey, preparationID string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	info := m.sandboxes[ref.ID]
	if info == nil {
		return runtime.ErrNotFound
	}
	if info.RuntimeUID != ref.UID || info.Labels["sandbox.pool"] != "true" || info.Labels["sandbox.pool.key"] != poolKey ||
		info.Labels["sandbox.pool.instance"] != preparationID || info.Labels["sandbox.pool.state"] != "preparing" {
		return runtime.ErrInvalidRuntimeRef
	}
	info.Labels["sandbox.pool.state"] = "prepared"
	return nil
}

func (m *sharedPoolRuntime) ListSandboxes(_ context.Context, labels map[string]string) ([]runtime.SandboxInfo, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	result := make([]runtime.SandboxInfo, 0)
	for _, info := range m.sandboxes {
		matches := true
		for key, expected := range labels {
			if info.Labels[key] != expected {
				matches = false
				break
			}
		}
		if matches {
			copy := *info
			copy.Labels = maps.Clone(info.Labels)
			result = append(result, copy)
		}
	}
	return result, nil
}

func (m *sharedPoolRuntime) IsStateful() bool { return true }

func (m *sharedPoolRuntime) snapshotIDs() map[string]struct{} {
	m.mu.Lock()
	defer m.mu.Unlock()
	result := make(map[string]struct{}, len(m.sandboxes))
	for id := range m.sandboxes {
		result[id] = struct{}{}
	}
	return result
}

func (m *mockRuntime) ListFilesRecursive(_ context.Context, _, _ string, _ int, page, pageSize int) (*runtime.FileListResult, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.listRecursiveFunc != nil {
		return m.listRecursiveFunc(page, pageSize), nil
	}
	return nil, nil
}
func (m *mockRuntime) ReadFileLines(context.Context, string, string, int, int) (*runtime.FileLineResult, error) {
	return nil, nil
}
func (m *mockRuntime) EditFile(context.Context, string, string, string, string, bool) error {
	return nil
}
func (m *mockRuntime) EditFileLines(context.Context, string, string, int, int, string) error {
	return nil
}
func (m *mockRuntime) GlobInfo(context.Context, string, string) ([]runtime.FileContent, error) {
	return nil, nil
}
func (m *mockRuntime) GlobFiles(context.Context, string, string, string, int, int) (*runtime.FileListResult, error) {
	return nil, nil
}
func (m *mockRuntime) DownloadFiles(context.Context, string, []string) ([]runtime.FileContent, error) {
	return nil, nil
}

func (m *mockRuntime) FileExists(_ context.Context, _ string, _ string) error {
	return nil
}

func (m *mockRuntime) CountReservedFiles(context.Context, string, string, int, string) (int, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.reservedFileCount, nil
}

func (m *mockRuntime) ReadFileContent(_ context.Context, _ string, _ string) (io.ReadCloser, error) {
	return nil, nil
}

var _ runtime.Runtime = (*mockRuntime)(nil)

func TestPool_Acquire(t *testing.T) {
	rt := newMockRuntime()
	pool := NewPool(rt, PoolConfig{
		MinSize: 2,
		MaxSize: 10,
		Image:   "sandbox:latest",
	})

	ctx := context.Background()

	// Warm up pool
	require.NoError(t, pool.WarmUp(ctx))
	time.Sleep(100 * time.Millisecond) // let async creation finish

	assert.Equal(t, 2, pool.Size())

	// Acquire one
	info, err := pool.Acquire(ctx)
	require.NoError(t, err)
	assert.NotEmpty(t, info.ID)
	assert.Equal(t, 1, pool.Size())
}

func TestPoolDrainWaitsForInFlightRefillAndRemovesItsResult(t *testing.T) {
	base := newMockRuntime()
	rt := &blockingCreateRuntime{
		mockRuntime: base,
		entered:     make(chan struct{}),
		release:     make(chan struct{}),
	}
	pool := NewPool(rt, PoolConfig{MinSize: 1, MaxSize: 1, Image: "sandbox:latest"})
	pool.NotifyRemoved()
	<-rt.entered

	drained := make(chan struct{})
	go func() {
		pool.Drain(context.Background())
		close(drained)
	}()

	select {
	case <-drained:
		assert.Fail(t, "pool drain returned before in-flight refill completed")
	case <-time.After(50 * time.Millisecond):
	}
	close(rt.release)
	select {
	case <-drained:
	case <-time.After(time.Second):
		t.Fatal("pool drain did not finish after refill completed")
	}
	require.Eventually(t, func() bool {
		base.mu.Lock()
		defer base.mu.Unlock()
		return base.created == 1
	}, time.Second, 10*time.Millisecond)

	base.mu.Lock()
	created, removed := base.created, base.removed
	remaining := len(base.sandboxes)
	base.mu.Unlock()
	assert.Equal(t, 1, created)
	assert.Equal(t, 1, removed)
	assert.Zero(t, remaining)
}

func TestPoolCreateWarmPropagatesTmpDisk(t *testing.T) {
	rt := newMockRuntime()
	pool := NewPool(rt, PoolConfig{
		Image:   "sandbox:latest",
		TmpDisk: "150Mi",
	})

	_, err := pool.createWarm(context.Background())

	require.NoError(t, err)
	assert.Equal(t, "150Mi", rt.lastCreatedSpec().TmpDisk)
}

func TestPool_Release(t *testing.T) {
	rt := newMockRuntime()
	pool := NewPool(rt, PoolConfig{
		MinSize: 2,
		MaxSize: 10,
		Image:   "sandbox:latest",
	})

	ctx := context.Background()
	require.NoError(t, pool.WarmUp(ctx))
	time.Sleep(100 * time.Millisecond)

	info, err := pool.Acquire(ctx)
	require.NoError(t, err)

	// Release should destroy (not return to pool — used containers are dirty)
	pool.Release(ctx, info.ID)

	rt.mu.Lock()
	assert.GreaterOrEqual(t, rt.removed, 1)
	rt.mu.Unlock()
}

func TestSharedOrdinaryPoolWarmUpAndAcquireAreGlobalAcrossReplicas(t *testing.T) {
	rt := newSharedPoolRuntime()
	store := newAtomicMemoryStore()
	cfg := PoolConfig{MinSize: 3, MaxSize: 3, Image: "sandbox:latest"}
	poolA, poolB := NewPool(rt, cfg), NewPool(rt, cfg)
	poolA.EnableShared(store, "sandbox-system")
	poolB.EnableShared(store, "sandbox-system")
	require.NoError(t, poolA.Start(context.Background()))
	require.NoError(t, poolB.Start(context.Background()))
	t.Cleanup(func() {
		poolA.Drain(context.Background())
		poolB.Drain(context.Background())
		_ = poolA.DrainRelease(context.Background())
	})

	require.NoError(t, poolA.WarmUp(context.Background()))
	original := rt.snapshotIDs()
	require.Len(t, original, 3)
	require.NoError(t, poolB.WarmUp(context.Background()))
	assert.Len(t, rt.snapshotIDs(), 3, "the second replica must not create a private pool")

	info, err := poolB.Acquire(context.Background())
	require.NoError(t, err)
	_, reused := original[info.RuntimeID]
	assert.True(t, reused, "a replica must claim a Pod prepared by another replica")
	assert.Equal(t, "prepared", info.Labels["sandbox.pool.state"], "the Manager retires pool labels during logical-ID migration")
}

func TestSharedOrdinaryPoolConcurrentAcquireClaimsWarmRuntimeOnce(t *testing.T) {
	rt := newSharedPoolRuntime()
	store := newAtomicMemoryStore()
	cfg := PoolConfig{MinSize: 1, MaxSize: 1, Image: "sandbox:latest"}
	poolA, poolB := NewPool(rt, cfg), NewPool(rt, cfg)
	poolA.EnableShared(store, "sandbox-system")
	poolB.EnableShared(store, "sandbox-system")
	require.NoError(t, poolA.Start(context.Background()))
	require.NoError(t, poolB.Start(context.Background()))
	t.Cleanup(func() {
		poolA.Drain(context.Background())
		poolB.Drain(context.Background())
		_ = poolA.DrainRelease(context.Background())
	})
	require.NoError(t, poolA.WarmUp(context.Background()))
	var warmID string
	for id := range rt.snapshotIDs() {
		warmID = id
	}

	start := make(chan struct{})
	results := make(chan *runtime.SandboxInfo, 2)
	errs := make(chan error, 2)
	for _, pool := range []*Pool{poolA, poolB} {
		go func(pool *Pool) {
			<-start
			info, err := pool.Acquire(context.Background())
			results <- info
			errs <- err
		}(pool)
	}
	close(start)
	first, second := <-results, <-results
	require.NoError(t, <-errs)
	require.NoError(t, <-errs)
	require.NotNil(t, first)
	require.NotNil(t, second)
	assert.NotEqual(t, first.RuntimeID, second.RuntimeID)
	warmClaims := 0
	if first.RuntimeID == warmID {
		warmClaims++
	}
	if second.RuntimeID == warmID {
		warmClaims++
	}
	assert.Equal(t, 1, warmClaims, "CAS must grant the warm runtime to exactly one replica")
	poolA.Release(context.Background(), first.RuntimeID)
	poolB.Release(context.Background(), second.RuntimeID)
}

func TestSharedOrdinaryPoolNormalStopPreservesInventoryAndReleaseDrainDeletesIt(t *testing.T) {
	rt := newSharedPoolRuntime()
	store := newAtomicMemoryStore()
	cfg := PoolConfig{MinSize: 1, MaxSize: 1, Image: "sandbox:latest"}
	poolA, poolB := NewPool(rt, cfg), NewPool(rt, cfg)
	poolA.EnableShared(store, "sandbox-system")
	poolB.EnableShared(store, "sandbox-system")
	require.NoError(t, poolA.Start(context.Background()))
	require.NoError(t, poolB.Start(context.Background()))
	require.NoError(t, poolA.WarmUp(context.Background()))
	original := rt.snapshotIDs()
	require.Len(t, original, 1)

	poolA.Drain(context.Background())
	assert.Len(t, rt.snapshotIDs(), 1, "rolling shutdown must leave global inventory intact")
	info, err := poolB.Acquire(context.Background())
	require.NoError(t, err)
	_, reused := original[info.RuntimeID]
	assert.True(t, reused)
	poolB.Release(context.Background(), info.RuntimeID)
	poolB.Drain(context.Background())
	// A full API restart must also preserve any compatible refill inventory.
	// Only the explicit release drain below is destructive.

	require.NoError(t, poolB.DrainRelease(context.Background()))
	assert.Empty(t, rt.snapshotIDs())
	keys, err := store.Keys(context.Background(), "ordinarypool:v1:*")
	require.NoError(t, err)
	assert.Empty(t, keys)
}

func TestSharedOrdinaryPoolRollingFingerprintDoesNotDeleteOldReplicaInventory(t *testing.T) {
	rt := newSharedPoolRuntime()
	store := newAtomicMemoryStore()
	oldPool := NewPool(rt, PoolConfig{MinSize: 1, MaxSize: 1, Image: "sandbox:v1"})
	newPool := NewPool(rt, PoolConfig{MinSize: 1, MaxSize: 1, Image: "sandbox:v2"})
	oldPool.EnableShared(store, "sandbox-system")
	newPool.EnableShared(store, "sandbox-system")
	require.NoError(t, oldPool.Start(context.Background()))
	require.NoError(t, newPool.Start(context.Background()))
	t.Cleanup(func() {
		oldPool.Drain(context.Background())
		newPool.Drain(context.Background())
		_ = newPool.DrainRelease(context.Background())
	})

	require.NoError(t, oldPool.WarmUp(context.Background()))
	oldInventory := rt.snapshotIDs()
	require.Len(t, oldInventory, 1)
	require.NoError(t, newPool.WarmUp(context.Background()))
	assert.Len(t, rt.snapshotIDs(), 2, "overlapping image versions must keep separate warm inventory")

	info, err := oldPool.Acquire(context.Background())
	require.NoError(t, err)
	_, reused := oldInventory[info.RuntimeID]
	assert.True(t, reused, "new replica startup must not invalidate an old replica's pool record")
	oldPool.Release(context.Background(), info.RuntimeID)
}

func TestSharedOrdinaryPoolReconcileRepairsPreparedStateLabel(t *testing.T) {
	rt := newSharedPoolRuntime()
	store := newAtomicMemoryStore()
	pool := NewPool(rt, PoolConfig{MinSize: 1, MaxSize: 1, Image: "sandbox:latest"})
	pool.EnableShared(store, "sandbox-system")
	require.NoError(t, pool.Start(context.Background()))
	t.Cleanup(func() { pool.Drain(context.Background()) })
	require.NoError(t, pool.WarmUp(context.Background()))

	rt.mu.Lock()
	for _, info := range rt.sandboxes {
		info.Labels["sandbox.pool.state"] = "preparing"
	}
	rt.mu.Unlock()
	require.NoError(t, pool.Reconcile(context.Background(), nil))

	rt.mu.Lock()
	defer rt.mu.Unlock()
	for _, info := range rt.sandboxes {
		assert.Equal(t, "prepared", info.Labels["sandbox.pool.state"])
	}
}
