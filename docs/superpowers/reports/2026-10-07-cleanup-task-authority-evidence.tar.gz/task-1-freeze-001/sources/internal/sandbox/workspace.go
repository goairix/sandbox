package sandbox

import (
	"archive/tar"
	"context"
	"errors"
	"fmt"
	"io"
	"mime"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/goairix/fs"

	"github.com/goairix/sandbox/internal/fuseprotocol"
	"github.com/goairix/sandbox/internal/logger"
	"github.com/goairix/sandbox/internal/runtime"
	"github.com/goairix/sandbox/internal/storage"
	"github.com/goairix/sandbox/internal/telemetry/metrics"
)

func validatePublicFUSEFilePath(sb *Sandbox, path string) error {
	if sb != nil && sb.Workspace != nil && sb.Workspace.MountType == WorkspaceMountFUSE &&
		fuseprotocol.IsReservedProbeObjectName(filepath.Base(filepath.Clean(path))) {
		return ErrReservedFUSEWorkspacePath
	}
	return nil
}

func hideReservedFUSEFileInfos(sb *Sandbox, files []runtime.FileInfo) []runtime.FileInfo {
	if sb == nil || sb.Workspace == nil || sb.Workspace.MountType != WorkspaceMountFUSE {
		return files
	}
	filtered := files[:0]
	for _, file := range files {
		if !fuseprotocol.IsReservedProbeObjectName(filepath.Base(filepath.Clean(file.Name))) &&
			!fuseprotocol.IsReservedProbeObjectName(filepath.Base(filepath.Clean(file.Path))) {
			filtered = append(filtered, file)
		}
	}
	return filtered
}

// storageWriteOptions returns object-storage metadata based on the file extension.
func storageWriteOptions(name string) []fs.Option {
	ext := strings.ToLower(filepath.Ext(name))
	ct := mime.TypeByExtension(ext)
	if ct == "" {
		ct = "application/octet-stream"
	}

	opts := []fs.Option{fs.WithContentType(ct)}
	if ext == ".html" || ext == ".htm" {
		opts = append(opts, fs.WithContentDisposition("inline"))
	}
	return opts
}

// fileEntry holds metadata for a single file or directory.
type fileEntry struct {
	relPath string
	isDir   bool
	size    int64
	modTime time.Time
}

// isExcluded reports whether path should be skipped during workspace sync.
// A path is excluded if it equals any exclude entry or starts with an exclude
// entry followed by "/". For example, exclude entry ".agent" matches ".agent",
// ".agent/", ".agent/skills/code.yaml", etc.
func isExcluded(path string, exclude []string) bool {
	for _, e := range exclude {
		if path == e || strings.HasPrefix(path, e+"/") {
			return true
		}
	}
	return false
}

// MountWorkspace creates a ScopedFS for the given rootPath, syncs files into the container.
// exclude is an optional list of path prefixes to skip during all subsequent syncs.
func (m *Manager) MountWorkspace(ctx context.Context, sandboxID, rootPath string, exclude []string) error {
	if m.distributedStateEnabled() {
		return m.mountDistributedWorkspace(ctx, sandboxID, rootPath, exclude)
	}
	m.mu.Lock()
	sb := m.sandboxes[sandboxID]
	if sb == nil {
		m.mu.Unlock()
		return fmt.Errorf("%w: %s", ErrSandboxNotFound, sandboxID)
	}
	gate := m.operationGates[sandboxID]
	if gate == nil {
		gate = newOperationGate(true)
		m.operationGates[sandboxID] = gate
	}
	m.mu.Unlock()
	exclusive, err := gate.BeginExclusive(ctx)
	if err != nil {
		return fmt.Errorf("begin workspace mount: %w", err)
	}
	resolved := false
	defer func() {
		if !resolved {
			_ = exclusive.Reopen()
		}
	}()
	m.mu.RLock()
	current := m.sandboxes[sandboxID]
	_, exists := m.workspaces[sandboxID]
	isFUSE := current != nil && current.Workspace != nil && current.Workspace.MountType == WorkspaceMountFUSE
	m.mu.RUnlock()
	if current != sb {
		return fmt.Errorf("%w: %s", ErrSandboxNotReady, sandboxID)
	}
	if isFUSE {
		return fmt.Errorf("%w: %s", ErrFUSEWorkspaceImmutable, sandboxID)
	}
	logger.Info(ctx, "MountWorkspace: starting",
		logger.AddField("sandbox_id", sandboxID),
		logger.AddField("root_path", rootPath),
	)
	if exists {
		return fmt.Errorf("%w: %s", ErrWorkspaceAlreadyMounted, sandboxID)
	}

	scoped, lifecycle, err := m.prepareSyncWorkspace(ctx, sb, gate, rootPath, exclude)
	if err != nil {
		logger.Error(ctx, "MountWorkspace: sync to container failed",
			logger.AddField("sandbox_id", sandboxID),
			logger.AddField("runtime_id", sb.RuntimeID),
			logger.ErrorField(err),
		)
		return err
	}

	now := time.Now()
	workspace := &WorkspaceInfo{
		RootPath:     rootPath,
		MountedAt:    now,
		LastSyncedAt: now,
		SyncExclude:  append([]string(nil), exclude...),
		MountType:    WorkspaceMountSync,
	}
	if lifecycle != nil {
		owner := lifecycle.lease.OwnerSnapshot()
		workspace.Owner = owner
		workspace.LeaseGeneration = owner.Generation
	}
	sessionSnapshot := cloneSandbox(sb)
	sessionSnapshot.Workspace = workspace
	sessionSnapshot.UpdatedAt = now

	if sb.Config.Mode == ModePersistent && m.sessions != nil {
		if err := m.sessions.Save(ctx, &sessionSnapshot); err != nil {
			_ = m.releasePreparedSyncWorkspace(lifecycle)
			return fmt.Errorf("save mounted workspace session: %w", err)
		}
	} else if sb.Config.Mode == ModeEphemeral && lifecycle != nil {
		record, err := m.createWorkspaceLifecycle(ctx, &sessionSnapshot)
		if err != nil {
			_ = m.releasePreparedSyncWorkspace(lifecycle)
			return fmt.Errorf("save ephemeral workspace lifecycle: %w", err)
		}
		lifecycle.ephemeralRecord = record
	}
	err = exclusive.commit(func() error {
		m.mu.Lock()
		defer m.mu.Unlock()
		if m.sandboxes[sandboxID] != sb || m.workspaces[sandboxID] != nil {
			return ErrSandboxNotReady
		}
		if !publishSyncLifecycle(lifecycle) {
			return ErrWorkspaceLeaseLost
		}
		m.workspaces[sandboxID] = scoped
		sb.Workspace = workspace
		sb.UpdatedAt = now
		if lifecycle != nil {
			m.syncLifecycles[sandboxID] = lifecycle
		}
		return nil
	})
	if err != nil {
		_ = m.releasePreparedSyncWorkspace(lifecycle)
		if sb.Config.Mode == ModePersistent && m.sessions != nil {
			_ = m.sessions.RemoveExact(ctx, &sessionSnapshot)
		} else if lifecycle != nil && lifecycle.ephemeralRecord != nil {
			_ = m.removeWorkspaceLifecycle(ctx, &sessionSnapshot, lifecycle.ephemeralRecord)
		}
		resolved = true
		return err
	}
	resolved = true

	logger.Info(ctx, "MountWorkspace: completed",
		logger.AddField("sandbox_id", sandboxID),
		logger.AddField("runtime_id", sb.RuntimeID),
	)

	return nil
}

// UnmountWorkspace syncs files back from container to storage, then detaches.
func (m *Manager) UnmountWorkspace(ctx context.Context, sandboxID string) error {
	if m.distributedStateEnabled() {
		return m.unmountDistributedWorkspace(ctx, sandboxID)
	}
	m.mu.RLock()
	sb := m.sandboxes[sandboxID]
	gate := m.operationGates[sandboxID]
	if sb == nil {
		m.mu.RUnlock()
		return fmt.Errorf("%w: %s", ErrSandboxNotFound, sandboxID)
	}
	runtimeID := sb.RuntimeID
	_, hasWS := m.workspaces[sandboxID]
	isFUSE := sb.Workspace != nil && sb.Workspace.MountType == WorkspaceMountFUSE
	lifecycle := m.syncLifecycles[sandboxID]
	var syncExclude []string
	if sb.Workspace != nil {
		syncExclude = append([]string(nil), sb.Workspace.SyncExclude...)
	}
	m.mu.RUnlock()

	if isFUSE {
		return fmt.Errorf("%w: %s", ErrFUSEWorkspaceImmutable, sandboxID)
	}
	if gate == nil {
		return fmt.Errorf("%w: %s", ErrSandboxNotReady, sandboxID)
	}
	exclusive, err := gate.BeginExclusive(ctx)
	if err != nil {
		return fmt.Errorf("begin workspace unmount: %w", err)
	}
	resolved := false
	defer func() {
		if !resolved {
			_ = exclusive.Reopen()
		}
	}()
	logger.Info(ctx, "UnmountWorkspace: starting",
		logger.AddField("sandbox_id", sandboxID),
	)
	if !hasWS {
		return fmt.Errorf("%w: %s", ErrNoWorkspaceMounted, sandboxID)
	}

	if err := m.syncFromContainer(ctx, sandboxID, runtimeID, syncExclude); err != nil {
		logger.Error(ctx, "UnmountWorkspace: sync from container failed",
			logger.AddField("sandbox_id", sandboxID),
			logger.AddField("runtime_id", runtimeID),
			logger.ErrorField(err),
		)
		return fmt.Errorf("sync from container: %w", err)
	}
	if lifecycle != nil {
		lifecycle.renewal.Stop()
		if err := m.config.WorkspaceCoordinator.Release(ctx, lifecycle.lease, runtime.TerminationEvidence{}); err != nil {
			if renewErr := m.restartSyncRenewal(lifecycle); renewErr != nil {
				exclusive.Close()
				resolved = true
				m.scheduleSyncFinalization(lifecycle, errors.Join(err, renewErr))
			}
			return fmt.Errorf("release workspace lease: %w", err)
		}
	}

	now := time.Now()
	sessionSnapshot := cloneSandbox(sb)
	sessionSnapshot.Workspace = nil
	sessionSnapshot.UpdatedAt = now
	if sb.Config.Mode == ModePersistent && m.sessions != nil {
		if err := m.sessions.Save(ctx, &sessionSnapshot); err != nil {
			exclusive.Close()
			resolved = true
			m.scheduleSyncFinalization(lifecycle, err)
			return fmt.Errorf("save unmounted workspace session: %w", err)
		}
	} else if sb.Config.Mode == ModeEphemeral && lifecycle != nil {
		mountedSnapshot := cloneSandbox(sb)
		if err := m.removeWorkspaceLifecycle(ctx, &mountedSnapshot, lifecycle.ephemeralRecord); err != nil {
			exclusive.Close()
			resolved = true
			m.scheduleSyncFinalization(lifecycle, err)
			return fmt.Errorf("remove ephemeral workspace lifecycle: %w", err)
		}
	}
	err = exclusive.commit(func() error {
		m.mu.Lock()
		defer m.mu.Unlock()
		if m.sandboxes[sandboxID] != sb || m.syncLifecycles[sandboxID] != lifecycle {
			return ErrSandboxNotReady
		}
		delete(m.workspaces, sandboxID)
		delete(m.syncLifecycles, sandboxID)
		sb.Workspace = nil
		sb.UpdatedAt = now
		return nil
	})
	resolved = true
	if err != nil {
		m.scheduleSyncFinalization(lifecycle, err)
		return err
	}

	logger.Info(ctx, "UnmountWorkspace: completed",
		logger.AddField("sandbox_id", sandboxID),
	)

	return nil
}

// SyncWorkspace manually syncs files in the given direction.
// exclude is an optional list of path prefixes to skip during from_container sync.
func (m *Manager) SyncWorkspace(ctx context.Context, sandboxID, direction string, exclude []string) error {
	if direction != "to_container" && direction != "from_container" {
		return fmt.Errorf("invalid sync direction: %s", direction)
	}
	if m.distributedStateEnabled() {
		return m.syncDistributedWorkspace(ctx, sandboxID, direction, exclude)
	}

	m.mu.RLock()
	sb := m.sandboxes[sandboxID]
	isFUSE := sb != nil && sb.Workspace != nil && sb.Workspace.MountType == WorkspaceMountFUSE
	m.mu.RUnlock()

	if isFUSE {
		if direction == "to_container" {
			// A FUSE workspace is already the container's live workspace. Copying
			// object storage into it would bypass the mount protocol.
			_, _, release, err := m.acquireSandboxOperation(ctx, sandboxID)
			if err != nil {
				return err
			}
			release()
			return nil
		}
		return m.flushFUSEWorkspace(ctx, sandboxID)
	}

	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, sandboxID)
	if err != nil {
		return err
	}
	ctx = operationCtx
	defer release()
	m.mu.RLock()
	runtimeID := sb.RuntimeID
	scoped, hasWS := m.workspaces[sandboxID]
	m.mu.RUnlock()

	logger.Info(ctx, "SyncWorkspace: request received",
		logger.AddField("sandbox_id", sandboxID),
		logger.AddField("direction", direction),
	)
	if !hasWS {
		return fmt.Errorf("%w: %s", ErrNoWorkspaceMounted, sandboxID)
	}

	var syncErr error
	syncStart := time.Now()
	switch direction {
	case "to_container":
		syncErr = m.syncToContainer(ctx, scoped, runtimeID)
	case "from_container":
		syncErr = m.syncFromContainer(ctx, sandboxID, runtimeID, exclude)
	}
	syncDuration := time.Since(syncStart).Seconds()

	if syncErr != nil {
		logger.Error(ctx, "SyncWorkspace: failed",
			logger.AddField("sandbox_id", sandboxID),
			logger.AddField("direction", direction),
			logger.ErrorField(syncErr),
		)
		metrics.RecordWorkspaceSync(ctx, direction, "error", syncDuration)
	} else {
		logger.Info(ctx, "SyncWorkspace: completed",
			logger.AddField("sandbox_id", sandboxID),
			logger.AddField("direction", direction),
		)
		metrics.RecordWorkspaceSync(ctx, direction, "success", syncDuration)
	}
	return syncErr
}

// flushFUSEWorkspace obtains exclusive admission, drains all existing API
// streams, and runs the generation-bound quiesce/flush/resume protocol. Any
// ambiguity permanently closes the gate; admission reopens only after the
// runtime and manager still agree on the exact runtime generation.
func (m *Manager) flushFUSEWorkspace(ctx context.Context, sandboxID string) (returnErr error) {
	m.mu.RLock()
	sb := m.sandboxes[sandboxID]
	gate := m.operationGates[sandboxID]
	if sb == nil {
		m.mu.RUnlock()
		return fmt.Errorf("%w: %s", ErrSandboxNotFound, sandboxID)
	}
	if sb.Workspace == nil || sb.Workspace.MountType != WorkspaceMountFUSE {
		m.mu.RUnlock()
		return fmt.Errorf("%w: %s", ErrNoWorkspaceMounted, sandboxID)
	}
	ref := runtime.RuntimeRef{ID: sb.RuntimeID, UID: sb.RuntimeUID}
	generation := sb.Workspace.LeaseGeneration
	m.mu.RUnlock()
	started := time.Now()
	defer func() {
		result := "success"
		if returnErr != nil {
			result = "error"
			metrics.RecordWorkspaceFUSEError(ctx, "flush")
		}
		if m.fusePool != nil && m.fusePool.spec.WorkspaceFUSE != nil {
			spec := m.fusePool.spec.WorkspaceFUSE
			metrics.RecordWorkspaceFlush(ctx, spec.RuntimeType, spec.Provider, result, time.Since(started).Seconds())
		}
	}()

	exclusive, err := gate.BeginExclusive(ctx)
	if err != nil {
		return fmt.Errorf("begin FUSE workspace flush: %w", err)
	}
	reopen := false
	defer func() {
		if !reopen {
			exclusive.Close()
		}
	}()

	err = exclusive.withOwnership(func() error {
		m.mu.Lock()
		current := m.sandboxes[sandboxID]
		if !fuseWorkspaceGenerationMatches(current, ref, generation) {
			m.mu.Unlock()
			return fmt.Errorf("FUSE workspace runtime generation changed")
		}
		current.Workspace.Flushed = false
		current.UpdatedAt = time.Now()
		pendingSnapshot := cloneSandbox(current)
		m.mu.Unlock()
		if err := m.verifyWorkspaceLifecycle(ctx, &pendingSnapshot); err != nil {
			return fmt.Errorf("persist pending FUSE workspace flush: %w", err)
		}
		return nil
	})
	if err != nil {
		return err
	}
	var token runtime.WorkspaceQuiesceToken
	err = exclusive.withOwnership(func() error {
		var quiesceErr error
		token, quiesceErr = m.runtime.QuiesceWorkspace(ctx, ref, generation)
		return quiesceErr
	})
	if err != nil {
		return fmt.Errorf("quiesce FUSE workspace: %w", err)
	}
	if token.RuntimeUID != ref.UID || token.Generation != generation || token.Opaque == "" {
		return fmt.Errorf("quiesce FUSE workspace returned an invalid generation-bound token")
	}
	if err := exclusive.withOwnership(func() error { return m.runtime.FlushWorkspace(ctx, ref, generation) }); err != nil {
		return fmt.Errorf("flush FUSE workspace: %w", err)
	}
	if err := exclusive.withOwnership(func() error { return m.runtime.ResumeWorkspace(ctx, ref, token) }); err != nil {
		return fmt.Errorf("resume FUSE workspace: %w", err)
	}
	var health *runtime.WorkspaceHealth
	err = exclusive.withOwnership(func() error {
		var healthErr error
		health, healthErr = m.runtime.WorkspaceHealth(ctx, ref)
		return healthErr
	})
	if err != nil {
		return fmt.Errorf("verify FUSE workspace after resume: %w", err)
	}
	if health == nil || !health.Ready || health.RuntimeUID != ref.UID || health.Generation != generation || health.MountType != string(WorkspaceMountFUSE) {
		return fmt.Errorf("FUSE workspace generation changed after resume")
	}
	err = exclusive.commit(func() error {
		now := time.Now()
		m.mu.Lock()
		current := m.sandboxes[sandboxID]
		if !fuseWorkspaceGenerationMatches(current, ref, generation) {
			m.mu.Unlock()
			return fmt.Errorf("FUSE workspace runtime generation changed")
		}
		snapshot := cloneSandbox(current)
		snapshot.Workspace.Flushed = true
		snapshot.Workspace.LastFlushedAt = &now
		snapshot.UpdatedAt = now
		m.mu.Unlock()
		if err := m.verifyWorkspaceLifecycle(ctx, &snapshot); err != nil {
			return fmt.Errorf("persist completed FUSE workspace flush: %w", err)
		}
		m.mu.Lock()
		current = m.sandboxes[sandboxID]
		if !fuseWorkspaceGenerationMatches(current, ref, generation) {
			m.mu.Unlock()
			return fmt.Errorf("FUSE workspace runtime generation changed")
		}
		current.Workspace.Flushed = true
		current.Workspace.LastFlushedAt = &now
		current.UpdatedAt = now
		m.mu.Unlock()
		return nil
	})
	if err != nil {
		return fmt.Errorf("reopen FUSE workspace admission: %w", err)
	}
	reopen = true
	return nil
}

func fuseWorkspaceGenerationMatches(sb *Sandbox, ref runtime.RuntimeRef, generation int64) bool {
	if sb == nil || sb.Workspace == nil || sb.Workspace.MountType != WorkspaceMountFUSE ||
		sb.RuntimeID != ref.ID || sb.RuntimeUID != ref.UID || sb.Workspace.LeaseGeneration != generation || generation <= 0 {
		return false
	}
	return true
}

// GetWorkspaceInfo returns workspace info for a sandbox.
func (m *Manager) GetWorkspaceInfo(ctx context.Context, sandboxID string) (*WorkspaceInfo, error) {
	sb, _, release, err := m.acquireSandboxOperation(ctx, sandboxID)
	if err != nil {
		return nil, err
	}
	defer release()
	m.mu.RLock()
	if sb.Workspace == nil {
		m.mu.RUnlock()
		return nil, nil
	}
	workspace := *sb.Workspace
	workspace.SyncExclude = append([]string(nil), sb.Workspace.SyncExclude...)
	if sb.Workspace.LastFlushedAt != nil {
		lastFlushedAt := *sb.Workspace.LastFlushedAt
		workspace.LastFlushedAt = &lastFlushedAt
	}
	m.mu.RUnlock()
	return &workspace, nil
}

// syncToContainer collects file metadata from ScopedFS and streams a tar archive
// into the container via exec pipe. File contents are copied directly from
// storage, so content memory does not grow with the total workspace byte size;
// the entries slice still grows with the number of files and directories.
func (m *Manager) syncToContainer(ctx context.Context, scoped storage.ScopedFS, runtimeID string) error {
	// Phase 1: walk the directory tree to collect file metadata.
	var entries []fileEntry
	if err := m.collectFiles(ctx, scoped, ".", &entries); err != nil {
		logger.Error(ctx, "syncToContainer: collectFiles failed",
			logger.AddField("runtime_id", runtimeID),
			logger.ErrorField(err),
		)
		return fmt.Errorf("collect files: %w", err)
	}
	if len(entries) == 0 {
		logger.Debug(ctx, "syncToContainer: no files to sync",
			logger.AddField("runtime_id", runtimeID),
		)
		return nil
	}

	logger.Debug(ctx, "syncToContainer: starting tar upload",
		logger.AddField("runtime_id", runtimeID),
		logger.AddField("entries", len(entries)),
	)

	// Phase 2: stream tar into container via exec pipe.
	writeErr, execErr := m.streamTarToContainer(ctx, scoped, entries, runtimeID)

	if writeErr != nil {
		logger.Error(ctx, "syncToContainer: write tar stream failed",
			logger.AddField("runtime_id", runtimeID),
			logger.ErrorField(writeErr),
		)
		return fmt.Errorf("write tar stream: %w", writeErr)
	}
	if execErr != nil {
		logger.Error(ctx, "syncToContainer: exec tar extract failed",
			logger.AddField("runtime_id", runtimeID),
			logger.ErrorField(execErr),
		)
		return fmt.Errorf("exec tar extract: %w", execErr)
	}

	logger.Debug(ctx, "syncToContainer: completed",
		logger.AddField("runtime_id", runtimeID),
		logger.AddField("entries", len(entries)),
	)
	return nil
}

// streamTarToContainer connects the tar producer to the runtime consumer.
// It returns both sides' errors so the caller can log the failing phase.
func (m *Manager) streamTarToContainer(
	ctx context.Context,
	scoped storage.ScopedFS,
	entries []fileEntry,
	runtimeID string,
) (writeErr, execErr error) {
	pr, pw := io.Pipe()

	execErrCh := make(chan error, 1)
	go func() {
		execErr := m.runtime.ExecPipe(ctx, runtimeID,
			[]string{"tar", "xf", "-", "-C", "/workspace"}, pr)
		// ExecPipe may return before consuming the stream (for example, when
		// starting tar fails). Closing the reader wakes a producer blocked in
		// io.PipeWriter.Write instead of leaking the sync goroutine forever.
		_ = pr.CloseWithError(execErr)
		execErrCh <- execErr
	}()

	writeErr = m.writeTarStream(ctx, scoped, entries, pw)
	if writeErr != nil {
		_ = pw.CloseWithError(writeErr)
	} else {
		_ = pw.Close()
	}

	execErr = <-execErrCh
	return writeErr, execErr
}

// writeTarStream writes entries directly from storage into the tar stream.
// Files must not be prefetched into []byte: a workspace may contain millions
// of files or tens of GB, so file-content memory must stay bounded even though
// the metadata entries slice is proportional to the number of paths.
func (m *Manager) writeTarStream(ctx context.Context, scoped storage.ScopedFS, entries []fileEntry, w io.Writer) error {
	if len(entries) == 0 {
		return nil
	}

	tw := tar.NewWriter(w)
	for _, e := range entries {
		if err := ctx.Err(); err != nil {
			return err
		}
		if e.isDir {
			if err := tw.WriteHeader(&tar.Header{
				Name:     e.relPath + "/",
				Typeflag: tar.TypeDir,
				Mode:     0755,
				ModTime:  e.modTime,
				Uid:      1000,
				Gid:      1000,
				Format:   tar.FormatPAX,
			}); err != nil {
				return fmt.Errorf("write dir header %q: %w", e.relPath, err)
			}
			continue
		}

		if err := tw.WriteHeader(&tar.Header{
			Name:    e.relPath,
			Size:    e.size,
			Mode:    0644,
			ModTime: e.modTime,
			Uid:     1000,
			Gid:     1000,
			Format:  tar.FormatPAX,
		}); err != nil {
			return fmt.Errorf("write file header %q: %w", e.relPath, err)
		}

		reader, err := scoped.Open(ctx, e.relPath)
		if err != nil {
			return fmt.Errorf("open %q: %w", e.relPath, err)
		}
		written, copyErr := io.Copy(tw, reader)
		closeErr := reader.Close()
		if copyErr != nil {
			return fmt.Errorf("stream %q: %w", e.relPath, copyErr)
		}
		if closeErr != nil {
			return fmt.Errorf("close %q: %w", e.relPath, closeErr)
		}
		if written != e.size {
			return fmt.Errorf("stream %q: size changed during sync: metadata=%d streamed=%d", e.relPath, e.size, written)
		}
	}

	return tw.Close()
}

// collectFiles recursively walks the ScopedFS directory tree and appends
// file/directory metadata to entries. File content is NOT read here.
func (m *Manager) collectFiles(ctx context.Context, scoped storage.ScopedFS, dir string, entries *[]fileEntry) error {
	files, err := scoped.List(ctx, dir)
	if err != nil {
		return err
	}

	for _, fi := range files {
		// Normalize: MinIO returns full object keys, local FS returns base names.
		baseName := filepath.Base(strings.TrimRight(fi.Name(), "/"))
		if baseName == "." || baseName == "" {
			continue
		}

		relPath := baseName
		if dir != "." {
			relPath = filepath.Join(dir, baseName)
		}

		*entries = append(*entries, fileEntry{
			relPath: relPath,
			isDir:   fi.IsDir(),
			size:    fi.Size(),
			modTime: fi.ModTime(),
		})

		if fi.IsDir() {
			if err := m.collectFiles(ctx, scoped, relPath, entries); err != nil {
				return err
			}
		}
	}
	return nil
}

// syncFromContainer incrementally syncs changed files from the container back to storage.
// It compares container file modification times against the last sync timestamp
// and only writes files that were modified since then. Files deleted in the container
// are also removed from storage. Mount sets LastSyncedAt, so every syncFromContainer
// is incremental.
func (m *Manager) syncFromContainer(ctx context.Context, sandboxID, runtimeID string, exclude []string) error {
	m.mu.RLock()
	scoped, ok := m.workspaces[sandboxID]
	sb := m.sandboxes[sandboxID]
	var snapshot Sandbox
	if sb != nil {
		snapshot = cloneSandbox(sb)
	}
	m.mu.RUnlock()
	if !ok {
		return fmt.Errorf("%w: %s", ErrNoWorkspaceMounted, sandboxID)
	}
	if sb == nil {
		return nil
	}
	if err := m.syncFromContainerSnapshot(ctx, &snapshot, scoped, exclude); err != nil {
		return err
	}
	m.mu.Lock()
	if m.sandboxes[sandboxID] == sb && sb.Workspace != nil && snapshot.Workspace != nil {
		sb.Workspace.LastSyncedAt = snapshot.Workspace.LastSyncedAt
		sb.UpdatedAt = snapshot.UpdatedAt
	}
	m.mu.Unlock()
	m.saveSessionIfAlive(ctx, sandboxID, sb)
	return nil
}

// syncFromContainerSnapshot copies from an explicit authoritative snapshot.
// It never obtains workspace identity from a process-local map.
func (m *Manager) syncFromContainerSnapshot(ctx context.Context, sb *Sandbox, scoped storage.ScopedFS, exclude []string) error {
	if sb == nil || sb.Workspace == nil || scoped == nil {
		return ErrNoWorkspaceMounted
	}
	sandboxID, runtimeID := sb.ID, sb.RuntimeID
	bindMounted := sb.Workspace.BindMounted
	lastSyncedAt := sb.Workspace.LastSyncedAt

	// Bind-mounted workspaces share the host filesystem directly — no sync needed.
	if bindMounted {
		logger.Debug(ctx, "syncFromContainer: bind-mounted, skipping",
			logger.AddField("sandbox_id", sandboxID),
		)
		return nil
	}

	// LastSyncedAt is set at mount time; use it as the change detection baseline.
	var cutoff int64
	if !lastSyncedAt.IsZero() {
		cutoff = lastSyncedAt.Unix()
	}

	// Record the sync start time BEFORE collecting the manifest. Any file
	// modified after this point will be picked up by the next sync cycle.
	syncStartedAt := time.Now()

	// Get container file manifest via exec
	manifest, err := m.containerFileManifest(ctx, runtimeID)
	if err != nil {
		if errors.Is(err, runtime.ErrNotFound) {
			logger.Debug(ctx, "syncFromContainer: container not found",
				logger.AddField("sandbox_id", sandboxID),
				logger.AddField("runtime_id", runtimeID),
			)
			return err
		}
		// Fall back to full sync if manifest collection fails
		logger.Warn(ctx, "container manifest failed, falling back to full sync",
			logger.AddField("runtime_id", runtimeID),
			logger.ErrorField(err),
		)
		if err := m.fullSyncFromContainer(ctx, scoped, runtimeID, exclude); err != nil {
			return err
		}
		m.setLastSyncedAt(sb, syncStartedAt)
		return nil
	}

	// Get storage file set
	storageFiles, err := m.storageFileSet(ctx, scoped, ".")
	if err != nil {
		logger.Warn(ctx, "storage file listing failed, falling back to full sync",
			logger.AddField("runtime_id", runtimeID),
			logger.ErrorField(err),
		)
		if err := m.fullSyncFromContainer(ctx, scoped, runtimeID, exclude); err != nil {
			return err
		}
		m.setLastSyncedAt(sb, syncStartedAt)
		return nil
	}

	// Compute changed files: container files that are new or modified since cutoff.
	// Also collect files with mtime=0 so we can touch them after sync to give them
	// a real timestamp for future incremental comparisons.
	changedSet := make(map[string]struct{})
	var zeroMtimeFiles []string
	for path, modtime := range manifest {
		if strings.HasSuffix(path, "/") {
			continue // skip directories
		}
		if isExcluded(path, exclude) {
			continue
		}
		_, inStorage := storageFiles[path]
		// modtime == 0 means the filesystem doesn't track mtime (e.g. some overlay
		// mounts reset it to epoch). Treat it as always-changed so we don't silently
		// skip files whose real modification time is unknown.
		if modtime == 0 {
			zeroMtimeFiles = append(zeroMtimeFiles, path)
		}
		if !inStorage || cutoff == 0 || modtime == 0 || modtime >= cutoff {
			changedSet[path] = struct{}{}
		}
	}

	// Compute deleted files: in storage but not in container
	var deletedFiles []string
	for path := range storageFiles {
		if isExcluded(path, exclude) {
			continue
		}
		if _, exists := manifest[path]; !exists {
			deletedFiles = append(deletedFiles, path)
		}
	}

	// Nothing to do
	if len(changedSet) == 0 && len(deletedFiles) == 0 {
		m.setLastSyncedAt(sb, syncStartedAt)
		return nil
	}

	// Download tar and selectively extract only changed files
	if len(changedSet) > 0 {
		logger.Debug(ctx, "syncFromContainer: downloading changed files",
			logger.AddField("sandbox_id", sandboxID),
			logger.AddField("count", len(changedSet)),
		)
		if err := m.downloadChangedFiles(ctx, scoped, runtimeID, changedSet, exclude); err != nil {
			logger.Error(ctx, "syncFromContainer: download changed files failed",
				logger.AddField("sandbox_id", sandboxID),
				logger.AddField("runtime_id", runtimeID),
				logger.ErrorField(err),
			)
			return fmt.Errorf("download changed files: %w", err)
		}
	}

	// Touch files that had mtime=0 so future incremental syncs can detect real changes.
	if len(zeroMtimeFiles) > 0 {
		m.touchFilesInContainer(ctx, runtimeID, zeroMtimeFiles)
	}

	// Remove deleted files from storage
	for _, path := range deletedFiles {
		if err := scoped.Remove(ctx, path); err != nil {
			return fmt.Errorf("remove deleted workspace object: %w", err)
		}
	}

	logger.Info(ctx, "syncFromContainer: completed",
		logger.AddField("sandbox_id", sandboxID),
		logger.AddField("synced", len(changedSet)),
		logger.AddField("removed", len(deletedFiles)),
	)

	m.setLastSyncedAt(sb, syncStartedAt)
	return nil
}

// setLastSyncedAt updates the LastSyncedAt timestamp under lock.
func (m *Manager) setLastSyncedAt(sb *Sandbox, t time.Time) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if sb == nil || sb.Workspace == nil {
		return
	}
	sb.Workspace.LastSyncedAt = t
	sb.UpdatedAt = t
}

// saveSessionIfAlive persists sb to the session store only if the sandbox is
// still registered in the in-memory map. This prevents a concurrent Destroy
// (which removes the sandbox from the map and deletes the Redis key) from
// having its key re-created by an in-flight autoSync goroutine that captured
// the sb pointer before Destroy ran.
func (m *Manager) saveSessionIfAlive(ctx context.Context, sandboxID string, sb *Sandbox) {
	if sb == nil {
		return
	}
	m.mu.RLock()
	_, alive := m.sandboxes[sandboxID]
	var snapshot Sandbox
	if alive {
		snapshot = cloneSandbox(sb)
	}
	m.mu.RUnlock()
	if alive {
		if snapshot.Config.Mode == ModePersistent && m.sessions != nil {
			_ = m.sessions.Save(ctx, &snapshot)
		} else if snapshot.Config.Mode == ModeEphemeral && snapshot.Workspace != nil && snapshot.Workspace.Owner.Generation > 0 {
			_ = m.verifyWorkspaceLifecycle(ctx, &snapshot)
		}
	}
}

// fullSyncFromContainer downloads the entire /workspace as a tar and extracts all files.
func (m *Manager) fullSyncFromContainer(ctx context.Context, scoped storage.ScopedFS, runtimeID string, exclude []string) error {
	tarReader, err := m.runtime.DownloadDir(ctx, runtimeID, "/workspace")
	if err != nil {
		logger.Error(ctx, "fullSyncFromContainer: download failed",
			logger.AddField("runtime_id", runtimeID),
			logger.ErrorField(err),
		)
		return fmt.Errorf("download workspace: %w", err)
	}
	defer func() { _ = tarReader.Close() }()

	tr := tar.NewReader(tarReader)
	for {
		hdr, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			logger.Error(ctx, "fullSyncFromContainer: read tar entry failed",
				logger.AddField("runtime_id", runtimeID),
				logger.ErrorField(err),
			)
			return fmt.Errorf("read tar entry: %w", err)
		}

		name := strings.TrimPrefix(hdr.Name, "workspace/")
		if name == "" {
			continue
		}

		if isExcluded(name, exclude) {
			continue
		}

		if hdr.Typeflag == tar.TypeDir {
			_ = scoped.MakeDir(ctx, strings.TrimRight(name, "/"), 0755)
			continue
		}

		writer, err := scoped.Create(ctx, name, storageWriteOptions(name)...)
		if err != nil {
			logger.Error(ctx, "fullSyncFromContainer: create file failed",
				logger.AddField("runtime_id", runtimeID),
				logger.AddField("file", name),
				logger.ErrorField(err),
			)
			return fmt.Errorf("create %q: %w", name, err)
		}

		_, copyErr := io.Copy(writer, tr)
		closeErr := writer.Close()
		if copyErr != nil {
			logger.Error(ctx, "fullSyncFromContainer: write file failed",
				logger.AddField("runtime_id", runtimeID),
				logger.AddField("file", name),
				logger.ErrorField(copyErr),
			)
			return fmt.Errorf("write %q: %w", name, copyErr)
		}
		if closeErr != nil {
			logger.Error(ctx, "fullSyncFromContainer: flush file failed",
				logger.AddField("runtime_id", runtimeID),
				logger.AddField("file", name),
				logger.ErrorField(closeErr),
			)
			return fmt.Errorf("flush %q to storage: %w", name, closeErr)
		}
	}

	return nil
}

// downloadChangedFiles downloads the workspace tar and only extracts files in changedSet.
func (m *Manager) downloadChangedFiles(ctx context.Context, scoped storage.ScopedFS, runtimeID string, changedSet map[string]struct{}, exclude []string) error {
	tarReader, err := m.runtime.DownloadDir(ctx, runtimeID, "/workspace")
	if err != nil {
		logger.Error(ctx, "downloadChangedFiles: download failed",
			logger.AddField("runtime_id", runtimeID),
			logger.ErrorField(err),
		)
		return fmt.Errorf("download workspace: %w", err)
	}
	defer func() { _ = tarReader.Close() }()

	tr := tar.NewReader(tarReader)
	for {
		hdr, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			logger.Error(ctx, "downloadChangedFiles: read tar entry failed",
				logger.AddField("runtime_id", runtimeID),
				logger.ErrorField(err),
			)
			return fmt.Errorf("read tar entry: %w", err)
		}

		name := strings.TrimPrefix(hdr.Name, "workspace/")
		if name == "" {
			continue
		}

		if isExcluded(name, exclude) {
			continue
		}

		if hdr.Typeflag == tar.TypeDir {
			_ = scoped.MakeDir(ctx, strings.TrimRight(name, "/"), 0755)
			continue
		}

		// Only write files that are in the changed set
		if _, changed := changedSet[name]; !changed {
			continue
		}

		writer, err := scoped.Create(ctx, name, storageWriteOptions(name)...)
		if err != nil {
			logger.Error(ctx, "downloadChangedFiles: create file failed",
				logger.AddField("runtime_id", runtimeID),
				logger.AddField("file", name),
				logger.ErrorField(err),
			)
			return fmt.Errorf("create %q: %w", name, err)
		}

		_, copyErr := io.Copy(writer, tr)
		closeErr := writer.Close()
		if copyErr != nil {
			logger.Error(ctx, "downloadChangedFiles: write file failed",
				logger.AddField("runtime_id", runtimeID),
				logger.AddField("file", name),
				logger.ErrorField(copyErr),
			)
			return fmt.Errorf("write %q: %w", name, copyErr)
		}
		if closeErr != nil {
			logger.Error(ctx, "downloadChangedFiles: flush file failed",
				logger.AddField("runtime_id", runtimeID),
				logger.AddField("file", name),
				logger.ErrorField(closeErr),
			)
			return fmt.Errorf("flush %q to storage: %w", name, closeErr)
		}
	}

	return nil
}

// containerFileManifest runs `find` inside the container and returns a map of
// relative path → modification time (unix seconds).
// Directory entries have a trailing "/".
func (m *Manager) containerFileManifest(ctx context.Context, runtimeID string) (map[string]int64, error) {
	result, err := m.runtime.Exec(ctx, runtimeID, runtime.ExecRequest{
		Command: "find /workspace -not -path /workspace -printf '%P\\t%Y\\t%T@\\n'",
		WorkDir: "/workspace",
		Timeout: 30,
	})
	if err != nil {
		logger.Error(ctx, "containerFileManifest: exec find failed",
			logger.AddField("runtime_id", runtimeID),
			logger.ErrorField(err),
		)
		return nil, fmt.Errorf("exec find: %w", err)
	}

	manifest := make(map[string]int64)
	for _, line := range strings.Split(strings.TrimSpace(result.Stdout), "\n") {
		if line == "" {
			continue
		}
		parts := strings.SplitN(line, "\t", 3)
		if len(parts) < 3 {
			continue
		}

		path := parts[0]
		fileType := parts[1]

		// Parse modtime (float like "1712345678.123456")
		dotIdx := strings.Index(parts[2], ".")
		tsStr := parts[2]
		if dotIdx > 0 {
			tsStr = parts[2][:dotIdx]
		}
		modtime, err := strconv.ParseInt(tsStr, 10, 64)
		if err != nil {
			continue
		}

		if fileType == "d" {
			manifest[path+"/"] = modtime
		} else {
			manifest[path] = modtime
		}
	}

	return manifest, nil
}

// storageFileSet recursively lists all files in ScopedFS and returns their relative paths.
func (m *Manager) storageFileSet(ctx context.Context, scoped storage.ScopedFS, dir string) (map[string]struct{}, error) {
	result := make(map[string]struct{})
	if err := m.walkStorageFiles(ctx, scoped, dir, result); err != nil {
		return nil, err
	}
	return result, nil
}

// walkStorageFiles recursively walks ScopedFS directories, collecting file paths.
func (m *Manager) walkStorageFiles(ctx context.Context, scoped storage.ScopedFS, dir string, result map[string]struct{}) error {
	files, err := scoped.List(ctx, dir)
	if err != nil {
		return err
	}

	for _, fi := range files {
		baseName := filepath.Base(strings.TrimRight(fi.Name(), "/"))
		if baseName == "." || baseName == "" {
			continue
		}

		relPath := baseName
		if dir != "." {
			relPath = filepath.Join(dir, baseName)
		}

		if fi.IsDir() {
			if err := m.walkStorageFiles(ctx, scoped, relPath, result); err != nil {
				return err
			}
			continue
		}

		result[relPath] = struct{}{}
	}

	return nil
}

const touchBatchSize = 200

// touchFilesInContainer stamps the given paths inside the container with a
// fixed historical timestamp (1970-01-01 00:01:00) so that future incremental
// syncs can skip them unless they are genuinely modified.
//
// We use a fixed past timestamp rather than "now" because the next sync's
// cutoff equals syncStartedAt (recorded before this call). Using "now" would
// produce mtime > cutoff and cause the files to be re-synced every cycle.
// epoch+60 is non-zero (so the manifest parser won't treat it as unknown) and
// safely below any real cutoff.
func (m *Manager) touchFilesInContainer(ctx context.Context, runtimeID string, paths []string) {
	// Validate and escape paths in one pass, skipping any suspicious entries.
	escaped := make([]string, 0, len(paths))
	for _, p := range paths {
		clean := filepath.Clean(p)
		if strings.HasPrefix(clean, "..") || filepath.IsAbs(clean) {
			continue
		}
		q := "'" + strings.ReplaceAll("/workspace/"+clean, "'", "'\\''") + "'"
		escaped = append(escaped, q)
	}

	// Process in batches to stay well within ARG_MAX limits.
	for i := 0; i < len(escaped); i += touchBatchSize {
		end := i + touchBatchSize
		if end > len(escaped) {
			end = len(escaped)
		}
		// -t 197001010001.00 = 1970-01-01 00:01:00 UTC (epoch+60), always < any real cutoff.
		cmd := "touch -t 197001010001.00 " + strings.Join(escaped[i:end], " ")
		if _, err := m.runtime.Exec(ctx, runtimeID, runtime.ExecRequest{
			Command: cmd,
			WorkDir: "/workspace",
			Timeout: 10,
		}); err != nil {
			logger.Warn(ctx, "touchFilesInContainer: touch failed",
				logger.AddField("runtime_id", runtimeID),
				logger.ErrorField(err),
			)
		}
	}
}
