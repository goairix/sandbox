package sandbox

import (
	"context"
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"

	"github.com/goairix/fs"
	"github.com/google/uuid"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/trace"

	"github.com/goairix/sandbox/internal/fuseprotocol"
	"github.com/goairix/sandbox/internal/logger"
	"github.com/goairix/sandbox/internal/runtime"
	"github.com/goairix/sandbox/internal/storage"
	"github.com/goairix/sandbox/internal/storage/state"
	"github.com/goairix/sandbox/internal/telemetry/metrics"
	telemetry "github.com/goairix/sandbox/internal/telemetry/trace"
)

// validDepRegexp validates dependency names and versions to prevent command injection.
var validDepRegexp = regexp.MustCompile(`^[a-zA-Z0-9._-]+$`)

const randSuffixLen = 10
const multipartKeyPrefix = "sandbox:multipart:"
const multipartTTL = 24 * time.Hour

type MultipartUploadState struct {
	UploadID       string    `json:"upload_id"`
	SandboxID      string    `json:"sandbox_id"`
	DestPath       string    `json:"dest_path"`
	TotalChunks    int       `json:"total_chunks"`
	ReceivedChunks int       `json:"received_chunks"`
	CreatedAt      time.Time `json:"created_at"`
}

type fuseBindingClaim struct {
	record          state.FUSEPoolRecord
	returning       bool
	lost            bool
	published       bool
	lifecycle       *fuseSandboxLifecycle
	cleanupRecord   *state.FUSEPoolRecord
	sessionIdentity *Sandbox
	ephemeralRecord *EphemeralLifecycleRecord
}

type fuseSandboxLifecycle struct {
	sandboxID           string
	sandbox             *Sandbox
	gate                *operationGate
	lease               *WorkspaceLease
	renewal             *WorkspaceLeaseRenewal
	record              state.FUSEPoolRecord
	cancel              context.CancelFunc
	teardownMu          sync.Mutex
	teardownRunning     bool
	teardownScheduled   bool
	teardownDone        bool
	lastFailureStage    string
	lastFailureAt       time.Time
	finalizingPersisted bool
	gateClosed          bool
	renewalStopped      bool
	quiesceAttempted    bool
	quiesced            bool
	flushAttempted      bool
	poolRemoved         bool
	claimed             *state.FUSEPoolRecord
	runtimeRemoved      bool
	evidence            runtime.TerminationEvidence
	probeRemoved        bool
	unmountRecorded     bool
	leaseReleased       bool
	sessionRemoved      bool
	ephemeralRecord     *EphemeralLifecycleRecord
	controller          *activeController
}

type syncSandboxLifecycle struct {
	sandboxID       string
	gate            *operationGate
	lease           *WorkspaceLease
	renewal         *WorkspaceLeaseRenewal
	once            sync.Once
	mu              sync.Mutex
	lost            bool
	published       bool
	ephemeralRecord *EphemeralLifecycleRecord
	finalizeMu      sync.Mutex
	finalizeDone    bool
	finalSyncDone   bool
	runtimeRemoved  bool
	controller      *activeController
}

// randSuffix generates a random lowercase alphanumeric string of length n.
func randSuffix(n int) string {
	const alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	for i := range b {
		b[i] = alphabet[b[i]%byte(len(alphabet))]
	}
	return string(b)
}

func multipartKey(sandboxID, uploadID string) string {
	return multipartKeyPrefix + sandboxID + ":" + uploadID
}

// ManagerConfig configures the SandboxManager.
type ManagerConfig struct {
	PoolConfig              PoolConfig
	PoolStateStore          state.AtomicStore
	PoolScope               string
	ActiveSandboxes         state.ActiveSandboxRepository
	InstanceID              string
	ControllerTTL           time.Duration
	ControllerRenewInterval time.Duration
	ActiveOperationTTL      time.Duration
	OperationRenewInterval  time.Duration
	RuntimeType             string
	DefaultMountMode        WorkspaceMountType
	EnabledMountModes       map[WorkspaceMountType]bool
	FUSEPool                *FUSEPool
	WorkspaceCoordinator    *WorkspaceCoordinator
	WorkspaceObjectClient   storage.WorkspaceObjectClient
	WorkspaceMarkerProfile  storage.RootMarkerProfile
	FUSEHealthInterval      time.Duration
	DefaultTimeout          int // seconds
	ExecTimeoutSeconds      int // per-execution timeout; 0 = no limit
	MaxExecTimeoutSeconds   int // maximum request timeout; 0 = no additional maximum
	AutoSyncIntervalSeconds int // 0 = disabled
}

func (m *Manager) resolveWorkspaceMountMode(cfg SandboxConfig) (WorkspaceMountType, error) {
	if cfg.WorkspacePath == "" {
		if cfg.WorkspaceMountMode != "" {
			return "", fmt.Errorf("workspace mount mode requires workspace path: %w", ErrInvalidWorkspaceMountMode)
		}
		return "", nil
	}
	mode := WorkspaceMountType(cfg.WorkspaceMountMode)
	if mode == "" {
		mode = m.config.DefaultMountMode
		if mode == "" {
			mode = WorkspaceMountSync
		}
	}
	if mode != WorkspaceMountSync && mode != WorkspaceMountFUSE {
		return "", fmt.Errorf("unknown workspace mount mode %q: %w", mode, ErrInvalidWorkspaceMountMode)
	}
	enabled := m.config.EnabledMountModes
	if len(enabled) == 0 {
		// Preserve the historical zero-value ManagerConfig as sync-only for
		// internal callers while production wiring always passes the map.
		enabled = map[WorkspaceMountType]bool{WorkspaceMountSync: true}
	}
	if !enabled[mode] {
		return "", fmt.Errorf("workspace mount mode %q is disabled: %w", mode, ErrInvalidWorkspaceMountMode)
	}
	return mode, nil
}

// Manager orchestrates sandbox lifecycle: creation, execution, destruction.
type Manager struct {
	runtime         runtime.Runtime
	filesystem      fs.FileSystem
	fsMeta          *storage.FileSystemMeta
	config          ManagerConfig
	sessions        *SessionStore // optional, for persistent sandboxes
	ephemeral       *EphemeralLifecycleStore
	multipartStore  state.Store // optional, for multipart upload state
	activeSandboxes state.ActiveSandboxRepository

	pool                *Pool
	fusePool            *FUSEPool
	sandboxes           map[string]*Sandbox
	workspaces          map[string]storage.ScopedFS // sandbox ID -> ScopedFS
	operationGates      map[string]*operationGate
	fuseLifecycles      map[string]*fuseSandboxLifecycle
	syncLifecycles      map[string]*syncSandboxLifecycle
	fuseInFlight        map[string]*fuseBindingClaim
	mu                  sync.RWMutex
	workspaceRequestsMu sync.Mutex
	workspaceRequests   map[string]*workspaceRequestLock

	stopCh        chan struct{}
	stopOnce      sync.Once
	shutdownDone  chan struct{}
	shutdownErr   error
	wg            sync.WaitGroup
	createWG      sync.WaitGroup
	lifecycleMu   sync.Mutex
	stopping      bool
	controlCtx    context.Context
	cancelControl context.CancelFunc
	cleanupWake   chan struct{}
}

// NewManager creates a new SandboxManager.
func NewManager(rt runtime.Runtime, fsys fs.FileSystem, fsMeta *storage.FileSystemMeta, cfg ManagerConfig) *Manager {
	controlCtx, cancelControl := context.WithCancel(context.Background())
	pool := NewPool(rt, cfg.PoolConfig)
	if cfg.RuntimeType == "kubernetes" {
		pool.EnableShared(cfg.PoolStateStore, cfg.PoolScope)
	}
	m := &Manager{
		runtime:         rt,
		filesystem:      fsys,
		fsMeta:          fsMeta,
		config:          cfg,
		pool:            pool,
		fusePool:        cfg.FUSEPool,
		activeSandboxes: cfg.ActiveSandboxes,
		sandboxes:       make(map[string]*Sandbox),
		workspaces:      make(map[string]storage.ScopedFS),
		operationGates:  make(map[string]*operationGate),
		fuseLifecycles:  make(map[string]*fuseSandboxLifecycle),
		syncLifecycles:  make(map[string]*syncSandboxLifecycle),
		fuseInFlight:    make(map[string]*fuseBindingClaim),
		stopCh:          make(chan struct{}),
		shutdownDone:    make(chan struct{}),
		controlCtx:      controlCtx,
		cancelControl:   cancelControl,
		cleanupWake:     make(chan struct{}, 1),
	}
	if m.fusePool != nil {
		m.fusePool.config.PristineGuard = m.guardFUSEPoolRecord
	}
	return m
}

func (m *Manager) resolveExecTimeout(requested int) (int, error) {
	if requested < 0 {
		return 0, fmt.Errorf("%w: timeout must not be negative: %d", ErrInvalidExecTimeout, requested)
	}
	if m.config.MaxExecTimeoutSeconds > 0 && requested > m.config.MaxExecTimeoutSeconds {
		return 0, fmt.Errorf("%w: requested %d seconds exceeds maximum %d seconds", ErrInvalidExecTimeout, requested, m.config.MaxExecTimeoutSeconds)
	}
	if requested == 0 {
		return m.config.ExecTimeoutSeconds, nil
	}
	return requested, nil
}

func execTimeoutSource(requested int) string {
	if requested == 0 {
		return "default"
	}
	return "request"
}

func newExecContext(parent context.Context, effectiveTimeout int) (context.Context, context.CancelFunc) {
	if effectiveTimeout > 0 {
		return context.WithTimeoutCause(parent, time.Duration(effectiveTimeout)*time.Second, ErrExecTimeout)
	}
	return context.WithCancel(parent)
}

func isExecTimeout(parentCtx, execCtx context.Context, err error, effectiveTimeout int) bool {
	if errors.Is(context.Cause(execCtx), ErrExecTimeout) {
		return true
	}
	return effectiveTimeout > 0 && errors.Is(err, context.DeadlineExceeded) && parentCtx.Err() == nil
}

func execFailureStatus(parentCtx, execCtx context.Context, err error, effectiveTimeout int, timeoutSource string) string {
	if isExecTimeout(parentCtx, execCtx, err, effectiveTimeout) {
		return "timeout_" + timeoutSource
	}
	if parentCtx.Err() != nil || context.Cause(execCtx) != nil {
		return "caller_cancelled"
	}
	return "error"
}

func sendStreamTerminal(outCh chan runtime.StreamEvent, event runtime.StreamEvent) {
	select {
	case outCh <- event:
		return
	default:
	}

	// The buffer is full. Drop the oldest ordinary event to reserve room for
	// the terminal event without waiting for a slow or disconnected consumer.
	select {
	case <-outCh:
	default:
	}
	select {
	case outCh <- event:
	default:
	}
}

// SetSessionStore sets an optional SessionStore for persistent sandbox state.
func (m *Manager) SetSessionStore(ss *SessionStore) {
	m.sessions = ss
}

// SetEphemeralLifecycleStore sets the private, non-user-visible cleanup store
// used by ephemeral workspaces.
func (m *Manager) SetEphemeralLifecycleStore(store *EphemeralLifecycleStore) {
	m.ephemeral = store
}

// SetMultipartStore sets the state.Store used for multipart upload state.
func (m *Manager) SetMultipartStore(s state.Store) {
	m.multipartStore = s
}

// Ready reports whether this replica can safely accept Kubernetes requests.
// Liveness intentionally remains independent so dependency outages do not
// cause restart storms.
func (m *Manager) Ready(ctx context.Context) error {
	m.lifecycleMu.Lock()
	stopping := m.stopping
	m.lifecycleMu.Unlock()
	if stopping {
		return errors.New("sandbox manager is stopping")
	}
	if m.pool.shared != nil && (m.pool.shared.ctx.Err() != nil || !m.pool.shared.ownerHealthy.Load()) {
		return errors.New("ordinary pool owner lease lost")
	}
	if m.fusePool != nil && m.fusePool.shared != nil && (m.fusePool.loopCtx.Err() != nil || !m.fusePool.shared.healthy.Load()) {
		return errors.New("FUSE pool owner lease lost")
	}
	if m.distributedStateEnabled() {
		if err := m.activeSandboxes.Ping(ctx); err != nil {
			return fmt.Errorf("active sandbox state: %w", err)
		}
	}
	if checker, ok := m.runtime.(interface{ Ping(context.Context) error }); ok {
		if err := checker.Ping(ctx); err != nil {
			return fmt.Errorf("runtime: %w", err)
		}
	}
	return nil
}

// Start initializes the manager and warms up the pool.
// It first removes any orphaned pool containers left over from a previous
// process that exited without cleanup (e.g. crash, SIGKILL).
func (m *Manager) Start(ctx context.Context) error {
	spanCtx, span := telemetry.Tracer().Start(ctx, "sandbox.Manager.Start")
	defer span.End()

	fuseEnabled := m.config.EnabledMountModes[WorkspaceMountFUSE]
	if m.config.RuntimeType == "kubernetes" && m.config.PoolConfig.MinSize > 0 && !m.pool.Shared() {
		return errors.Join(ErrInvalidOrdinaryPoolConfig, errors.New("kubernetes warm pool requires a shared state store and scope"))
	}
	if fuseEnabled {
		if m.fusePool == nil {
			return errors.Join(ErrInvalidFUSEPoolConfig, errors.New("FUSE mode requires a FUSE pool"))
		}
	}

	// Restore state before either pool becomes available so live runtimes are
	// protected from orphan reconciliation. FUSE remains fail-closed; sync-only
	// retains best-effort recovery for compatibility.
	if !m.distributedStateEnabled() {
		if err := m.restorePersistentSandboxes(spanCtx); err != nil {
			if fuseEnabled {
				return fmt.Errorf("restore persistent sandboxes for FUSE mode: %w", err)
			}
			logger.Error(spanCtx, "failed to restore persistent sandboxes", logger.ErrorField(err))
		}
	}
	if !m.distributedStateEnabled() {
		if err := m.finalizeEphemeralLifecycles(spanCtx); err != nil {
			return fmt.Errorf("finalize ephemeral workspace lifecycles: %w", err)
		}
	}
	if fuseEnabled {
		if err := m.reconcileFUSEOrphans(spanCtx); err != nil {
			return fmt.Errorf("reconcile FUSE runtime orphans: %w", err)
		}
	}
	if m.pool.Shared() {
		if err := m.pool.Start(spanCtx); err != nil {
			return fmt.Errorf("register shared ordinary pool owner: %w", err)
		}
		activeRuntimeIDs := make(map[string]struct{})
		m.mu.RLock()
		for _, sb := range m.sandboxes {
			activeRuntimeIDs[sb.RuntimeID] = struct{}{}
		}
		m.mu.RUnlock()
		if err := m.pool.Reconcile(spanCtx, activeRuntimeIDs); err != nil {
			return fmt.Errorf("reconcile shared ordinary pool: %w", err)
		}
	} else {
		m.cleanupOrphanedPoolContainers(spanCtx)
	}
	if err := m.pool.WarmUp(spanCtx); err != nil {
		return fmt.Errorf("warm ordinary pool: %w", err)
	}
	if fuseEnabled {
		if err := m.fusePool.Start(spanCtx); err != nil {
			m.pool.Drain(context.Background())
			return fmt.Errorf("start FUSE pool: %w", err)
		}
	}
	if m.distributedStateEnabled() {
		if err := m.reconcileActiveLifecycleControllers(spanCtx); err != nil {
			return fmt.Errorf("reconcile active lifecycle controllers: %w", err)
		}
		m.wg.Add(1)
		go m.runActiveLifecycleCoordinator()
	}

	m.wg.Add(1)
	go m.reapExpiredSandboxes()

	if m.config.AutoSyncIntervalSeconds > 0 {
		m.wg.Add(1)
		go m.autoSyncWorkspaces()
	}
	return nil
}

// reconcileFUSEOrphans is deliberately invoked only after session recovery
// and before pool reconciliation. It combines every durable source of runtime
// ownership; any unreadable source aborts cleanup rather than supplying an
// incomplete allow-delete set.
func (m *Manager) reconcileFUSEOrphans(ctx context.Context) error {
	return m.reconcileFUSEOrphansWithExclusivity(ctx, false)
}

func (m *Manager) reconcileFUSEOrphansWithExclusivity(ctx context.Context, releaseExclusive bool) error {
	// Namespace-wide snapshot cleanup cannot fence concurrent preparations or
	// registrations. Shared controllers own normal cleanup through exact CAS;
	// this legacy orphan sweep is permitted only after every replica is drained.
	if m.fusePool != nil && m.fusePool.shared != nil && !releaseExclusive {
		return nil
	}
	reconciler, ok := m.runtime.(runtime.OrphanReconciler)
	if !ok {
		return nil
	}
	if m.sessions == nil || m.fusePool == nil || m.config.WorkspaceCoordinator == nil {
		return ErrInvalidFUSEPoolConfig
	}
	protected := make(map[string]struct{})
	ids, err := m.sessions.List(ctx)
	if err != nil {
		return fmt.Errorf("list protected FUSE sessions: %w", err)
	}
	for _, id := range ids {
		sb, err := m.sessions.Load(ctx, id)
		if err != nil {
			return fmt.Errorf("load protected FUSE session %q: %w", id, err)
		}
		if sb.ID != id || (sb.RuntimeUID != "" && validateOpaqueText(sb.RuntimeUID, false) != nil) {
			return ErrSandboxNotReady
		}
		if sb.RuntimeUID != "" {
			protected[sb.RuntimeUID] = struct{}{}
		}
	}
	if m.ephemeral != nil {
		records, err := m.ephemeral.List(ctx)
		if err != nil {
			return fmt.Errorf("list protected ephemeral lifecycles: %w", err)
		}
		for _, record := range records {
			if validateOpaqueText(record.RuntimeUID, false) != nil {
				return ErrEphemeralLifecycleInvalid
			}
			protected[record.RuntimeUID] = struct{}{}
		}
	}
	ownerUIDs, err := m.config.WorkspaceCoordinator.ProtectedRuntimeUIDs(ctx)
	if err != nil {
		return err
	}
	for uid := range ownerUIDs {
		protected[uid] = struct{}{}
	}
	records, err := m.fusePool.repo.ListByPoolKey(ctx, m.fusePool.poolKey)
	if err != nil {
		return fmt.Errorf("list protected FUSE pool records: %w", err)
	}
	for _, record := range records {
		if record.RuntimeUID != "" {
			if validateOpaqueText(record.RuntimeUID, false) != nil {
				return state.ErrFUSEPoolCorrupt
			}
			protected[record.RuntimeUID] = struct{}{}
		}
	}
	return reconciler.ReconcileOrphanedResources(ctx, protected)
}

// Stop shuts down process-local controllers. Shared Kubernetes inventory and
// business runtimes survive; DrainRelease is the explicit destructive path.
func (m *Manager) Stop(ctx context.Context) error {
	_, span := telemetry.Tracer().Start(ctx, "sandbox.Manager.Stop")
	defer span.End()

	m.stopOnce.Do(func() {
		m.lifecycleMu.Lock()
		m.stopping = true
		m.cancelControl()
		close(m.stopCh)
		m.lifecycleMu.Unlock()
		go m.finishShutdown()
	})
	select {
	case <-m.shutdownDone:
		return m.shutdownErr
	case <-ctx.Done():
		return ctx.Err()
	}
}

// BeginShutdown removes this replica from readiness before the HTTP server is
// drained. It deliberately leaves controllers and request leases alive until
// Stop so in-flight requests remain fenced throughout graceful shutdown.
func (m *Manager) BeginShutdown() {
	m.lifecycleMu.Lock()
	m.stopping = true
	m.lifecycleMu.Unlock()
}

func (m *Manager) finishShutdown() {
	defer close(m.shutdownDone)
	var shutdownErr error
	m.createWG.Wait()
	m.mu.RLock()
	lifecycles := make([]*fuseSandboxLifecycle, 0, len(m.fuseLifecycles))
	for _, lifecycle := range m.fuseLifecycles {
		lifecycles = append(lifecycles, lifecycle)
	}
	syncLifecycles := make([]*syncSandboxLifecycle, 0, len(m.syncLifecycles))
	for _, lifecycle := range m.syncLifecycles {
		syncLifecycles = append(syncLifecycles, lifecycle)
	}
	m.mu.RUnlock()
	for _, lifecycle := range syncLifecycles {
		if m.distributedStateEnabled() {
			if lifecycle.renewal != nil {
				lifecycle.renewal.Stop()
			}
		} else if lifecycle.ephemeralRecord != nil {
			if err := m.destroySyncSandbox(context.Background(), lifecycle); err != nil {
				shutdownErr = errors.Join(shutdownErr, err)
			}
		} else if lifecycle.renewal != nil {
			lifecycle.renewal.Stop()
		}
		if lifecycle.controller != nil {
			shutdownErr = errors.Join(shutdownErr, lifecycle.controller.Stop(context.Background()))
		}
	}
	for _, lifecycle := range lifecycles {
		if m.distributedStateEnabled() {
			lifecycle.cancel()
			if lifecycle.renewal != nil {
				lifecycle.renewal.Stop()
			}
		} else if lifecycle.sandbox != nil && lifecycle.sandbox.Config.Mode == ModeEphemeral {
			m.runFUSETeardown(context.Background(), lifecycle, ErrSandboxNotReady)
		} else {
			lifecycle.cancel()
			lifecycle.renewal.Stop()
		}
		if lifecycle.controller != nil {
			shutdownErr = errors.Join(shutdownErr, lifecycle.controller.Stop(context.Background()))
		}
	}
	m.wg.Wait()
	if m.fusePool != nil {
		shutdownErr = errors.Join(shutdownErr, m.fusePool.Stop(context.Background()))
	}
	m.pool.Drain(context.Background())
	m.shutdownErr = shutdownErr
}

// DrainRelease performs the destructive, release-wide drain used only for a
// backend switch or Helm deletion. Unlike Stop, it finalizes persistent state.
func (m *Manager) DrainRelease(ctx context.Context) error {
	started := false
	m.stopOnce.Do(func() {
		started = true
		m.lifecycleMu.Lock()
		m.stopping = true
		m.cancelControl()
		close(m.stopCh)
		m.lifecycleMu.Unlock()
	})
	if !started {
		select {
		case <-m.shutdownDone:
			return m.shutdownErr
		case <-ctx.Done():
			return ctx.Err()
		}
	}
	defer close(m.shutdownDone)

	created := make(chan struct{})
	go func() {
		m.createWG.Wait()
		close(created)
	}()
	select {
	case <-created:
	case <-ctx.Done():
		m.shutdownErr = ctx.Err()
		return m.shutdownErr
	}

	m.mu.RLock()
	needRestore := len(m.sandboxes) == 0
	m.mu.RUnlock()
	var drainErr error
	if m.distributedStateEnabled() {
		drainErr = errors.Join(drainErr, m.drainDistributedActiveSandboxes(ctx))
	}
	if needRestore && m.sessions != nil {
		if !m.distributedStateEnabled() {
			drainErr = errors.Join(drainErr, m.restorePersistentSandboxes(ctx))
		}
	}

	m.mu.RLock()
	syncLifecycles := make([]*syncSandboxLifecycle, 0, len(m.syncLifecycles))
	for _, lifecycle := range m.syncLifecycles {
		syncLifecycles = append(syncLifecycles, lifecycle)
	}
	fuseLifecycles := make([]*fuseSandboxLifecycle, 0, len(m.fuseLifecycles))
	for _, lifecycle := range m.fuseLifecycles {
		fuseLifecycles = append(fuseLifecycles, lifecycle)
	}
	m.mu.RUnlock()
	for _, lifecycle := range syncLifecycles {
		if err := m.destroySyncSandbox(ctx, lifecycle); err != nil {
			drainErr = errors.Join(drainErr, err)
		}
	}
	for _, lifecycle := range fuseLifecycles {
		m.runFUSETeardown(ctx, lifecycle, ErrSandboxCleanupPending)
		lifecycle.teardownMu.Lock()
		done := lifecycle.teardownDone
		lifecycle.teardownMu.Unlock()
		if !done {
			drainErr = errors.Join(drainErr, ErrSandboxCleanupPending)
		}
	}

	// Sandboxes without a coordinated workspace still need exact gate drain,
	// session removal, and runtime removal during a release-wide drain.
	m.mu.RLock()
	remaining := make([]*Sandbox, 0, len(m.sandboxes))
	for id, sb := range m.sandboxes {
		if m.syncLifecycles[id] == nil && m.fuseLifecycles[id] == nil {
			copy := cloneSandbox(sb)
			remaining = append(remaining, &copy)
		}
	}
	m.mu.RUnlock()
	for _, sb := range remaining {
		m.mu.RLock()
		gate := m.operationGates[sb.ID]
		m.mu.RUnlock()
		if gate != nil {
			drainErr = errors.Join(drainErr, gate.CloseAndWait(ctx))
		}
		if sb.Config.Mode == ModePersistent && m.sessions != nil {
			drainErr = errors.Join(drainErr, m.sessions.Remove(ctx, sb.ID))
		}
		if err := m.runtime.RemoveSandbox(ctx, sb.RuntimeID); err != nil {
			drainErr = errors.Join(drainErr, err)
			continue
		}
		m.mu.Lock()
		delete(m.sandboxes, sb.ID)
		delete(m.workspaces, sb.ID)
		delete(m.operationGates, sb.ID)
		m.mu.Unlock()
	}

	if m.ephemeral != nil {
		drainErr = errors.Join(drainErr, m.finalizeEphemeralLifecycles(ctx))
	}
	if m.fusePool != nil {
		// A stopped refill can leave a FUSE Pod behind before its RuntimeUID is
		// bound into the preparing record. Remove those unprotected runtime
		// orphans first so pool cleanup can retire the record in this pass.
		drainErr = errors.Join(drainErr, m.reconcileFUSEOrphansWithExclusivity(ctx, true))
		drainErr = errors.Join(drainErr, m.fusePool.DrainRelease(ctx))
		// Pool finalization may leave policy-only artifacts after Pods disappear.
		drainErr = errors.Join(drainErr, m.reconcileFUSEOrphansWithExclusivity(ctx, true))
	}
	drainErr = errors.Join(drainErr, m.pool.DrainRelease(ctx))
	if m.config.RuntimeType == "kubernetes" {
		drainErr = errors.Join(drainErr, m.drainOrphanedOrdinaryPoolContainers(ctx))
		if reconciler, ok := m.runtime.(runtime.ReleaseOrphanReconciler); ok {
			drainErr = errors.Join(drainErr, reconciler.ReconcileReleaseOrphanedResources(ctx))
		}
	}
	if m.sessions != nil {
		drainErr = errors.Join(drainErr, AuditDrainedState(ctx, m.sessions.store))
	}
	m.shutdownErr = drainErr
	return drainErr
}

// Create creates a new sandbox.
func (m *Manager) Create(ctx context.Context, cfg SandboxConfig) (*Sandbox, error) {
	m.lifecycleMu.Lock()
	if m.stopping {
		m.lifecycleMu.Unlock()
		return nil, ErrSandboxNotReady
	}
	m.createWG.Add(1)
	m.lifecycleMu.Unlock()
	defer m.createWG.Done()
	cfg = cloneSandboxConfig(cfg)
	workspaceMountMode, err := m.resolveWorkspaceMountMode(cfg)
	if err != nil {
		return nil, err
	}
	cfg.WorkspaceMountMode = WorkspaceMountMode(workspaceMountMode)
	createCtx, cancelCreate := context.WithCancel(ctx)
	stopCreate := context.AfterFunc(m.controlCtx, cancelCreate)
	defer stopCreate()
	defer cancelCreate()
	spanCtx, span := telemetry.Tracer().Start(createCtx, "sandbox.Manager.Create")
	defer span.End()
	if workspaceMountMode == WorkspaceMountFUSE {
		sb, err := m.createFUSESandbox(spanCtx, cfg)
		if err == nil {
			metrics.SandboxActiveGauge.Add(spanCtx, 1)
		}
		return sb, err
	}

	createStart := time.Now()

	timeout := cfg.Timeout
	if timeout == 0 {
		timeout = m.config.DefaultTimeout
	}

	var timeoutDuration time.Duration
	if timeout < 0 {
		// -1 means never expire
		timeoutDuration = -1
	} else {
		timeoutDuration = time.Duration(timeout) * time.Second
	}

	m.mu.Lock()
	id := fmt.Sprintf("sandbox-%s", randSuffix(randSuffixLen))
	m.mu.Unlock()

	var info *runtime.SandboxInfo
	var bindMounted bool
	var source string

	useBindMount := cfg.WorkspacePath != "" && m.fsMeta != nil && m.fsMeta.Provider == storage.ProviderLocal

	if cfg.Network.Enabled || useBindMount || !ordinaryResourcesCompatible(cfg.Resources, m.pool.config) {
		source = "direct"
		spec := m.buildSpec(id, cfg)
		fillOrdinaryResourceDefaults(&spec, cfg.Resources, m.pool.config)
		if useBindMount {
			hostPath := m.resolveLocalWorkspacePath(cfg.WorkspacePath)
			spec.Mounts = append(spec.Mounts, runtime.Mount{
				HostPath:      hostPath,
				ContainerPath: "/workspace",
			})
			bindMounted = true
		}
		info, err = m.runtime.CreateSandbox(spanCtx, spec)
		if err != nil {
			telemetry.Error(err, span)
			metrics.RecordSandboxCreate(spanCtx, source, "error", 0)
			metrics.RecordError(spanCtx, "create_failed")
			return nil, fmt.Errorf("create sandbox: %w", err)
		}
	} else {
		source = "pool"
		info, err = m.pool.Acquire(spanCtx)
		if err != nil {
			telemetry.Error(err, span)
			metrics.RecordSandboxCreate(spanCtx, source, "error", 0)
			metrics.RecordError(spanCtx, "create_failed")
			return nil, fmt.Errorf("acquire container: %w", err)
		}
		// Publish business ownership. Kubernetes uses UID-bound annotations and
		// an effective label view; physical CNI labels remain immutable on checkout.
		ref := runtime.RuntimeRef{ID: info.RuntimeID, UID: info.RuntimeUID}
		var claimErr error
		if claimer, ok := m.runtime.(runtime.OrdinaryPoolClaimer); ok {
			claimErr = claimer.ClaimOrdinaryPool(spanCtx, ref, id)
		} else {
			claimErr = m.runtime.UpdateLabels(spanCtx, info.RuntimeID, map[string]*string{"sandbox.pool": nil, "sandbox.id": &id})
		}
		if claimErr != nil {
			cleanupCtx, cancel := context.WithTimeout(context.Background(), workspaceCleanupTimeout)
			var removeErr error
			if remover, ok := m.runtime.(runtime.OrdinarySandboxRemover); ok {
				removeErr = remover.RemoveOrdinarySandbox(cleanupCtx, ref)
			} else {
				removeErr = m.runtime.RemoveSandbox(cleanupCtx, info.RuntimeID)
			}
			if removeErr == nil {
				_ = m.pool.ConfirmAcquired(cleanupCtx, info)
			}
			cancel()
			m.pool.NotifyRemoved()
			return nil, errors.Join(fmt.Errorf("claim pooled sandbox: %w", claimErr), removeErr)
		}
		if err := m.pool.ConfirmAcquired(spanCtx, info); err != nil {
			// The Pod is already atomically de-pooled by the runtime identity
			// migration. A durable claim residue is safe and reconciliation will
			// retire it, so do not fail an otherwise successful sandbox create.
			logger.Error(spanCtx, "failed to retire ordinary pool claim",
				logger.AddField("runtime_id", info.RuntimeID), logger.ErrorField(err))
		}
	}
	if err := spanCtx.Err(); err != nil {
		cleanupCtx, cancel := context.WithTimeout(context.Background(), workspaceCleanupTimeout)
		defer cancel()
		_ = m.runtime.RemoveSandbox(cleanupCtx, info.RuntimeID)
		if source == "pool" {
			m.pool.NotifyRemoved()
		}
		return nil, errors.Join(ErrSandboxNotReady, err)
	}

	// Rename container for easier identification (best-effort)
	_ = m.runtime.RenameSandbox(spanCtx, info.RuntimeID, id)

	sb := &Sandbox{
		ID:         id,
		Config:     cfg,
		State:      StateReady,
		CreatedAt:  time.Now(),
		UpdatedAt:  time.Now(),
		RuntimeID:  info.RuntimeID,
		RuntimeUID: info.RuntimeUID,
		Timeout:    timeoutDuration,
	}

	// Install dependencies if requested
	if len(cfg.Dependencies) > 0 {
		installCmd := buildInstallCommand(cfg.Dependencies)
		if installCmd != "" {
			depStart := time.Now()
			if _, err := m.runtime.Exec(spanCtx, info.RuntimeID, runtime.ExecRequest{
				Command: installCmd,
				WorkDir: "/workspace",
				Timeout: 120, // 2 min for dependency install
			}); err != nil {
				logger.Error(spanCtx, "Create: install dependencies failed",
					logger.AddField("sandbox_id", id),
					logger.AddField("runtime_id", info.RuntimeID),
					logger.ErrorField(err),
				)
				metrics.RecordDependencyInstall(spanCtx, "error", time.Since(depStart).Seconds())
				// Cleanup on failure
				_ = m.runtime.RemoveSandbox(spanCtx, info.RuntimeID)
				metrics.RecordSandboxCreate(spanCtx, source, "error", 0)
				metrics.RecordError(spanCtx, "install_dependencies_failed")
				return nil, fmt.Errorf("install dependencies: %w", err)
			}
			metrics.RecordDependencyInstall(spanCtx, "success", time.Since(depStart).Seconds())
		}
	}

	gate := newOperationGate(true)
	if cfg.WorkspacePath != "" && !bindMounted {
		scoped, lifecycle, mountErr := m.prepareSyncWorkspace(spanCtx, sb, gate, cfg.WorkspacePath, cfg.WorkspaceSyncExclude)
		if mountErr != nil {
			_ = m.runtime.RemoveSandbox(context.WithoutCancel(spanCtx), info.RuntimeID)
			if source == "pool" {
				m.pool.NotifyRemoved()
			}
			metrics.RecordSandboxCreate(spanCtx, source, "error", 0)
			metrics.RecordError(spanCtx, "mount_workspace_failed")
			return nil, fmt.Errorf("mount workspace: %w", mountErr)
		}
		now := time.Now()
		workspace := &WorkspaceInfo{RootPath: cfg.WorkspacePath, MountedAt: now, LastSyncedAt: now,
			SyncExclude: append([]string(nil), cfg.WorkspaceSyncExclude...), MountType: WorkspaceMountSync}
		if lifecycle != nil {
			owner := lifecycle.lease.OwnerSnapshot()
			workspace.Owner = owner
			workspace.LeaseGeneration = owner.Generation
		}
		sb.Workspace = workspace
		sb.UpdatedAt = now
		if cfg.Mode == ModePersistent && m.sessions != nil {
			if saveErr := m.sessions.Save(spanCtx, sb); saveErr != nil {
				_ = m.releasePreparedSyncWorkspace(lifecycle)
				_ = m.runtime.RemoveSandbox(context.WithoutCancel(spanCtx), info.RuntimeID)
				if source == "pool" {
					m.pool.NotifyRemoved()
				}
				return nil, fmt.Errorf("persist mounted sandbox: %w", saveErr)
			}
		} else if cfg.Mode == ModeEphemeral && lifecycle != nil {
			record, lifecycleErr := m.createWorkspaceLifecycle(spanCtx, sb)
			if lifecycleErr != nil {
				_ = m.releasePreparedSyncWorkspace(lifecycle)
				_ = m.runtime.RemoveSandbox(context.WithoutCancel(spanCtx), info.RuntimeID)
				if source == "pool" {
					m.pool.NotifyRemoved()
				}
				return nil, fmt.Errorf("persist ephemeral workspace lifecycle: %w", lifecycleErr)
			}
			lifecycle.ephemeralRecord = record
		}
		controller, publishErr := m.publishActiveSandboxState(spanCtx, sb, lifecycle != nil)
		if publishErr != nil {
			_ = m.releasePreparedSyncWorkspace(lifecycle)
			if cfg.Mode == ModePersistent && m.sessions != nil {
				_ = m.sessions.RemoveExact(context.WithoutCancel(spanCtx), sb)
			} else if lifecycle != nil && lifecycle.ephemeralRecord != nil {
				_ = m.removeWorkspaceLifecycle(context.WithoutCancel(spanCtx), sb, lifecycle.ephemeralRecord)
			}
			_ = m.runtime.RemoveSandbox(context.WithoutCancel(spanCtx), info.RuntimeID)
			if source == "pool" {
				m.pool.NotifyRemoved()
			}
			return nil, fmt.Errorf("publish sandbox: %w", publishErr)
		}
		if lifecycle != nil && controller != nil {
			m.bindSyncController(lifecycle, controller)
		}
		m.mu.Lock()
		if !publishSyncLifecycle(lifecycle) {
			m.mu.Unlock()
			_ = m.releasePreparedSyncWorkspace(lifecycle)
			if cfg.Mode == ModePersistent && m.sessions != nil {
				_ = m.sessions.RemoveExact(context.WithoutCancel(spanCtx), sb)
			} else if lifecycle != nil && lifecycle.ephemeralRecord != nil {
				_ = m.removeWorkspaceLifecycle(context.WithoutCancel(spanCtx), sb, lifecycle.ephemeralRecord)
			}
			_ = m.runtime.RemoveSandbox(context.WithoutCancel(spanCtx), info.RuntimeID)
			return nil, ErrWorkspaceLeaseLost
		}
		m.sandboxes[id] = sb
		m.operationGates[id] = gate
		m.workspaces[id] = scoped
		if lifecycle != nil {
			m.syncLifecycles[id] = lifecycle
		}
		m.mu.Unlock()
	} else {
		if err := m.publishActiveSandbox(spanCtx, sb); err != nil {
			_ = m.runtime.RemoveSandbox(context.WithoutCancel(spanCtx), info.RuntimeID)
			if source == "pool" {
				m.pool.NotifyRemoved()
			}
			return nil, fmt.Errorf("publish sandbox: %w", err)
		}
		m.mu.Lock()
		m.sandboxes[id] = sb
		m.operationGates[id] = gate
		m.mu.Unlock()

		if cfg.Mode == ModePersistent && m.sessions != nil {
			if err := m.sessions.Save(spanCtx, sb); err != nil {
				logger.Error(spanCtx, "Create: persist sandbox to session store failed",
					logger.AddField("sandbox_id", id), logger.ErrorField(err))
			}
		}

		if cfg.WorkspacePath != "" && bindMounted {
			// Bind mount: just register the scoped FS, no file copy needed.
			if err := m.registerWorkspace(spanCtx, id, cfg.WorkspacePath); err != nil {
				_ = m.runtime.RemoveSandbox(spanCtx, info.RuntimeID)
				m.mu.Lock()
				delete(m.sandboxes, id)
				delete(m.operationGates, id)
				m.mu.Unlock()
				metrics.RecordSandboxCreate(spanCtx, source, "error", 0)
				metrics.RecordError(spanCtx, "register_workspace_failed")
				return nil, fmt.Errorf("register workspace: %w", err)
			}
		}
	}

	span.SetAttributes(attribute.String("sandbox.id", id))
	metrics.SandboxActiveGauge.Add(spanCtx, 1)
	metrics.RecordSandboxCreate(spanCtx, source, "success", time.Since(createStart).Seconds())
	m.mu.RLock()
	result := cloneSandbox(sb)
	m.mu.RUnlock()
	return &result, nil
}

func (m *Manager) createFUSESandbox(ctx context.Context, cfg SandboxConfig) (_ *Sandbox, returnErr error) {
	if m.fusePool == nil || m.config.WorkspaceCoordinator == nil || m.config.WorkspaceObjectClient == nil || m.fsMeta == nil || m.sessions == nil || m.fusePool.spec.WorkspaceFUSE == nil {
		return nil, ErrInvalidFUSEPoolConfig
	}
	mountStarted := time.Now()
	stage, stageStarted := "prefix", time.Now()
	recordStage := func(result string) {
		spec := m.fusePool.spec.WorkspaceFUSE
		metrics.RecordWorkspaceStage(ctx, spec.RuntimeType, spec.Provider, stage, result, time.Since(stageStarted).Seconds())
	}
	nextStage := func(next string) {
		recordStage("success")
		stage, stageStarted = next, time.Now()
	}
	defer func() {
		result := "success"
		if returnErr != nil {
			result = "error"
		}
		recordStage(result)
	}()
	defer func() {
		result := "success"
		if returnErr != nil {
			result = "error"
		}
		spec := m.fusePool.spec.WorkspaceFUSE
		metrics.RecordWorkspaceMount(ctx, spec.RuntimeType, spec.Provider, result, time.Since(mountStarted).Seconds())
	}()
	if !fuseResourcesCompatible(cfg.Resources, m.fusePool.spec) {
		return nil, errors.Join(ErrInvalidFUSEPoolConfig, errors.New("requested resources do not match the prepared FUSE pool"))
	}
	prefix, err := storage.BuildWorkspacePrefix(m.fsMeta.SubPath, cfg.WorkspacePath)
	if err != nil {
		return nil, err
	}
	id := fmt.Sprintf("sandbox-%s", randSuffix(randSuffixLen))
	timeout := cfg.Timeout
	if timeout == 0 {
		timeout = m.config.DefaultTimeout
	}
	timeoutDuration := time.Duration(timeout) * time.Second
	if timeout < 0 {
		timeoutDuration = -1
	}

	txnCtx, cancelTxn := context.WithCancel(ctx)
	stopTxn := context.AfterFunc(m.controlCtx, cancelTxn)
	defer stopTxn()
	defer cancelTxn()
	nextStage("pool_acquire")
	record, err := m.fusePool.Acquire(txnCtx, m.fusePool.poolKey)
	if err != nil {
		return nil, fmt.Errorf("acquire FUSE sandbox: %w", err)
	}
	claim := &fuseBindingClaim{record: *record}
	m.mu.Lock()
	m.fuseInFlight[record.PreparationID] = claim
	m.mu.Unlock()

	var lease *WorkspaceLease
	var renewal *WorkspaceLeaseRenewal
	bindingStarted := false
	var ambiguousAfter *state.FUSEPoolRecord
	published := false
	defer func() {
		if published {
			return
		}
		m.mu.RLock()
		cleanupRecord := claim.record
		m.mu.RUnlock()
		cleanupErr := m.cleanupFailedFUSECreate(cleanupRecord, ambiguousAfter, lease, renewal, claim, bindingStarted)
		if cleanupErr != nil {
			m.scheduleFailedFUSECreateCleanup(cleanupRecord, ambiguousAfter, lease, renewal, claim, bindingStarted)
		} else {
			m.mu.Lock()
			delete(m.fuseInFlight, record.PreparationID)
			m.mu.Unlock()
		}
		returnErr = errors.Join(returnErr, cleanupErr)
	}()

	nextStage("lease_acquire")
	lease, err = m.config.WorkspaceCoordinator.Acquire(txnCtx, WorkspaceLeaseRequest{
		MountType:       WorkspaceMountFUSE,
		Provider:        m.fusePool.spec.WorkspaceFUSE.Provider,
		StorageIdentity: m.fusePool.spec.WorkspaceFUSE.StorageIdentity,
		Bucket:          m.fusePool.spec.WorkspaceFUSE.Bucket,
		Prefix:          prefix,
		SandboxID:       id,
		Runtime:         m.fusePool.spec.WorkspaceFUSE.RuntimeType,
		RuntimeID:       record.RuntimeID,
	})
	if err != nil {
		bindingStarted = errors.Is(err, ErrWorkspaceAcquireCleanupUnconfirmed)
		return nil, fmt.Errorf("acquire workspace lease: %w", err)
	}
	var lifecycle *fuseSandboxLifecycle
	renewal, err = m.config.WorkspaceCoordinator.StartRenewal(context.Background(), lease, func(lost error) {
		m.mu.Lock()
		claim.lost = true
		published := claim.published
		publishedLifecycle := claim.lifecycle
		m.mu.Unlock()
		cancelTxn()
		if published && publishedLifecycle != nil {
			m.scheduleFUSETeardown(publishedLifecycle, lost)
		}
	})
	if err != nil {
		return nil, fmt.Errorf("start workspace lease renewal: %w", err)
	}
	nextStage("prefix_prepare")
	if err = storage.PrepareWorkspacePrefix(txnCtx, m.config.WorkspaceObjectClient, prefix, m.config.WorkspaceMarkerProfile); err != nil {
		return nil, err
	}
	nextStage("runtime_bind")
	err = m.config.WorkspaceCoordinator.BindRuntime(txnCtx, lease, record.RuntimeUID)
	bindingStarted = lease.RuntimeBindingMatches(record.RuntimeUID)
	if err != nil {
		return nil, fmt.Errorf("bind workspace runtime: %w", err)
	}
	nextStage("mount_authorization")
	auth, err := m.config.WorkspaceCoordinator.ConsumeMountAttempt(txnCtx, lease, record.PoolKey)
	if err != nil {
		return nil, fmt.Errorf("consume workspace mount attempt: %w", err)
	}
	nextRecord, err := m.fusePool.repo.Transition(txnCtx, record.PreparationID, state.FUSEPoolReserved, state.FUSEPoolBinding, record.ReservationToken, record.Revision)
	if err != nil {
		possibleAfter := expectedPublication(claim.record, state.FUSEPoolBinding, claim.record.ReservationToken)
		ambiguousAfter = &possibleAfter
		return nil, fmt.Errorf("publish FUSE binding: %w", err)
	}
	record = nextRecord
	m.mu.Lock()
	claim.record = *record
	m.mu.Unlock()
	runtimeRef, refErr := runtime.NewRuntimeRef(record.RuntimeID, record.RuntimeUID)
	if refErr != nil {
		return nil, fmt.Errorf("construct exact FUSE runtime reference: %w", refErr)
	}
	if err = m.runtime.AuthorizeWorkspaceMount(txnCtx, runtimeRef, auth); err != nil {
		return nil, fmt.Errorf("authorize workspace mount: %w", err)
	}
	nextStage("network")
	if err = m.runtime.UpdateFUSENetwork(txnCtx, runtimeRef, cfg.Network.Enabled, cfg.Network.Whitelist, cfg.Network.BlockPrivate); err != nil {
		return nil, fmt.Errorf("update sandbox network: %w", err)
	}
	nextStage("readiness")
	readyInfo, err := m.runtime.WaitSandboxReady(txnCtx, runtimeRef, auth.LeaseGeneration)
	if err != nil {
		return nil, fmt.Errorf("wait FUSE sandbox ready: %w", err)
	}
	if readyInfo == nil || readyInfo.RuntimeID != record.RuntimeID || readyInfo.RuntimeUID != record.RuntimeUID {
		return nil, fmt.Errorf("wait FUSE sandbox ready: runtime identity changed")
	}
	nextStage("pool_consume")
	nextRecord, err = m.fusePool.repo.Transition(txnCtx, record.PreparationID, state.FUSEPoolBinding, state.FUSEPoolConsumed, record.ReservationToken, record.Revision)
	if err != nil {
		possibleAfter := expectedPublication(claim.record, state.FUSEPoolConsumed, claim.record.ReservationToken)
		ambiguousAfter = &possibleAfter
		return nil, fmt.Errorf("consume FUSE sandbox: %w", err)
	}
	record = nextRecord
	m.mu.Lock()
	claim.record = *record
	m.mu.Unlock()
	nextStage("dependencies")
	if len(cfg.Dependencies) > 0 {
		if command := buildInstallCommand(cfg.Dependencies); command != "" {
			if _, err = m.runtime.Exec(txnCtx, record.RuntimeID, runtime.ExecRequest{Command: command, WorkDir: "/workspace", Timeout: 120}); err != nil {
				return nil, fmt.Errorf("install dependencies: %w", err)
			}
		}
	}
	now := time.Now()
	owner := lease.OwnerSnapshot()
	sb := &Sandbox{
		ID: id, Config: cfg, State: StateReady, CreatedAt: now, UpdatedAt: now,
		RuntimeID: record.RuntimeID, RuntimeUID: record.RuntimeUID, Timeout: timeoutDuration,
		Workspace: &WorkspaceInfo{
			RootPath: cfg.WorkspacePath, MountedAt: now, LastHealthyAt: now,
			MountType: WorkspaceMountFUSE, MountState: WorkspaceMountReady, Driver: m.fusePool.spec.WorkspaceFUSE.Driver,
			Owner: owner, LeaseGeneration: owner.Generation,
			FUSEPreparationID: record.PreparationID, FUSEPoolKey: record.PoolKey,
			FUSEReservationToken: record.ReservationToken, FUSERecordRevision: record.Revision,
		},
	}
	gate := newOperationGate(true)
	lifecycleCtx, cancelLifecycle := context.WithCancel(context.Background())
	lifecycle = &fuseSandboxLifecycle{sandboxID: id, sandbox: sb, gate: gate, lease: lease, renewal: renewal, record: *record, cancel: cancelLifecycle}
	_ = lifecycleCtx
	m.mu.Lock()
	sessionIdentity := cloneSandbox(sb)
	claim.sessionIdentity = &sessionIdentity
	m.mu.Unlock()
	nextStage("publish")
	if err = m.publishSandboxLifecycle(txnCtx, sb, gate, lifecycle, claim); err != nil {
		cancelLifecycle()
		return nil, err
	}
	published = true
	m.mu.RLock()
	result := cloneSandbox(sb)
	m.mu.RUnlock()
	m.startFUSEWatcher(lifecycleCtx, lifecycle)
	return &result, nil
}

func fuseResourcesCompatible(requested ResourceLimits, prepared runtime.SandboxSpec) bool {
	return (requested.Memory == "" || requested.Memory == prepared.Memory) &&
		(requested.CPU == "" || requested.CPU == prepared.CPU) &&
		(requested.Disk == "" || requested.Disk == prepared.Disk) &&
		(requested.TmpDisk == "" || requested.TmpDisk == prepared.TmpDisk)
}

func (m *Manager) publishSandboxLifecycle(ctx context.Context, sb *Sandbox, gate *operationGate, lifecycle *fuseSandboxLifecycle, claim *fuseBindingClaim) error {
	ephemeralRecord, err := m.createWorkspaceLifecycle(ctx, sb)
	if err != nil {
		cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), workspaceCleanupTimeout)
		defer cancel()
		if sb.Config.Mode == ModePersistent && m.sessions != nil {
			return errors.Join(fmt.Errorf("save FUSE sandbox lifecycle: %w", err), m.sessions.RemoveExact(cleanupCtx, sb))
		}
		return fmt.Errorf("save FUSE sandbox lifecycle: %w", err)
	}
	lifecycle.ephemeralRecord = ephemeralRecord
	claim.ephemeralRecord = ephemeralRecord
	controller, publishErr := m.publishActiveSandboxState(ctx, sb, true)
	if publishErr != nil {
		cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), workspaceCleanupTimeout)
		defer cancel()
		return errors.Join(fmt.Errorf("publish active FUSE sandbox: %w", publishErr), m.removeWorkspaceLifecycle(cleanupCtx, sb, ephemeralRecord))
	}
	if controller != nil {
		m.bindFUSEController(lifecycle, controller)
	}
	m.mu.Lock()
	if ctx.Err() != nil || claim.lost {
		m.mu.Unlock()
		cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), workspaceCleanupTimeout)
		defer cancel()
		return errors.Join(ErrWorkspaceLeaseLost, m.removeWorkspaceLifecycle(cleanupCtx, sb, ephemeralRecord))
	}
	m.lifecycleMu.Lock()
	stopping := m.stopping
	m.lifecycleMu.Unlock()
	if stopping {
		m.mu.Unlock()
		cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), workspaceCleanupTimeout)
		defer cancel()
		return errors.Join(ErrSandboxNotReady, m.removeWorkspaceLifecycle(cleanupCtx, sb, ephemeralRecord))
	}
	m.sandboxes[sb.ID] = sb
	m.operationGates[sb.ID] = gate
	m.fuseLifecycles[sb.ID] = lifecycle
	delete(m.fuseInFlight, lifecycle.record.PreparationID)
	claim.published = true
	claim.lifecycle = lifecycle
	m.mu.Unlock()
	return nil
}

func (m *Manager) cleanupFailedFUSECreate(record state.FUSEPoolRecord, ambiguousAfter *state.FUSEPoolRecord, lease *WorkspaceLease, renewal *WorkspaceLeaseRenewal, claim *fuseBindingClaim, bindingStarted bool) error {
	timeout := workspaceCleanupTimeout
	if bindingStarted {
		timeout = m.fuseTeardownTimeout()
	}
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	if !bindingStarted {
		if lease != nil {
			if err := m.config.WorkspaceCoordinator.Release(ctx, lease, runtime.TerminationEvidence{}); err != nil {
				return err
			}
		}
		if renewal != nil {
			renewal.Stop()
		}
		m.mu.Lock()
		claim.returning = true
		m.mu.Unlock()
		if err := m.fusePool.ReturnPrepared(ctx, record); errors.Is(err, ErrFUSEPoolReturnFenced) {
			return nil
		} else {
			return err
		}
	}
	var claimed *state.FUSEPoolRecord
	var err error
	m.mu.RLock()
	if claim.cleanupRecord != nil {
		copy := *claim.cleanupRecord
		claimed = &copy
	}
	m.mu.RUnlock()
	if claimed == nil {
		if ambiguousAfter != nil {
			claimed, err = m.fusePool.claimAmbiguousCleanup(record, *ambiguousAfter)
		} else {
			claimed, err = m.fusePool.ClaimSingleUseCleanup(ctx, record)
		}
		if err == nil {
			m.mu.Lock()
			copy := *claimed
			claim.cleanupRecord = &copy
			m.mu.Unlock()
		}
	}
	if err != nil {
		return err
	}
	updatedClaimed, removeErr := m.fusePool.RemoveClaimedRuntime(ctx, *claimed)
	if updatedClaimed != nil {
		claimed = updatedClaimed
		m.mu.Lock()
		copy := *claimed
		claim.cleanupRecord = &copy
		m.mu.Unlock()
	}
	if removeErr != nil {
		return removeErr
	}
	evidence, ok := poolTerminationEvidence(*claimed)
	if !ok {
		fencer, available := m.runtime.(runtime.RuntimeFencer)
		if !available {
			return ErrRuntimeExitUnconfirmed
		}
		evidence, err = fencer.ConfirmTerminated(ctx, record.RuntimeID, record.RuntimeUID)
		if err != nil {
			return err
		}
	}
	if lease != nil {
		if err := m.config.WorkspaceCoordinator.Release(ctx, lease, evidence); err != nil {
			return err
		}
	}
	if renewal != nil {
		renewal.Stop()
	}
	m.mu.RLock()
	sessionIdentity := claim.sessionIdentity
	ephemeralRecord := claim.ephemeralRecord
	m.mu.RUnlock()
	if sessionIdentity != nil {
		workspace := sessionIdentity.Workspace
		if workspace == nil {
			return ErrSessionPublicationConflict
		}
		if err := m.removeWorkspaceLifecycle(ctx, sessionIdentity, ephemeralRecord); err != nil {
			return err
		}
	}
	return m.fusePool.CompleteClaimedCleanup(ctx, *claimed)
}

func (m *Manager) scheduleFailedFUSECreateCleanup(record state.FUSEPoolRecord, ambiguousAfter *state.FUSEPoolRecord, lease *WorkspaceLease, renewal *WorkspaceLeaseRenewal, claim *fuseBindingClaim, bindingStarted bool) {
	m.wg.Add(1)
	go func() {
		defer m.wg.Done()
		for {
			if err := m.cleanupFailedFUSECreate(record, ambiguousAfter, lease, renewal, claim, bindingStarted); err == nil {
				m.mu.Lock()
				delete(m.fuseInFlight, record.PreparationID)
				m.mu.Unlock()
				return
			}
			time.Sleep(100 * time.Millisecond)
		}
	}()
}

func (m *Manager) guardFUSEPoolRecord(ctx context.Context, record state.FUSEPoolRecord) (FUSEPoolDisposition, error) {
	m.mu.RLock()
	claim := m.fuseInFlight[record.PreparationID]
	if claim != nil {
		returning := claim.returning
		m.mu.RUnlock()
		if returning {
			return FUSEPoolPristine, nil
		}
		return FUSEPoolProtected, nil
	}
	for id, lifecycle := range m.fuseLifecycles {
		if lifecycle.record.RuntimeUID == record.RuntimeUID || lifecycle.record.PreparationID == record.PreparationID {
			_ = id
			m.mu.RUnlock()
			return FUSEPoolProtected, nil
		}
	}
	m.mu.RUnlock()
	if m.sessions != nil {
		ids, err := m.sessions.List(ctx)
		if err != nil {
			return FUSEPoolDispositionUnknown, err
		}
		for _, id := range ids {
			sb, err := m.sessions.Load(ctx, id)
			if err != nil {
				return FUSEPoolDispositionUnknown, err
			}
			if sb.RuntimeUID == record.RuntimeUID || (sb.Workspace != nil && sb.Workspace.FUSEPreparationID == record.PreparationID) {
				return FUSEPoolProtected, nil
			}
		}
	}
	if m.ephemeral != nil {
		records, err := m.ephemeral.List(ctx)
		if err != nil {
			return FUSEPoolDispositionUnknown, err
		}
		for _, lifecycle := range records {
			if lifecycle.RuntimeUID == record.RuntimeUID || lifecycle.PreparationID == record.PreparationID {
				return FUSEPoolProtected, nil
			}
		}
	}
	if m.config.WorkspaceCoordinator != nil {
		protected, err := m.config.WorkspaceCoordinator.HasRuntimeOwner(ctx, record.RuntimeID, record.RuntimeUID)
		if err != nil {
			return FUSEPoolDispositionUnknown, err
		}
		if protected {
			return FUSEPoolProtected, nil
		}
	}
	if record.State == state.FUSEPoolBinding || record.State == state.FUSEPoolConsumed {
		return FUSEPoolAbandoned, nil
	}
	return FUSEPoolPristine, nil
}

func (m *Manager) startFUSEWatcher(ctx context.Context, lifecycle *fuseSandboxLifecycle) {
	interval := m.config.FUSEHealthInterval
	if interval <= 0 {
		interval = 5 * time.Second
	}
	m.wg.Add(1)
	go func() {
		defer m.wg.Done()
		ticker := time.NewTicker(interval)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-m.stopCh:
				if !m.distributedStateEnabled() && lifecycle.sandbox != nil && lifecycle.sandbox.Config.Mode == ModeEphemeral {
					m.runFUSETeardown(context.Background(), lifecycle, ErrSandboxNotReady)
				}
				return
			case <-ticker.C:
				if err := m.checkFUSELifecycle(ctx, lifecycle); err != nil {
					metrics.RecordWorkspaceUnavailable(ctx, "health_check")
					metrics.RecordWorkspaceFUSEError(ctx, "health")
					m.scheduleFUSETeardown(lifecycle, err)
					return
				}
			}
		}
	}()
}

func (m *Manager) checkFUSELifecycle(ctx context.Context, lifecycle *fuseSandboxLifecycle) error {
	if m.distributedStateEnabled() {
		_, operationCtx, release, err := m.beginDistributedOperation(ctx, lifecycle.sandboxID, state.ActiveOperationData)
		if errors.Is(err, ErrSandboxNotReady) || errors.Is(err, state.ErrActiveSandboxAdmissionClosed) || errors.Is(err, state.ErrActiveSandboxConflict) {
			// Runtime inspection can also return NotReady. Only authoritative
			// closed admission proves that this health check should be skipped.
			record, loadErr := m.activeSandboxes.Load(ctx, lifecycle.sandboxID)
			if loadErr != nil {
				return errors.Join(err, loadErr)
			}
			if record != nil && (record.Phase == state.ActiveSandboxExclusive || record.Phase == state.ActiveSandboxDestroying || record.Phase == state.ActiveSandboxCleanupPending) {
				return nil
			}
		}
		if err != nil {
			return err
		}
		defer release()
		ctx = operationCtx
	}
	info, err := m.runtime.GetSandbox(ctx, lifecycle.record.RuntimeID)
	if err != nil {
		return err
	}
	if info == nil || info.RuntimeUID != lifecycle.record.RuntimeUID || info.State != "running" {
		return ErrSandboxNotReady
	}
	health, err := m.runtime.WorkspaceHealth(ctx, runtime.RuntimeRef{ID: lifecycle.record.RuntimeID, UID: lifecycle.record.RuntimeUID})
	if err != nil {
		return err
	}
	if health != nil && m.fusePool != nil && m.fusePool.spec.WorkspaceFUSE != nil {
		spec := m.fusePool.spec.WorkspaceFUSE
		metrics.RecordWorkspaceFUSECache(ctx, spec.RuntimeType, spec.Provider, health.CacheBytes)
		if health.CacheExceeded || (health.CacheLimitBytes > 0 && health.CacheBytes >= health.CacheLimitBytes) {
			metrics.RecordWorkspaceFUSEError(ctx, "cache_threshold")
		}
	}
	if health == nil || !health.Ready || health.MountType != "fuse" || health.RuntimeUID != lifecycle.record.RuntimeUID || health.Generation != lifecycle.lease.OwnerSnapshot().Generation || health.RestartCount != 0 || health.RestartDetected {
		return ErrSandboxNotReady
	}
	m.mu.Lock()
	if sb := m.sandboxes[lifecycle.sandboxID]; sb != nil && sb.Workspace != nil {
		sb.Workspace.LastHealthyAt = time.Now()
	}
	m.mu.Unlock()
	return nil
}

func (m *Manager) teardownFUSESandbox(lifecycle *fuseSandboxLifecycle, cause error) {
	ctx, cancel := context.WithTimeout(context.Background(), m.fuseTeardownTimeout())
	defer cancel()
	m.teardownFUSESandboxWithContext(ctx, lifecycle, cause)
}

func (m *Manager) teardownFUSESandboxWithContext(ctx context.Context, lifecycle *fuseSandboxLifecycle, cause error) {
	m.teardownFUSESandboxWithResult(ctx, lifecycle, cause)
}

func (m *Manager) teardownFUSESandboxWithResult(ctx context.Context, lifecycle *fuseSandboxLifecycle, cause error) bool {
	if lifecycle == nil {
		return false
	}
	lifecycle.teardownMu.Lock()
	if lifecycle.teardownRunning || lifecycle.teardownDone {
		lifecycle.teardownMu.Unlock()
		return false
	}
	lifecycle.teardownRunning = true
	lifecycle.teardownMu.Unlock()
	defer func() {
		lifecycle.teardownMu.Lock()
		lifecycle.teardownRunning = false
		lifecycle.teardownMu.Unlock()
	}()

	lifecycle.cancel()
	_ = cause
	if lifecycle.controller != nil {
		if err := lifecycle.controller.Fence(ctx); err != nil {
			m.logFUSETeardownFailure(lifecycle, "controller-fence", err)
			return false
		}
	}
	if err := m.beginActiveCleanup(ctx, lifecycle.sandboxID); err != nil {
		m.logFUSETeardownFailure(lifecycle, "drain-distributed-operations", err)
		return false
	}
	if !lifecycle.gateClosed {
		if err := lifecycle.gate.CloseAndWait(ctx); err != nil {
			m.logFUSETeardownFailure(lifecycle, "close-operation-gate", err)
			return false
		}
		lifecycle.gateClosed = true
	}
	if !lifecycle.finalizingPersisted {
		m.mu.RLock()
		sb := m.sandboxes[lifecycle.sandboxID]
		if sb == nil {
			sb = lifecycle.sandbox
		}
		snapshot := cloneSandbox(sb)
		m.mu.RUnlock()
		if sb == nil || sb.Workspace == nil {
			m.logFUSETeardownFailure(lifecycle, "load-lifecycle", ErrSandboxNotReady)
			return false
		}
		snapshot.State = StateDestroying
		snapshot.UpdatedAt = time.Now()
		if snapshot.Config.Mode == ModePersistent {
			if m.sessions == nil || m.sessions.Save(ctx, &snapshot) != nil {
				m.logFUSETeardownFailure(lifecycle, "persist-finalizing", ErrSessionPublicationConflict)
				return false
			}
		} else if lifecycle.ephemeralRecord != nil && lifecycle.ephemeralRecord.State == EphemeralActive {
			next, err := m.ephemeral.Transition(ctx, lifecycle.sandboxID, lifecycle.ephemeralRecord.Revision, EphemeralFinalizing)
			if err != nil {
				m.logFUSETeardownFailure(lifecycle, "persist-finalizing", err)
				return false
			}
			lifecycle.ephemeralRecord = next
		}
		m.mu.Lock()
		if current := m.sandboxes[lifecycle.sandboxID]; current != nil {
			current.State = StateDestroying
			current.UpdatedAt = snapshot.UpdatedAt
		}
		m.mu.Unlock()
		lifecycle.finalizingPersisted = true
	}
	if !lifecycle.renewalStopped {
		lifecycle.renewal.Stop()
		lifecycle.renewalStopped = true
	}
	ctx, cancel := context.WithTimeout(ctx, m.fuseTeardownTimeout())
	defer cancel()
	ref := runtime.RuntimeRef{ID: lifecycle.record.RuntimeID, UID: lifecycle.record.RuntimeUID}
	generation := lifecycle.lease.OwnerSnapshot().Generation
	if !lifecycle.quiesceAttempted {
		if lifecycle.controller != nil {
			if err := lifecycle.controller.Fence(ctx); err != nil {
				m.logFUSETeardownFailure(lifecycle, "controller-fence-quiesce", err)
				return false
			}
		}
		token, err := m.runtime.QuiesceWorkspace(ctx, ref, generation)
		if err == nil && token.RuntimeUID == ref.UID && token.Generation == generation && token.Opaque != "" {
			lifecycle.quiesceAttempted = true
			lifecycle.quiesced = true
		} else {
			if err == nil {
				err = errors.New("invalid generation-bound quiesce token")
			}
			m.logFUSETeardownFailure(lifecycle, "quiesce", err)
			return false
		}
	}
	if lifecycle.quiesced && !lifecycle.flushAttempted {
		if lifecycle.controller != nil {
			if err := lifecycle.controller.Fence(ctx); err != nil {
				m.logFUSETeardownFailure(lifecycle, "controller-fence-flush", err)
				return false
			}
		}
		started := time.Now()
		flushErr := m.runtime.FlushWorkspace(ctx, ref, generation)
		result := "success"
		if flushErr != nil {
			result = "error"
			metrics.RecordWorkspaceFUSEError(ctx, "flush")
		}
		if m.fusePool.spec.WorkspaceFUSE != nil {
			spec := m.fusePool.spec.WorkspaceFUSE
			metrics.RecordWorkspaceFlush(ctx, spec.RuntimeType, spec.Provider, result, time.Since(started).Seconds())
		}
		if flushErr != nil {
			m.logFUSETeardownFailure(lifecycle, "durable-flush", flushErr)
			return false
		}
		lifecycle.flushAttempted = true
	}
	if lifecycle.ephemeralRecord != nil && lifecycle.ephemeralRecord.State == EphemeralFinalizing {
		next, err := m.ephemeral.Transition(ctx, lifecycle.sandboxID, lifecycle.ephemeralRecord.Revision, EphemeralRemovingRuntime)
		if err != nil {
			m.logFUSETeardownFailure(lifecycle, "persist-durable-flush", err)
			return false
		}
		lifecycle.ephemeralRecord = next
	}
	if lifecycle.claimed == nil {
		if err := m.checkpointFUSECleanup(ctx, lifecycle); err != nil {
			m.logFUSETeardownFailure(lifecycle, "checkpoint-durable-flush", err)
			return false
		}
		if lifecycle.controller != nil {
			if err := lifecycle.controller.Fence(ctx); err != nil {
				m.logFUSETeardownFailure(lifecycle, "controller-fence-pool-claim", err)
				return false
			}
		}
		claimed, err := m.fusePool.ClaimSingleUseCleanup(ctx, lifecycle.record)
		if err != nil {
			m.logFUSETeardownFailure(lifecycle, "claim-pool-cleanup", err)
			return false
		}
		lifecycle.claimed = claimed
	}
	if err := m.checkpointFUSECleanup(ctx, lifecycle); err != nil {
		m.logFUSETeardownFailure(lifecycle, "checkpoint-cleanup-claim", err)
		return false
	}
	if !lifecycle.runtimeRemoved {
		if lifecycle.controller != nil {
			if err := lifecycle.controller.Fence(ctx); err != nil {
				m.logFUSETeardownFailure(lifecycle, "controller-fence-runtime-remove", err)
				return false
			}
		}
		updatedClaimed, err := m.fusePool.RemoveClaimedRuntime(ctx, *lifecycle.claimed)
		if updatedClaimed != nil {
			lifecycle.claimed = updatedClaimed
		}
		if err != nil {
			m.logFUSETeardownFailure(lifecycle, "remove-runtime", err)
			return false
		}
		lifecycle.runtimeRemoved = true
	}
	if err := m.checkpointFUSECleanup(ctx, lifecycle); err != nil {
		m.logFUSETeardownFailure(lifecycle, "checkpoint-runtime-termination", err)
		return false
	}
	if lifecycle.ephemeralRecord != nil && lifecycle.ephemeralRecord.State == EphemeralRemovingRuntime {
		next, err := m.ephemeral.Transition(ctx, lifecycle.sandboxID, lifecycle.ephemeralRecord.Revision, EphemeralReleasingLease)
		if err != nil {
			m.logFUSETeardownFailure(lifecycle, "persist-runtime-removed", err)
			return false
		}
		lifecycle.ephemeralRecord = next
	}
	if lifecycle.ephemeralRecord != nil && lifecycle.ephemeralRecord.State != EphemeralReleasingLease {
		m.logFUSETeardownFailure(lifecycle, "invalid-finalization-state", ErrEphemeralLifecycleConflict)
		return false
	}
	if lifecycle.evidence.RuntimeUID == "" {
		if evidence, persisted := poolTerminationEvidence(*lifecycle.claimed); persisted {
			lifecycle.evidence = evidence
		} else {
			fencer, ok := m.runtime.(runtime.RuntimeFencer)
			if !ok {
				m.logFUSETeardownFailure(lifecycle, "confirm-runtime-termination", errors.New("runtime has no termination fencer"))
				return false
			}
			evidence, err := fencer.ConfirmTerminated(ctx, lifecycle.record.RuntimeID, lifecycle.record.RuntimeUID)
			if err != nil {
				m.logFUSETeardownFailure(lifecycle, "confirm-runtime-termination", err)
				return false
			}
			lifecycle.evidence = evidence
		}
	}
	if !lifecycle.unmountRecorded && m.fusePool.spec.WorkspaceFUSE != nil {
		metrics.RecordWorkspaceUnmount(ctx, m.fusePool.spec.WorkspaceFUSE.RuntimeType, "success")
		lifecycle.unmountRecorded = true
	}
	if !lifecycle.probeRemoved {
		if lifecycle.controller != nil {
			if err := lifecycle.controller.Fence(ctx); err != nil {
				m.logFUSETeardownFailure(lifecycle, "controller-fence-probe-remove", err)
				return false
			}
		}
		probeName, err := fuseprotocol.DeriveProbeObjectName(lifecycle.record.RuntimeUID, generation)
		if err != nil {
			m.logFUSETeardownFailure(lifecycle, "derive-probe-object", err)
			return false
		}
		probeKey := lifecycle.lease.OwnerSnapshot().Prefix + probeName
		if err := m.config.WorkspaceObjectClient.DeleteObject(ctx, probeKey); err != nil {
			m.logFUSETeardownFailure(lifecycle, "delete-probe-object", err)
			return false
		}
		exists, err := m.config.WorkspaceObjectClient.HeadObject(ctx, probeKey)
		if err != nil || exists {
			if err == nil {
				err = errors.New("probe object still exists after deletion")
			}
			m.logFUSETeardownFailure(lifecycle, "verify-probe-object-deletion", err)
			return false
		}
		lifecycle.probeRemoved = true
	}
	if !lifecycle.leaseReleased {
		if lifecycle.controller != nil {
			if err := lifecycle.controller.Fence(ctx); err != nil {
				m.logFUSETeardownFailure(lifecycle, "controller-fence-owner-release", err)
				return false
			}
		}
		if err := m.config.WorkspaceCoordinator.Release(ctx, lifecycle.lease, lifecycle.evidence); err != nil {
			m.logFUSETeardownFailure(lifecycle, "release-workspace-lease", err)
			return false
		}
		lifecycle.leaseReleased = true
	}
	if !lifecycle.poolRemoved {
		if err := m.checkpointFUSECleanup(ctx, lifecycle); err != nil {
			m.logFUSETeardownFailure(lifecycle, "checkpoint-pool-deletion", err)
			return false
		}
		if lifecycle.controller != nil {
			if err := lifecycle.controller.Fence(ctx); err != nil {
				m.logFUSETeardownFailure(lifecycle, "controller-fence-pool-complete", err)
				return false
			}
		}
		if err := m.fusePool.CompleteClaimedCleanup(ctx, *lifecycle.claimed); err != nil {
			m.logFUSETeardownFailure(lifecycle, "complete-pool-cleanup", err)
			return false
		}
		lifecycle.poolRemoved = true
	}
	if !lifecycle.sessionRemoved {
		m.mu.RLock()
		source := m.sandboxes[lifecycle.sandboxID]
		if source == nil {
			source = lifecycle.sandbox
		}
		sb := cloneSandbox(source)
		m.mu.RUnlock()
		if err := m.removeWorkspaceLifecycle(ctx, &sb, lifecycle.ephemeralRecord); err != nil {
			m.logFUSETeardownFailure(lifecycle, "remove-session", err)
			return false
		}
		lifecycle.sessionRemoved = true
	}
	if lifecycle.controller != nil {
		if err := lifecycle.controller.Fence(ctx); err != nil {
			m.logFUSETeardownFailure(lifecycle, "controller-fence-active-state", err)
			return false
		}
	}
	completed, err := m.completeActiveSandboxCleanupWithResult(ctx, lifecycle.sandboxID, lifecycle.controller)
	if err != nil {
		m.logFUSETeardownFailure(lifecycle, "complete-active-state", err)
		return false
	}
	m.mu.Lock()
	delete(m.sandboxes, lifecycle.sandboxID)
	delete(m.operationGates, lifecycle.sandboxID)
	delete(m.fuseLifecycles, lifecycle.sandboxID)
	m.mu.Unlock()
	if lifecycle.controller != nil {
		_ = lifecycle.controller.Stop(ctx)
	}
	lifecycle.teardownMu.Lock()
	lifecycle.teardownDone = true
	lifecycle.teardownMu.Unlock()
	return completed
}

func (m *Manager) logFUSETeardownFailure(lifecycle *fuseSandboxLifecycle, stage string, err error) {
	if lifecycle == nil || err == nil {
		return
	}
	now := time.Now()
	lifecycle.teardownMu.Lock()
	if lifecycle.lastFailureStage == stage && now.Sub(lifecycle.lastFailureAt) < 10*time.Second {
		lifecycle.teardownMu.Unlock()
		return
	}
	lifecycle.lastFailureStage = stage
	lifecycle.lastFailureAt = now
	lifecycle.teardownMu.Unlock()
	logger.Error(context.Background(), "FUSE sandbox teardown stage failed",
		logger.AddField("sandbox_id", lifecycle.sandboxID),
		logger.AddField("runtime_id", lifecycle.record.RuntimeID),
		logger.AddField("stage", stage),
		logger.ErrorField(err),
	)
}

func (m *Manager) fuseTeardownTimeout() time.Duration {
	const controlMargin = 30 * time.Second
	timeout := controlMargin
	if m == nil || m.fusePool == nil || m.fusePool.spec.WorkspaceFUSE == nil {
		return workspaceCleanupTimeout
	}
	// Destruction flushes once after quiescing and the strong supervisor
	// shutdown flushes again before unmounting. Leave a bounded control-plane
	// margin for quiesce, acknowledgements, and exact runtime termination proof.
	for _, duration := range []time.Duration{
		m.fusePool.spec.WorkspaceFUSE.FlushTimeout,
		m.fusePool.spec.WorkspaceFUSE.FlushTimeout,
		m.fusePool.spec.WorkspaceFUSE.UnmountTimeout,
	} {
		if duration <= 0 {
			continue
		}
		if duration > time.Duration(1<<63-1)-timeout {
			return time.Duration(1<<63 - 1)
		}
		timeout += duration
	}
	if timeout < workspaceCleanupTimeout {
		return workspaceCleanupTimeout
	}
	return timeout
}

func (m *Manager) scheduleFUSETeardown(lifecycle *fuseSandboxLifecycle, cause error) {
	if lifecycle == nil {
		return
	}
	m.lifecycleMu.Lock()
	if m.stopping {
		m.lifecycleMu.Unlock()
		return
	}
	lifecycle.teardownMu.Lock()
	if lifecycle.teardownScheduled || lifecycle.teardownDone {
		lifecycle.teardownMu.Unlock()
		m.lifecycleMu.Unlock()
		return
	}
	lifecycle.teardownScheduled = true
	lifecycle.teardownMu.Unlock()
	m.wg.Add(1)
	m.lifecycleMu.Unlock()
	go func() {
		defer m.wg.Done()
		defer func() {
			lifecycle.teardownMu.Lock()
			lifecycle.teardownScheduled = false
			lifecycle.teardownMu.Unlock()
		}()
		ctx, cancel := context.WithTimeout(m.controlCtx, m.fuseTeardownTimeout())
		defer cancel()
		m.runFUSETeardown(ctx, lifecycle, cause)
	}()
}

func (m *Manager) runFUSETeardown(ctx context.Context, lifecycle *fuseSandboxLifecycle, cause error) {
	_, _ = m.runFUSETeardownWithResult(ctx, lifecycle, cause)
}

func (m *Manager) runFUSETeardownWithResult(ctx context.Context, lifecycle *fuseSandboxLifecycle, cause error) (bool, error) {
	if lifecycle == nil {
		return false, ErrSandboxCleanupPending
	}
	ctx, cancel := context.WithTimeout(ctx, m.fuseTeardownTimeout())
	defer cancel()
	for {
		if ctx.Err() != nil {
			return false, errors.Join(ErrSandboxCleanupPending, ctx.Err())
		}
		completed := m.teardownFUSESandboxWithResult(ctx, lifecycle, cause)
		lifecycle.teardownMu.Lock()
		done := lifecycle.teardownDone
		lifecycle.teardownMu.Unlock()
		if done {
			return completed, nil
		}
		select {
		case <-ctx.Done():
			return false, errors.Join(ErrSandboxCleanupPending, ctx.Err())
		case <-time.After(100 * time.Millisecond):
		}
	}
}

// Get retrieves a sandbox by ID. Returns a copy to prevent external data races.
func (m *Manager) Get(ctx context.Context, id string) (Sandbox, error) {
	spanCtx, span := telemetry.Tracer().Start(ctx, "sandbox.Manager.Get")
	defer span.End()

	sb, _, release, err := m.acquireSandboxOperation(spanCtx, id)
	if err != nil {
		return Sandbox{}, err
	}
	defer release()
	m.mu.RLock()
	clone := cloneSandbox(sb)
	m.mu.RUnlock()
	return clone, nil
}

func cloneSandbox(sb *Sandbox) Sandbox {
	if sb == nil {
		return Sandbox{}
	}
	clone := *sb
	clone.Config = cloneSandboxConfig(sb.Config)
	clone.WorkspaceTransitionExclude = append([]string(nil), sb.WorkspaceTransitionExclude...)
	if sb.Workspace != nil {
		workspace := *sb.Workspace
		workspace.SyncExclude = append([]string(nil), sb.Workspace.SyncExclude...)
		if sb.Workspace.LastFlushedAt != nil {
			lastFlushedAt := *sb.Workspace.LastFlushedAt
			workspace.LastFlushedAt = &lastFlushedAt
		}
		clone.Workspace = &workspace
	}
	return clone
}

func cloneSandboxConfig(config SandboxConfig) SandboxConfig {
	clone := config
	clone.Network.Whitelist = append([]string(nil), config.Network.Whitelist...)
	clone.Dependencies = append([]Dependency(nil), config.Dependencies...)
	clone.WorkspaceSyncExclude = append([]string(nil), config.WorkspaceSyncExclude...)
	return clone
}

func (m *Manager) sandboxRuntimeID(sb *Sandbox) string {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if sb == nil {
		return ""
	}
	return sb.RuntimeID
}

func (m *Manager) acquireSandboxOperation(ctx context.Context, id string) (*Sandbox, context.Context, func(), error) {
	if m.distributedStateEnabled() {
		return m.beginDistributedOperation(ctx, id, state.ActiveOperationData)
	}
	m.mu.RLock()
	sb, ok := m.sandboxes[id]
	gate := m.operationGates[id]
	if ok {
		if gate != nil {
			m.mu.RUnlock()
			release, err := gate.Acquire()
			if err != nil {
				return nil, nil, nil, fmt.Errorf("%w: %s", err, id)
			}
			m.mu.RLock()
			current := m.sandboxes[id]
			if current == nil || current != sb || m.operationGates[id] != gate {
				m.mu.RUnlock()
				release()
				return nil, nil, nil, fmt.Errorf("%w: %s", ErrSandboxNotReady, id)
			}
			m.mu.RUnlock()
			return current, ctx, release, nil
		}
		if sb.Workspace != nil && (sb.Workspace.MountType == WorkspaceMountFUSE || sb.Workspace.Owner.Generation > 0) {
			m.mu.RUnlock()
			return nil, nil, nil, fmt.Errorf("%w: %s", ErrSandboxNotReady, id)
		}
		m.mu.RUnlock()
		return sb, ctx, func() {}, nil
	}
	m.mu.RUnlock()

	if m.sessions != nil {
		loaded, err := m.sessions.Load(ctx, id)
		if err != nil {
			return nil, nil, nil, err
		}
		if loaded.Workspace != nil && (loaded.Workspace.MountType == WorkspaceMountFUSE || loaded.Workspace.Owner.Generation > 0) {
			return nil, nil, nil, fmt.Errorf("%w: %s", ErrSandboxNotReady, id)
		}
		m.mu.Lock()
		if current := m.sandboxes[id]; current != nil {
			loaded = current
		} else {
			m.sandboxes[id] = loaded
			m.operationGates[id] = newOperationGate(true)
		}
		m.mu.Unlock()
		return loaded, ctx, func() {}, nil
	}
	return nil, nil, nil, fmt.Errorf("%w: %s", ErrSandboxNotFound, id)
}

// resolve looks up a sandbox by ID: first in memory, then in the session store.
// Returns a pointer to the in-memory Sandbox (caller must hold no lock).
func (m *Manager) resolve(ctx context.Context, id string) (*Sandbox, error) {
	m.mu.RLock()
	sb, ok := m.sandboxes[id]
	m.mu.RUnlock()
	if ok {
		return sb, nil
	}

	// Fall back to session store for persistent sandboxes
	if m.sessions != nil {
		sbPtr, err := m.sessions.Load(ctx, id)
		if err != nil {
			return nil, err
		}
		if sbPtr.Workspace != nil && sbPtr.Workspace.MountType == WorkspaceMountFUSE {
			return nil, fmt.Errorf("%w: %s", ErrSandboxNotReady, id)
		}
		logger.Info(ctx, "sandbox restored from session store",
			logger.AddField("sandbox_id", id),
			logger.AddField("runtime_id", sbPtr.RuntimeID),
		)
		// Register into in-memory map so subsequent lookups find it directly
		m.mu.Lock()
		m.sandboxes[id] = sbPtr
		m.mu.Unlock()

		// Restore workspace ScopedFS if workspace was mounted
		if sbPtr.Workspace != nil && sbPtr.Workspace.RootPath != "" {
			scoped, fsErr := storage.NewScopedFS(m.filesystem, sbPtr.Workspace.RootPath)
			if fsErr == nil {
				m.mu.Lock()
				m.workspaces[id] = scoped
				m.mu.Unlock()
			} else {
				logger.Error(ctx, "resolve: restore workspace scoped fs failed",
					logger.AddField("sandbox_id", id),
					logger.AddField("root_path", sbPtr.Workspace.RootPath),
					logger.ErrorField(fsErr),
				)
			}
		}

		return sbPtr, nil
	}

	return nil, fmt.Errorf("%w: %s", ErrSandboxNotFound, id)
}

// Destroy removes a sandbox.
func (m *Manager) Destroy(ctx context.Context, id string) error {
	return m.destroyWithReason(ctx, id, "manual")
}

func (m *Manager) destroyWithReason(ctx context.Context, id, reason string) error {
	ctx, span := telemetry.Tracer().Start(ctx, "sandbox.Destroy",
		trace.WithAttributes(attribute.String("sandbox.id", id)),
		trace.WithAttributes(attribute.String("reason", reason)),
	)
	defer span.End()
	if m.distributedStateEnabled() {
		recordDestroy, err := m.destroyDistributedSandboxWithWait(ctx, id, true)
		if err != nil {
			telemetry.Error(err, span)
			return err
		}
		if recordDestroy {
			metrics.SandboxActiveGauge.Add(ctx, -1)
			metrics.RecordSandboxDestroy(ctx, reason)
		}
		return nil
	}
	m.mu.RLock()
	fuseLifecycle := m.fuseLifecycles[id]
	syncLifecycle := m.syncLifecycles[id]
	m.mu.RUnlock()
	if fuseLifecycle != nil {
		cleanupCtx, cancel := context.WithTimeout(context.Background(), m.fuseTeardownTimeout())
		defer cancel()
		completed := m.teardownFUSESandboxWithResult(cleanupCtx, fuseLifecycle, fmt.Errorf("sandbox destroy: %s", reason))
		fuseLifecycle.teardownMu.Lock()
		done := fuseLifecycle.teardownDone
		fuseLifecycle.teardownMu.Unlock()
		if !done {
			m.scheduleFUSETeardown(fuseLifecycle, fmt.Errorf("sandbox destroy retry: %s", reason))
			return fmt.Errorf("%w: destroy FUSE sandbox", ErrSandboxCleanupPending)
		}
		if completed {
			metrics.SandboxActiveGauge.Add(ctx, -1)
			metrics.RecordSandboxDestroy(ctx, reason)
		}
		return nil
	}
	if syncLifecycle != nil {
		completed, err := m.destroySyncSandboxWithResult(ctx, syncLifecycle)
		if err != nil {
			if errors.Is(err, ErrSandboxCleanupPending) {
				m.scheduleSyncFinalization(syncLifecycle, err)
			}
			return err
		}
		if completed {
			metrics.SandboxActiveGauge.Add(ctx, -1)
			metrics.RecordSandboxDestroy(ctx, reason)
		}
		return nil
	}

	sb, err := m.resolve(ctx, id)
	if err != nil {
		telemetry.Error(err, span)
		return err
	}

	m.mu.RLock()
	gate := m.operationGates[id]
	m.mu.RUnlock()
	if gate != nil {
		if err := gate.CloseAndWait(ctx); err != nil {
			return fmt.Errorf("drain sandbox operations: %w", err)
		}
	}

	m.mu.Lock()
	sb.State = StateDestroying
	m.mu.Unlock()

	// Clean up session store
	if m.sessions != nil {
		_ = m.sessions.Remove(ctx, id)
	}

	// Best-effort sync workspace back before destroying.
	// We do this before removing from the sandboxes map so that concurrent
	// autoSync goroutines see StateDestroying and skip this sandbox.
	m.mu.RLock()
	_, hasWS := m.workspaces[id]
	m.mu.RUnlock()
	if hasWS {
		_ = m.syncFromContainer(ctx, id, sb.RuntimeID, nil)
		m.mu.Lock()
		delete(m.workspaces, id)
		m.mu.Unlock()
	}

	m.mu.Lock()
	delete(m.sandboxes, id)
	delete(m.operationGates, id)
	m.mu.Unlock()

	// Remove the container
	if err := m.runtime.RemoveSandbox(ctx, sb.RuntimeID); err != nil {
		telemetry.Error(err, span)
		metrics.RecordError(ctx, "destroy_failed")
		return fmt.Errorf("remove sandbox: %w", err)
	}

	// Notify pool so it can refill
	m.pool.NotifyRemoved()
	metrics.SandboxActiveGauge.Add(ctx, -1)
	metrics.RecordSandboxDestroy(ctx, reason)

	return nil
}

// Exec executes a command in a sandbox synchronously.
func (m *Manager) Exec(ctx context.Context, id string, req runtime.ExecRequest) (*runtime.ExecResult, error) {
	parentCtx := ctx
	ctx, span := telemetry.Tracer().Start(ctx, "sandbox.Manager.Exec",
		trace.WithAttributes(
			attribute.String("sandbox.id", id),
			attribute.String("exec.language", req.Command[:min(len(req.Command), 20)]),
		),
	)
	defer span.End()

	execStart := time.Now()
	requestedTimeout := req.Timeout
	timeoutSource := execTimeoutSource(requestedTimeout)
	effectiveTimeout, err := m.resolveExecTimeout(requestedTimeout)
	span.SetAttributes(
		attribute.Int("exec.timeout.requested_seconds", requestedTimeout),
		attribute.String("exec.timeout.source", timeoutSource),
	)
	if err != nil {
		telemetry.Error(err, span)
		return nil, err
	}
	span.SetAttributes(attribute.Int("exec.timeout.effective_seconds", effectiveTimeout))
	req.Timeout = effectiveTimeout
	execCtx, cancel := newExecContext(ctx, effectiveTimeout)
	defer cancel()

	sb, operationCtx, release, err := m.acquireSandboxOperation(execCtx, id)
	if err != nil {
		telemetry.Error(err, span)
		metrics.RecordError(execCtx, "sandbox_not_found")
		return nil, err
	}
	execCtx = operationCtx
	defer release()

	m.mu.Lock()
	networkEnabled := sb.Config.Network.Enabled
	runtimeID := sb.RuntimeID
	networkDenied := req.RequiresNetwork && !networkEnabled
	if !networkDenied {
		sb.State = StateRunning
		sb.UpdatedAt = time.Now()
	}
	m.mu.Unlock()

	if networkDenied {
		telemetry.Error(ErrNetworkRequired, span)
		metrics.RecordError(execCtx, "network_required")
		return nil, ErrNetworkRequired
	}

	result, err := m.runtime.Exec(execCtx, runtimeID, req)

	m.mu.Lock()
	if err != nil {
		sb.State = StateError
	} else {
		sb.State = StateIdle
	}
	sb.UpdatedAt = time.Now()
	m.mu.Unlock()

	if err != nil {
		telemetry.Error(err, span)
		status := execFailureStatus(parentCtx, execCtx, err, effectiveTimeout, timeoutSource)
		metrics.RecordExec(execCtx, "sync", status, time.Since(execStart).Seconds())
		metrics.RecordError(execCtx, "exec_failed")
		if isExecTimeout(parentCtx, execCtx, err, effectiveTimeout) {
			return nil, fmt.Errorf("execute sandbox: %w", ErrExecTimeout)
		}
		return nil, err
	}

	status := "success"
	if result.ExitCode != 0 {
		status = "non_zero_exit"
	}
	metrics.RecordExec(execCtx, "sync", status, result.Duration.Seconds())
	span.SetAttributes(
		attribute.Int("exec.exit_code", result.ExitCode),
		attribute.Float64("exec.duration_s", result.Duration.Seconds()),
	)
	return result, nil
}

// ExecStream executes a command in a sandbox with streaming output.
func (m *Manager) ExecStream(ctx context.Context, id string, req runtime.ExecRequest) (<-chan runtime.StreamEvent, error) {
	parentCtx := ctx
	ctx, span := telemetry.Tracer().Start(ctx, "sandbox.Manager.ExecStream",
		trace.WithAttributes(attribute.String("sandbox.id", id)),
	)
	requestedTimeout := req.Timeout
	timeoutSource := execTimeoutSource(requestedTimeout)
	effectiveTimeout, err := m.resolveExecTimeout(requestedTimeout)
	span.SetAttributes(
		attribute.Int("exec.timeout.requested_seconds", requestedTimeout),
		attribute.String("exec.timeout.source", timeoutSource),
	)
	if err != nil {
		telemetry.Error(err, span)
		span.End()
		return nil, err
	}
	span.SetAttributes(attribute.Int("exec.timeout.effective_seconds", effectiveTimeout))
	req.Timeout = effectiveTimeout
	execCtx, cancel := newExecContext(ctx, effectiveTimeout)

	sb, operationCtx, release, err := m.acquireSandboxOperation(execCtx, id)
	if err != nil {
		telemetry.Error(err, span)
		metrics.RecordError(execCtx, "sandbox_not_found")
		cancel()
		span.End()
		return nil, err
	}
	execCtx = operationCtx

	m.mu.Lock()
	networkEnabled := sb.Config.Network.Enabled
	runtimeID := sb.RuntimeID
	networkDenied := req.RequiresNetwork && !networkEnabled
	if !networkDenied {
		sb.State = StateRunning
		sb.UpdatedAt = time.Now()
	}
	m.mu.Unlock()

	if networkDenied {
		telemetry.Error(ErrNetworkRequired, span)
		metrics.RecordError(execCtx, "network_required")
		cancel()
		span.End()
		release()
		return nil, ErrNetworkRequired
	}

	streamStart := time.Now()
	ch, err := m.runtime.ExecStream(execCtx, runtimeID, req)
	if err != nil {
		m.mu.Lock()
		sb.State = StateError
		sb.UpdatedAt = time.Now()
		m.mu.Unlock()
		telemetry.Error(err, span)
		status := execFailureStatus(parentCtx, execCtx, err, effectiveTimeout, timeoutSource)
		metrics.RecordExec(execCtx, "stream", status, time.Since(streamStart).Seconds())
		metrics.RecordError(execCtx, "exec_failed")
		timedOut := isExecTimeout(parentCtx, execCtx, err, effectiveTimeout)
		cancel()
		span.End()
		release()
		if timedOut {
			return nil, fmt.Errorf("execute sandbox stream: %w", ErrExecTimeout)
		}
		return nil, err
	}

	// Wrap channel to update state on completion
	outCh := make(chan runtime.StreamEvent, 64)
	go func() {
		defer span.End()
		defer cancel()
		defer release()
		defer close(outCh)

		finalized := false
		finalize := func(state State, status string, terminal *runtime.StreamEvent) {
			if finalized {
				return
			}
			finalized = true
			m.mu.Lock()
			sb.State = state
			sb.UpdatedAt = time.Now()
			m.mu.Unlock()
			if terminal != nil {
				sendStreamTerminal(outCh, *terminal)
			}
			metrics.RecordExec(execCtx, "stream", status, time.Since(streamStart).Seconds())
		}

		finishCancelled := func() {
			cause := context.Cause(execCtx)
			var terminal *runtime.StreamEvent
			if errors.Is(cause, ErrExecTimeout) {
				telemetry.Error(ErrExecTimeout, span)
				event := runtime.StreamEvent{Type: runtime.StreamError, Content: ErrExecTimeout.Error()}
				terminal = &event
			}
			status := execFailureStatus(parentCtx, execCtx, cause, effectiveTimeout, timeoutSource)
			finalize(StateError, status, terminal)
		}

		finishEvent := func(event runtime.StreamEvent) bool {
			switch event.Type {
			case runtime.StreamDone:
				finalize(StateIdle, "success", &event)
				return true
			case runtime.StreamError:
				finalize(StateError, "error", &event)
				return true
			default:
				return false
			}
		}

		finishReadyTerminal := func() bool {
			select {
			case event, ok := <-ch:
				return ok && finishEvent(event)
			default:
				return false
			}
		}

		for {
			select {
			case <-execCtx.Done():
				if finishReadyTerminal() {
					return
				}
				finishCancelled()
				return
			case event, ok := <-ch:
				if !ok {
					if context.Cause(execCtx) != nil {
						finishCancelled()
					} else {
						finalize(StateIdle, "success", nil)
					}
					return
				}
				if finishEvent(event) {
					return
				}
				select {
				case outCh <- event:
				case <-execCtx.Done():
					if finishReadyTerminal() {
						return
					}
					finishCancelled()
					return
				}
			}
		}
	}()

	return outCh, nil
}

// UploadFile uploads a file into a sandbox.
func (m *Manager) UploadFile(ctx context.Context, id, destPath string, size int64, reader io.Reader) error {
	ctx, span := telemetry.Tracer().Start(ctx, "sandbox.Manager.UploadFile",
		trace.WithAttributes(attribute.String("sandbox.id", id)),
	)
	defer span.End()

	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, id)
	if err != nil {
		return err
	}
	ctx = operationCtx
	defer release()
	if err := validatePublicFUSEFilePath(sb, destPath); err != nil {
		return err
	}

	runtimeID := m.sandboxRuntimeID(sb)
	if err := m.runtime.UploadFile(ctx, runtimeID, destPath, size, reader); err != nil {
		metrics.RecordFileOp(ctx, "upload", "error")
		return err
	}
	metrics.RecordFileOp(ctx, "upload", "success")
	return nil
}

// DownloadFile downloads a file from a sandbox.
func (m *Manager) DownloadFile(ctx context.Context, id string, srcPath string) (io.ReadCloser, error) {
	ctx, span := telemetry.Tracer().Start(ctx, "sandbox.Manager.DownloadFile",
		trace.WithAttributes(attribute.String("sandbox.id", id)),
	)
	defer span.End()

	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, id)
	if err != nil {
		return nil, err
	}
	ctx = operationCtx
	if err := validatePublicFUSEFilePath(sb, srcPath); err != nil {
		release()
		return nil, err
	}

	runtimeID := m.sandboxRuntimeID(sb)
	rc, err := m.runtime.DownloadFile(ctx, runtimeID, srcPath)
	if err != nil {
		release()
		metrics.RecordFileOp(ctx, "download", "error")
		return nil, err
	}
	if rc == nil {
		release()
		return nil, fmt.Errorf("download file returned no reader")
	}
	metrics.RecordFileOp(ctx, "download", "success")
	return &gatedReadCloser{reader: rc, release: release}, nil
}

// ReadFileContent streams the raw content of a file from the sandbox without tar wrapping.
func (m *Manager) ReadFileContent(ctx context.Context, id string, srcPath string) (io.ReadCloser, error) {
	ctx, span := telemetry.Tracer().Start(ctx, "sandbox.Manager.ReadFileContent",
		trace.WithAttributes(attribute.String("sandbox.id", id)),
	)
	defer span.End()

	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, id)
	if err != nil {
		return nil, err
	}
	ctx = operationCtx
	if err := validatePublicFUSEFilePath(sb, srcPath); err != nil {
		release()
		return nil, err
	}

	runtimeID := m.sandboxRuntimeID(sb)
	rc, err := m.runtime.ReadFileContent(ctx, runtimeID, srcPath)
	if err != nil {
		release()
		metrics.RecordFileOp(ctx, "read", "error")
		return nil, err
	}
	if rc == nil {
		release()
		return nil, fmt.Errorf("read file returned no reader")
	}
	metrics.RecordFileOp(ctx, "read", "success")
	return &gatedReadCloser{reader: rc, release: release}, nil
}

// GlobInfo returns files matching the glob pattern with their content.
func (m *Manager) GlobInfo(ctx context.Context, id string, pattern string) ([]runtime.FileContent, error) {
	ctx, span := telemetry.Tracer().Start(ctx, "sandbox.Manager.GlobInfo",
		trace.WithAttributes(attribute.String("sandbox.id", id)),
	)
	defer span.End()

	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, id)
	if err != nil {
		return nil, err
	}
	ctx = operationCtx
	if err := validatePublicFUSEFilePath(sb, pattern); err != nil {
		release()
		return nil, err
	}
	runtimeID := m.sandboxRuntimeID(sb)
	files, err := m.runtime.GlobInfo(ctx, runtimeID, pattern)
	if err != nil {
		for i := range files {
			if files[i].Content != nil {
				_ = files[i].Content.Close()
			}
		}
		release()
		return files, err
	}
	if sb.Workspace != nil && sb.Workspace.MountType == WorkspaceMountFUSE {
		filtered := files[:0]
		for _, file := range files {
			if fuseprotocol.IsReservedProbeObjectName(filepath.Base(filepath.Clean(file.Path))) {
				if file.Content != nil {
					_ = file.Content.Close()
				}
				continue
			}
			filtered = append(filtered, file)
		}
		files = filtered
	}
	return holdGateForFileContents(files, release), nil
}

// DownloadFiles downloads multiple files in parallel.
func (m *Manager) DownloadFiles(ctx context.Context, id string, paths []string) ([]runtime.FileContent, error) {
	ctx, span := telemetry.Tracer().Start(ctx, "sandbox.Manager.DownloadFiles",
		trace.WithAttributes(attribute.String("sandbox.id", id)),
	)
	defer span.End()

	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, id)
	if err != nil {
		return nil, err
	}
	ctx = operationCtx
	for _, path := range paths {
		if err := validatePublicFUSEFilePath(sb, path); err != nil {
			release()
			return nil, err
		}
	}

	runtimeID := m.sandboxRuntimeID(sb)
	files, err := m.runtime.DownloadFiles(ctx, runtimeID, paths)
	if err != nil {
		for i := range files {
			if files[i].Content != nil {
				_ = files[i].Content.Close()
			}
		}
		release()
		return files, err
	}
	return holdGateForFileContents(files, release), nil
}

// ListFiles lists files in a sandbox directory.
func (m *Manager) ListFiles(ctx context.Context, id string, dirPath string) ([]runtime.FileInfo, error) {
	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, id)
	if err != nil {
		return nil, err
	}
	ctx = operationCtx
	defer release()
	if err := validatePublicFUSEFilePath(sb, dirPath); err != nil {
		return nil, err
	}
	files, err := m.runtime.ListFiles(ctx, m.sandboxRuntimeID(sb), dirPath)
	return hideReservedFUSEFileInfos(sb, files), err
}

// ListFilesRecursive lists files recursively in a sandbox directory.
func (m *Manager) ListFilesRecursive(ctx context.Context, id string, dirPath string, maxDepth int, page int, pageSize int) (*runtime.FileListResult, error) {
	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, id)
	if err != nil {
		return nil, err
	}
	ctx = operationCtx
	defer release()
	if err := validatePublicFUSEFilePath(sb, dirPath); err != nil {
		return nil, err
	}
	runtimeID := m.sandboxRuntimeID(sb)
	if sb.Workspace != nil && sb.Workspace.MountType == WorkspaceMountFUSE {
		hiddenCount, probeErr := m.countReservedFUSEFiles(ctx, runtimeID, dirPath, maxDepth, "")
		if probeErr != nil {
			return nil, probeErr
		}
		return collectAndPaginateVisibleFUSEFiles(page, pageSize, hiddenCount, func(fetchPage, fetchPageSize int) (*runtime.FileListResult, error) {
			return m.runtime.ListFilesRecursive(ctx, runtimeID, dirPath, maxDepth, fetchPage, fetchPageSize)
		})
	}
	return m.runtime.ListFilesRecursive(ctx, runtimeID, dirPath, maxDepth, page, pageSize)
}

// GlobFiles finds files matching a glob pattern in a sandbox directory.
func (m *Manager) GlobFiles(ctx context.Context, id string, baseDir string, pattern string, page int, pageSize int) (*runtime.FileListResult, error) {
	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, id)
	if err != nil {
		return nil, err
	}
	ctx = operationCtx
	defer release()
	if err := validatePublicFUSEFilePath(sb, baseDir); err != nil {
		return nil, err
	}
	runtimeID := m.sandboxRuntimeID(sb)
	if sb.Workspace != nil && sb.Workspace.MountType == WorkspaceMountFUSE {
		hiddenCount, probeErr := m.countReservedFUSEFiles(ctx, runtimeID, baseDir, 0, pattern)
		if probeErr != nil {
			return nil, probeErr
		}
		return collectAndPaginateVisibleFUSEFiles(page, pageSize, hiddenCount, func(fetchPage, fetchPageSize int) (*runtime.FileListResult, error) {
			return m.runtime.GlobFiles(ctx, runtimeID, baseDir, pattern, fetchPage, fetchPageSize)
		})
	}
	return m.runtime.GlobFiles(ctx, runtimeID, baseDir, pattern, page, pageSize)
}

func collectAndPaginateVisibleFUSEFiles(page, pageSize, expectedHidden int, fetch func(int, int) (*runtime.FileListResult, error)) (*runtime.FileListResult, error) {
	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 100
	}
	const minScanPageSize = 128
	scanPageSize := pageSize
	if scanPageSize < minScanPageSize {
		scanPageSize = minScanPageSize
	}
	start := (page - 1) * pageSize
	end := start + pageSize
	visibleIndex := 0
	rawScanned := 0
	rawTotal := -1
	visible := make([]runtime.FileInfo, 0, pageSize)
	for fetchPage := 1; ; fetchPage++ {
		result, err := fetch(fetchPage, scanPageSize)
		if err != nil {
			return nil, err
		}
		if result == nil {
			return nil, fmt.Errorf("runtime returned no file list result")
		}
		if rawTotal < 0 {
			rawTotal = result.TotalCount
		}
		for _, file := range result.Files {
			rawScanned++
			if !fuseprotocol.IsReservedProbeObjectName(filepath.Base(filepath.Clean(file.Name))) &&
				!fuseprotocol.IsReservedProbeObjectName(filepath.Base(filepath.Clean(file.Path))) {
				if visibleIndex >= start && visibleIndex < end {
					visible = append(visible, file)
				}
				visibleIndex++
			}
		}
		if len(visible) == pageSize || len(result.Files) == 0 || len(result.Files) < scanPageSize || (rawTotal >= 0 && rawScanned >= rawTotal) {
			break
		}
	}
	visibleTotal := rawTotal - expectedHidden
	if visibleTotal < 0 {
		visibleTotal = 0
	}
	return &runtime.FileListResult{
		Files:      visible,
		TotalCount: visibleTotal,
		Page:       page,
		PageSize:   pageSize,
	}, nil
}

func (m *Manager) countReservedFUSEFiles(ctx context.Context, runtimeID, baseDir string, maxDepth int, globPattern string) (int, error) {
	counter, ok := m.runtime.(runtime.ReservedFileCounter)
	if !ok {
		return 0, fmt.Errorf("count reserved FUSE files: runtime does not support bounded reserved-file counting")
	}
	count, err := counter.CountReservedFiles(ctx, runtimeID, baseDir, maxDepth, globPattern)
	if err != nil {
		return 0, fmt.Errorf("count reserved FUSE files: %w", err)
	}
	if count < 0 {
		return 0, fmt.Errorf("count reserved FUSE files: runtime returned negative count")
	}
	return count, nil
}

// FileExists reports whether a regular file exists at the given path inside the sandbox.
// Returns runtime.ErrFileNotFound if the file does not exist.
func (m *Manager) FileExists(ctx context.Context, id string, filePath string) error {
	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, id)
	if err != nil {
		return err
	}
	ctx = operationCtx
	defer release()
	if err := validatePublicFUSEFilePath(sb, filePath); err != nil {
		return err
	}
	return m.runtime.FileExists(ctx, m.sandboxRuntimeID(sb), filePath)
}

// ReadFileLines reads a range of lines from a file in a sandbox.
func (m *Manager) ReadFileLines(ctx context.Context, id string, filePath string, startLine int, endLine int) (*runtime.FileLineResult, error) {
	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, id)
	if err != nil {
		return nil, err
	}
	ctx = operationCtx
	defer release()
	if err := validatePublicFUSEFilePath(sb, filePath); err != nil {
		return nil, err
	}
	result, err := m.runtime.ReadFileLines(ctx, m.sandboxRuntimeID(sb), filePath, startLine, endLine)
	if err != nil {
		metrics.RecordFileOp(ctx, "read_lines", "error")
		return nil, err
	}
	metrics.RecordFileOp(ctx, "read_lines", "success")
	return result, nil
}

// EditFile performs a string replacement in a file in a sandbox.
func (m *Manager) EditFile(ctx context.Context, id string, filePath string, oldStr string, newStr string, replaceAll bool) error {
	ctx, span := telemetry.Tracer().Start(ctx, "sandbox.Manager.EditFile",
		trace.WithAttributes(attribute.String("sandbox.id", id)),
		trace.WithAttributes(attribute.String("file_path", filePath)),
	)
	defer span.End()

	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, id)
	if err != nil {
		return err
	}
	ctx = operationCtx
	defer release()
	if err := validatePublicFUSEFilePath(sb, filePath); err != nil {
		return err
	}
	if err := m.runtime.EditFile(ctx, m.sandboxRuntimeID(sb), filePath, oldStr, newStr, replaceAll); err != nil {
		metrics.RecordFileOp(ctx, "edit", "error")
		return err
	}
	metrics.RecordFileOp(ctx, "edit", "success")
	return nil
}

// EditFileLines replaces a range of lines in a file in a sandbox.
func (m *Manager) EditFileLines(ctx context.Context, id string, filePath string, startLine int, endLine int, newContent string) error {
	ctx, span := telemetry.Tracer().Start(ctx, "sandbox.Manager.EditFileLines",
		trace.WithAttributes(attribute.String("sandbox.id", id)),
		trace.WithAttributes(attribute.String("file_path", filePath)),
	)
	defer span.End()

	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, id)
	if err != nil {
		return err
	}
	ctx = operationCtx
	defer release()
	if err := validatePublicFUSEFilePath(sb, filePath); err != nil {
		return err
	}
	if err := m.runtime.EditFileLines(ctx, m.sandboxRuntimeID(sb), filePath, startLine, endLine, newContent); err != nil {
		metrics.RecordFileOp(ctx, "edit_lines", "error")
		return err
	}
	metrics.RecordFileOp(ctx, "edit_lines", "success")
	return nil
}

// UpdateNetwork dynamically updates network access for a running sandbox.
func (m *Manager) UpdateNetwork(ctx context.Context, id string, enabled bool, whitelist []string, blockPrivate bool) error {
	whitelist = append([]string(nil), whitelist...)
	ctx, span := telemetry.Tracer().Start(ctx, "sandbox.Manager.UpdateNetwork",
		trace.WithAttributes(attribute.String("sandbox.id", id)),
		trace.WithAttributes(attribute.String("white_list", strings.Join(whitelist, ","))),
	)
	defer span.End()

	sb, operationCtx, release, err := m.acquireSandboxMutation(ctx, id)
	if err != nil {
		return err
	}
	ctx = operationCtx
	defer release()
	m.mu.RLock()
	runtimeID := sb.RuntimeID
	runtimeUID := sb.RuntimeUID
	isFUSE := sb.Workspace != nil && sb.Workspace.MountType == WorkspaceMountFUSE
	lifecycle := m.fuseLifecycles[id]
	m.mu.RUnlock()

	if isFUSE {
		ref, refErr := runtime.NewRuntimeRef(runtimeID, runtimeUID)
		if refErr != nil {
			return refErr
		}
		err = m.runtime.UpdateFUSENetwork(ctx, ref, enabled, whitelist, blockPrivate)
	} else {
		err = m.runtime.UpdateNetwork(ctx, runtimeID, enabled, whitelist, blockPrivate)
	}
	if err != nil {
		if isFUSE && lifecycle != nil && errors.Is(err, runtime.ErrFUSENetworkStateUncertain) {
			lifecycle.gate.closeAdmission()
			m.scheduleFUSETeardown(lifecycle, err)
		}
		return err
	}

	m.mu.Lock()
	sb.Config.Network.Enabled = enabled
	sb.Config.Network.Whitelist = append([]string(nil), whitelist...)
	sb.Config.Network.BlockPrivate = blockPrivate
	sb.UpdatedAt = time.Now()
	m.mu.Unlock()
	if err := m.persistActiveSandboxUpdate(ctx, sb); err != nil {
		return fmt.Errorf("persist network update: %w", err)
	}

	return nil
}

// UpdateTTL dynamically updates the TTL for a running sandbox.
// The new timeout (in seconds) must be > 0; setting to never-expire (-1) after
// creation is not allowed.
func (m *Manager) UpdateTTL(ctx context.Context, id string, timeoutSeconds int) (*Sandbox, error) {
	if timeoutSeconds <= 0 {
		return nil, fmt.Errorf("timeout must be greater than 0")
	}

	sb, operationCtx, release, err := m.acquireSandboxMutation(ctx, id)
	if err != nil {
		return nil, err
	}
	ctx = operationCtx
	defer release()

	now := time.Now()
	newTimeout := time.Duration(timeoutSeconds) * time.Second

	m.mu.Lock()
	sb.Timeout = newTimeout
	sb.CreatedAt = now // reset so reaper uses new baseline
	sb.UpdatedAt = now
	result := cloneSandbox(sb)
	m.mu.Unlock()
	if err := m.persistActiveSandboxUpdate(ctx, sb); err != nil {
		return nil, fmt.Errorf("persist sandbox TTL: %w", err)
	}

	// Persist to session store if applicable
	if result.Config.Mode == ModePersistent && m.sessions != nil {
		if err := m.sessions.Save(ctx, &result); err != nil {
			_ = err
		}
	}

	return &result, nil
}

// reapExpiredSandboxes periodically checks for sandboxes that have exceeded
// their timeout and destroys them.
func (m *Manager) reapExpiredSandboxes() {
	defer m.wg.Done()
	ticker := time.NewTicker(10 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-m.stopCh:
			return
		case <-ticker.C:
			m.reapOnce()
		}
	}
}

func (m *Manager) reapOnce() {
	now := time.Now()
	var expired []string

	m.mu.RLock()
	for id, sb := range m.sandboxes {
		if sb.Timeout > 0 && now.Sub(sb.CreatedAt) > sb.Timeout {
			expired = append(expired, id)
		}
	}
	m.mu.RUnlock()

	for _, id := range expired {
		_ = m.destroyWithReason(context.Background(), id, "ttl_expired")
	}
}

// autoSyncWorkspaces periodically syncs changed files from all mounted
// workspaces back to storage. This reduces data loss if a container crashes
// between manual syncs.
func (m *Manager) autoSyncWorkspaces() {
	defer m.wg.Done()
	interval := time.Duration(m.config.AutoSyncIntervalSeconds) * time.Second
	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	for {
		select {
		case <-m.stopCh:
			return
		case <-ticker.C:
			m.autoSyncOnce()
		}
	}
}

func (m *Manager) autoSyncOnce() {
	if m.distributedStateEnabled() {
		m.autoSyncDistributedWorkspaces()
		return
	}
	ctx := context.Background()

	// Restore persistent sandboxes not yet in local memory (handles multi-replica scenario)
	if m.sessions != nil {
		ids, err := m.sessions.List(ctx)
		if err != nil {
			logger.Error(ctx, "autoSyncOnce: list persistent sandboxes failed", logger.ErrorField(err))
		} else {
			for _, id := range ids {
				m.mu.RLock()
				_, inMemory := m.sandboxes[id]
				m.mu.RUnlock()
				if inMemory {
					continue
				}
				// Restore from session store so this replica can sync it
				sbPtr, err := m.sessions.Load(ctx, id)
				if err != nil {
					logger.Error(ctx, "autoSyncOnce: load sandbox from session store failed",
						logger.AddField("sandbox_id", id),
						logger.ErrorField(err),
					)
					continue
				}
				// Skip sandboxes that are being destroyed — the session entry may
				// be a stale record from a concurrent Destroy that removed the
				// session key after our List call but before we loaded it.
				// (StateDestroyed is never written to the session store because
				// Destroy deletes the key before the sandbox reaches that state.)
				if sbPtr.State == StateDestroying || (sbPtr.Workspace != nil && sbPtr.Workspace.MountType == WorkspaceMountFUSE) {
					continue
				}
				m.mu.Lock()
				m.sandboxes[id] = sbPtr
				m.mu.Unlock()
				metrics.RecordSessionRestore(ctx, "success")
				metrics.SandboxActiveGauge.Add(ctx, 1)

				if sbPtr.Workspace != nil && sbPtr.Workspace.RootPath != "" {
					scoped, fsErr := storage.NewScopedFS(m.filesystem, sbPtr.Workspace.RootPath)
					if fsErr != nil {
						logger.Error(ctx, "autoSyncOnce: restore workspace scoped fs failed",
							logger.AddField("sandbox_id", id),
							logger.AddField("root_path", sbPtr.Workspace.RootPath),
							logger.ErrorField(fsErr),
						)
					} else {
						m.mu.Lock()
						m.workspaces[id] = scoped
						m.mu.Unlock()
					}
				}
			}
		}
	}

	m.mu.RLock()
	type syncTarget struct {
		sandboxID   string
		runtimeID   string
		syncExclude []string
	}
	var targets []syncTarget
	for id := range m.workspaces {
		if sb, ok := m.sandboxes[id]; ok && sb.State != StateDestroying {
			var exclude []string
			if sb.Workspace != nil {
				exclude = append([]string(nil), sb.Workspace.SyncExclude...)
			}
			targets = append(targets, syncTarget{sandboxID: id, runtimeID: sb.RuntimeID, syncExclude: exclude})
		}
	}
	m.mu.RUnlock()

	for _, t := range targets {
		sb, operationCtx, release, acquireErr := m.acquireSandboxOperation(ctx, t.sandboxID)
		if acquireErr != nil {
			logger.Debug(ctx, "autoSync skipping sandbox",
				logger.AddField("sandbox_id", t.sandboxID),
				logger.ErrorField(acquireErr),
			)
			continue
		}
		m.mu.RLock()
		skip := sb.State == StateDestroying || (sb.Workspace != nil && sb.Workspace.MountType == WorkspaceMountFUSE)
		runtimeID := sb.RuntimeID
		m.mu.RUnlock()
		if skip {
			release()
			continue
		}
		syncErr := m.syncFromContainer(operationCtx, t.sandboxID, runtimeID, t.syncExclude)
		release()
		if syncErr != nil {
			if errors.Is(syncErr, runtime.ErrNotFound) {
				// Pod is gone — clean up both in-memory state and the session store
				// so we stop retrying on every tick and don't restore it again.
				m.mu.Lock()
				delete(m.workspaces, t.sandboxID)
				delete(m.sandboxes, t.sandboxID)
				m.mu.Unlock()
				if m.sessions != nil {
					_ = m.sessions.Remove(ctx, t.sandboxID)
				}
				continue
			}
			logger.Error(ctx, "auto-sync failed",
				logger.AddField("sandbox_id", t.sandboxID),
				logger.ErrorField(syncErr),
			)
		}
	}
}

// restorePersistentSandboxes reloads all persistent sandboxes from the session
// store at startup. If a container is gone, it recreates the container and
// re-syncs the workspace.
func (m *Manager) restorePersistentSandboxes(ctx context.Context) error {
	if m.sessions == nil {
		return nil
	}

	ids, err := m.sessions.List(ctx)
	if err != nil {
		return fmt.Errorf("list persistent sandboxes: %w", err)
	}

	var restored, recreated, failed int
	var restoreErr error
	for _, id := range ids {
		sbPtr, err := m.sessions.Load(ctx, id)
		if err != nil {
			logger.Error(ctx, "failed to load sandbox from session store",
				logger.AddField("sandbox_id", id),
				logger.ErrorField(err),
			)
			failed++
			restoreErr = errors.Join(restoreErr, fmt.Errorf("load persistent sandbox %q: %w", id, err))
			metrics.RecordSessionRestore(ctx, "error")
			continue
		}
		if sbPtr.State == StateDestroying && sbPtr.Workspace != nil && sbPtr.Workspace.MountType == WorkspaceMountSync {
			if err := m.finalizeRecoveredPersistentSync(ctx, sbPtr); err != nil {
				failed++
				restoreErr = errors.Join(restoreErr, fmt.Errorf("finalize persistent sync sandbox %q: %w", id, err))
				metrics.RecordSessionRestore(ctx, "error")
				continue
			}
			continue
		}
		if sbPtr.State == StateDestroying && sbPtr.Workspace != nil && sbPtr.Workspace.MountType == WorkspaceMountFUSE {
			if err := m.finalizeRecoveredPersistentFUSE(ctx, sbPtr); err != nil {
				failed++
				restoreErr = errors.Join(restoreErr, fmt.Errorf("finalize persistent FUSE sandbox %q: %w", id, err))
				metrics.RecordSessionRestore(ctx, "error")
				continue
			}
			continue
		}
		if sbPtr.Workspace != nil && sbPtr.Workspace.MountType == WorkspaceMountFUSE {
			if err := m.restoreFUSESandbox(ctx, sbPtr); err != nil {
				failed++
				restoreErr = errors.Join(restoreErr, fmt.Errorf("restore FUSE sandbox %q: %w", id, err))
				metrics.RecordSessionRestore(ctx, "error")
				continue
			}
			restored++
			metrics.RecordSessionRestore(ctx, "success")
			metrics.SandboxActiveGauge.Add(ctx, 1)
			continue
		}
		if sbPtr.Workspace != nil && sbPtr.Workspace.MountType == WorkspaceMountSync && sbPtr.Workspace.Owner.Generation > 0 {
			if err := m.restoreSyncSandbox(ctx, sbPtr); err != nil {
				failed++
				restoreErr = errors.Join(restoreErr, fmt.Errorf("restore sync sandbox %q: %w", id, err))
				metrics.RecordSessionRestore(ctx, "error")
				continue
			}
			restored++
			metrics.RecordSessionRestore(ctx, "success")
			metrics.SandboxActiveGauge.Add(ctx, 1)
			continue
		}

		// Check if the container still exists and is running
		existingInfo, rtErr := m.runtime.GetSandbox(ctx, sbPtr.RuntimeID)
		if rtErr != nil || existingInfo == nil || existingInfo.State != "running" {
			// Container gone or not healthy — recreate it
			logger.Warn(ctx, "sandbox container gone, recreating",
				logger.AddField("sandbox_id", id),
				logger.AddField("runtime_id", sbPtr.RuntimeID),
			)
			newInfo, recreateErr := m.recreateSandbox(ctx, sbPtr)
			if recreateErr != nil {
				logger.Error(ctx, "failed to recreate sandbox",
					logger.AddField("sandbox_id", id),
					logger.ErrorField(recreateErr),
				)
				if removeErr := m.sessions.Remove(ctx, id); removeErr != nil {
					restoreErr = errors.Join(restoreErr, fmt.Errorf("remove unrecoverable persistent sandbox %q: %w", id, removeErr))
				}
				failed++
				restoreErr = errors.Join(restoreErr, fmt.Errorf("recreate persistent sandbox %q: %w", id, recreateErr))
				metrics.RecordSessionRestore(ctx, "error")
				continue
			}
			sbPtr.RuntimeID = newInfo.RuntimeID
			sbPtr.State = StateReady
			sbPtr.UpdatedAt = time.Now()
			if saveErr := m.sessions.Save(ctx, sbPtr); saveErr != nil {
				restoreErr = errors.Join(restoreErr, fmt.Errorf("save recreated persistent sandbox %q: %w", id, saveErr))
			}
			recreated++
		}

		// Register into in-memory map
		m.sandboxes[id] = sbPtr
		m.operationGates[id] = newOperationGate(true)

		// Restore workspace ScopedFS and sync if needed
		if sbPtr.Workspace != nil && sbPtr.Workspace.RootPath != "" {
			scoped, fsErr := storage.NewScopedFS(m.filesystem, sbPtr.Workspace.RootPath)
			if fsErr == nil {
				m.workspaces[id] = scoped
				// Re-sync files to the new container (skip for bind mount)
				if !sbPtr.Workspace.BindMounted {
					if syncErr := m.syncToContainer(ctx, scoped, sbPtr.RuntimeID); syncErr != nil {
						logger.Error(ctx, "workspace re-sync failed",
							logger.AddField("sandbox_id", id),
							logger.AddField("runtime_id", sbPtr.RuntimeID),
							logger.ErrorField(syncErr),
						)
						restoreErr = errors.Join(restoreErr, fmt.Errorf("restore workspace for sandbox %q: %w", id, syncErr))
					}
				}
			} else {
				logger.Error(ctx, "failed to restore workspace scoped fs",
					logger.AddField("sandbox_id", id),
					logger.ErrorField(fsErr),
				)
				restoreErr = errors.Join(restoreErr, fmt.Errorf("restore scoped workspace for sandbox %q: %w", id, fsErr))
			}
		}

		restored++
		metrics.RecordSessionRestore(ctx, "success")
		metrics.SandboxActiveGauge.Add(ctx, 1)
	}

	if restored > 0 || failed > 0 {
		logger.Info(ctx, "persistent sandboxes restore complete",
			logger.AddField("restored", restored),
			logger.AddField("recreated", recreated),
			logger.AddField("failed", failed),
		)
	}
	return restoreErr
}

// restoreFUSESandbox reinstalls only the in-process gate, renewal and health
// watcher for an already-mounted runtime. The persisted mount attempt must be
// consumed; recovery never sends another authorization to the mounter.
func (m *Manager) restoreFUSESandbox(ctx context.Context, sb *Sandbox) error {
	return m.restoreFUSESandboxWithController(ctx, sb, nil)
}

func (m *Manager) restoreFUSESandboxWithController(ctx context.Context, sb *Sandbox, controller *activeController) error {
	return m.restoreFUSELifecycleWithController(ctx, sb, controller, false)
}

// Cleanup reconstruction never publishes ready admission. A live controller,
// the durable cleanup phase, exact consumed pool record, Pod UID and owner
// still fence every subsequent teardown operation. Quiesced health is not a
// reason to abandon that evidence after the requesting process has crashed.
func (m *Manager) restoreFUSECleanupWithController(ctx context.Context, sb *Sandbox, controller *activeController) error {
	if controller == nil || sb == nil || !m.distributedStateEnabled() {
		return ErrSandboxNotReady
	}
	if err := controller.Fence(ctx); err != nil {
		return err
	}
	record, err := m.activeSandboxes.Load(ctx, sb.ID)
	if err != nil {
		return err
	}
	if record == nil || (record.Phase != state.ActiveSandboxDestroying && record.Phase != state.ActiveSandboxCleanupPending) ||
		record.Generation != sb.activeGeneration || record.RuntimeID != sb.RuntimeID || record.RuntimeUID != sb.RuntimeUID {
		return ErrSandboxNotReady
	}
	if strings.HasPrefix(record.CleanupCheckpoint, fuseCleanupCheckpointPrefix) {
		return m.restoreCheckpointedFUSECleanup(ctx, sb, controller, record)
	}
	return m.restoreFUSELifecycleWithController(ctx, sb, controller, true)
}

func (m *Manager) restoreFUSELifecycleWithController(ctx context.Context, sb *Sandbox, controller *activeController, cleanup bool) error {
	if sb == nil || sb.Workspace == nil || m.fusePool == nil ||
		m.config.WorkspaceCoordinator == nil || m.config.WorkspaceObjectClient == nil {
		return ErrInvalidFUSEPoolConfig
	}
	if sb.Config.Mode == ModePersistent && m.sessions == nil {
		return ErrInvalidFUSEPoolConfig
	}
	if sb.Config.Mode == ModeEphemeral && m.ephemeral == nil {
		return ErrInvalidFUSEPoolConfig
	}
	workspace := sb.Workspace
	owner := workspace.Owner
	spec := m.fusePool.spec.WorkspaceFUSE
	if spec == nil || m.fsMeta == nil {
		return ErrInvalidFUSEPoolConfig
	}
	recoveryResult := "error"
	defer func() {
		metrics.RecordWorkspaceRecovery(ctx, spec.RuntimeType, spec.Provider, recoveryResult)
	}()
	expectedPrefix, err := storage.BuildWorkspacePrefix(m.fsMeta.SubPath, workspace.RootPath)
	if err != nil {
		return ErrSandboxNotReady
	}
	if sb.ID == "" || (sb.Config.Mode != ModePersistent && sb.Config.Mode != ModeEphemeral) || sb.State != StateReady ||
		sb.RuntimeID == "" || sb.RuntimeUID == "" || sb.RuntimeID != owner.RuntimeID || sb.RuntimeUID != owner.RuntimeUID ||
		owner.SandboxID != sb.ID || owner.Generation != workspace.LeaseGeneration || owner.MountAttempt != 1 ||
		owner.Provider != spec.Provider || owner.StorageIdentityHash != storageIdentityHash(spec.StorageIdentity) ||
		owner.Bucket != spec.Bucket || owner.Prefix != expectedPrefix || owner.Runtime != spec.RuntimeType ||
		workspace.MountState != WorkspaceMountReady || workspace.FUSEPreparationID == "" ||
		workspace.FUSEPoolKey == "" || workspace.FUSEReservationToken == "" || workspace.FUSERecordRevision == 0 {
		return ErrSandboxNotReady
	}

	records, err := m.fusePool.repo.ListByPoolKey(ctx, workspace.FUSEPoolKey)
	if err != nil {
		return fmt.Errorf("list FUSE pool records: %w", err)
	}
	var record *state.FUSEPoolRecord
	for i := range records {
		candidate := records[i]
		if candidate.PreparationID == workspace.FUSEPreparationID {
			record = &candidate
			break
		}
	}
	if record == nil || record.State != state.FUSEPoolConsumed || record.RuntimeID != sb.RuntimeID ||
		record.RuntimeUID != sb.RuntimeUID || record.PoolKey != workspace.FUSEPoolKey ||
		record.ReservationToken != workspace.FUSEReservationToken || record.Revision != workspace.FUSERecordRevision {
		return ErrSandboxNotReady
	}

	info, err := m.runtime.GetSandbox(ctx, sb.RuntimeID)
	if err != nil || info == nil || info.State != "running" || info.RuntimeID != sb.RuntimeID || info.RuntimeUID != sb.RuntimeUID {
		return ErrSandboxNotReady
	}
	ref, err := runtime.NewRuntimeRef(sb.RuntimeID, sb.RuntimeUID)
	if err != nil {
		return ErrSandboxNotReady
	}
	health, err := m.runtime.WorkspaceHealth(ctx, ref)
	if !cleanup && (err != nil || health == nil || !health.Ready || health.MountType != "fuse" ||
		health.RuntimeUID != sb.RuntimeUID || health.Generation != owner.Generation ||
		health.RestartCount != 0 || health.RestartDetected) {
		return ErrSandboxNotReady
	}
	if cleanup && health != nil && (health.MountType != "fuse" || health.RuntimeUID != sb.RuntimeUID || health.Generation != owner.Generation) {
		return ErrSandboxNotReady
	}

	lease, err := m.config.WorkspaceCoordinator.Restore(ctx, owner)
	if err != nil {
		return fmt.Errorf("restore workspace lease: %w", err)
	}
	gate := newOperationGate(!cleanup)
	lifecycleCtx, cancelLifecycle := context.WithCancel(context.Background())
	var lifecycle *fuseSandboxLifecycle
	var restoreMu sync.Mutex
	var renewalLost error
	published := false
	renewal, err := m.config.WorkspaceCoordinator.StartRenewal(context.Background(), lease, func(lost error) {
		restoreMu.Lock()
		current := lifecycle
		if !published {
			renewalLost = lost
			current = nil
		}
		restoreMu.Unlock()
		if current != nil {
			m.scheduleFUSETeardown(current, lost)
		}
	})
	if err != nil {
		cancelLifecycle()
		return fmt.Errorf("restart workspace lease renewal: %w", err)
	}
	restoreMu.Lock()
	var ephemeralRecord *EphemeralLifecycleRecord
	if sb.Config.Mode == ModeEphemeral {
		ephemeralRecord, err = m.ephemeral.Load(ctx, sb.ID)
		if err != nil {
			restoreMu.Unlock()
			cancelLifecycle()
			renewal.Stop()
			return fmt.Errorf("load ephemeral FUSE lifecycle: %w", err)
		}
	}
	lifecycle = &fuseSandboxLifecycle{
		sandboxID:       sb.ID,
		sandbox:         sb,
		gate:            gate,
		lease:           lease,
		renewal:         renewal,
		record:          *record,
		cancel:          cancelLifecycle,
		ephemeralRecord: ephemeralRecord,
	}
	m.bindFUSEController(lifecycle, controller)
	restoreMu.Unlock()

	m.mu.Lock()
	restoreMu.Lock()
	if renewalLost != nil {
		lost := renewalLost
		restoreMu.Unlock()
		m.mu.Unlock()
		cancelLifecycle()
		renewal.Stop()
		return errors.Join(ErrWorkspaceLeaseLost, lost)
	}
	if m.sandboxes[sb.ID] != nil || m.operationGates[sb.ID] != nil || m.fuseLifecycles[sb.ID] != nil {
		restoreMu.Unlock()
		m.mu.Unlock()
		cancelLifecycle()
		renewal.Stop()
		return ErrSandboxNotReady
	}
	if !cleanup {
		sb.Workspace.LastHealthyAt = health.LastSuccessful
		if sb.Workspace.LastHealthyAt.IsZero() {
			sb.Workspace.LastHealthyAt = time.Now()
		}
	}
	m.sandboxes[sb.ID] = sb
	m.operationGates[sb.ID] = gate
	m.fuseLifecycles[sb.ID] = lifecycle
	published = true
	restoreMu.Unlock()
	m.mu.Unlock()
	if !cleanup {
		m.startFUSEWatcher(lifecycleCtx, lifecycle)
	}
	recoveryResult = "success"
	return nil
}

// recreateSandbox creates a new container for a persistent sandbox whose
// container was lost (e.g. docker-compose restart).
func (m *Manager) recreateSandbox(ctx context.Context, sb *Sandbox) (*runtime.SandboxInfo, error) {
	// Use the original RuntimeID as the pod/container name so the identity is
	// consistent across restarts. On Docker, RenameSandbox will rename it to
	// sb.ID afterwards; on Kubernetes, pod names are immutable so RuntimeID is
	// the permanent name.
	spec := m.buildSpec(sb.RuntimeID, sb.Config)
	spec.Labels["sandbox.id"] = sb.ID

	// Restore bind mount if applicable
	if sb.Workspace != nil && sb.Workspace.BindMounted && m.fsMeta != nil && m.fsMeta.Provider == storage.ProviderLocal {
		hostPath := m.resolveLocalWorkspacePath(sb.Workspace.RootPath)
		spec.Mounts = append(spec.Mounts, runtime.Mount{
			HostPath:      hostPath,
			ContainerPath: "/workspace",
		})
	}

	info, err := m.runtime.CreateSandbox(ctx, spec)
	if err != nil {
		return nil, fmt.Errorf("create container: %w", err)
	}

	// Rename for identification
	_ = m.runtime.RenameSandbox(ctx, info.RuntimeID, sb.ID)

	return info, nil
}

// cleanupOrphanedPoolContainers removes ordinary pool containers left over
// from a previous process that exited without graceful shutdown. FUSE pool
// runtimes have Redis inventory and exact-UID teardown rules, so they must only
// be reconciled by FUSEPool.
// Must be called AFTER restorePersistentSandboxes so that active containers
// are already registered in m.sandboxes.
func (m *Manager) cleanupOrphanedPoolContainers(ctx context.Context) int {
	containers, err := m.runtime.ListSandboxes(ctx, map[string]string{
		"sandbox.pool": "true",
	})
	if err != nil {
		logger.Error(ctx, "failed to list orphaned pool containers", logger.ErrorField(err))
		return 0
	}

	// Build set of runtime IDs belonging to restored persistent sandboxes
	activeRuntimeIDs := make(map[string]struct{})
	m.mu.RLock()
	for _, sb := range m.sandboxes {
		activeRuntimeIDs[sb.RuntimeID] = struct{}{}
	}
	m.mu.RUnlock()

	var removed int
	for _, c := range containers {
		if c.Labels["sandbox.workspace.mode"] == string(WorkspaceMountFUSE) {
			continue
		}
		if _, active := activeRuntimeIDs[c.RuntimeID]; active {
			continue // in use by a persistent sandbox
		}
		logger.Info(ctx, "removing orphaned pool container",
			logger.AddField("runtime_id", c.RuntimeID),
		)
		if err := m.runtime.RemoveSandbox(ctx, c.RuntimeID); err != nil {
			logger.Error(ctx, "failed to remove orphaned pool container",
				logger.AddField("runtime_id", c.RuntimeID),
				logger.ErrorField(err),
			)
			continue
		}
		removed++
	}
	if removed > 0 {
		logger.Info(ctx, "cleaned up orphaned pool containers",
			logger.AddField("count", removed),
		)
	}
	return removed
}

// drainOrphanedOrdinaryPoolContainers removes Kubernetes ordinary warm-pool
// runtimes that are not represented in this Manager's in-memory Pool.
// Release-drain callers have already stopped every API replica and finalized
// user sandboxes, so any remaining non-FUSE runtime carrying sandbox.pool=true
// is orphaned. Unlike the startup cleanup, this path is fail-closed because
// Helm must not proceed while managed resources remain in the runtime namespace.
func (m *Manager) drainOrphanedOrdinaryPoolContainers(ctx context.Context) error {
	containers, err := m.runtime.ListSandboxes(ctx, map[string]string{
		"sandbox.managed": "true",
		"sandbox.pool":    "true",
	})
	if err != nil {
		return fmt.Errorf("list ordinary pool runtimes during release drain: %w", err)
	}

	var drainErr error
	for _, container := range containers {
		if container.Labels["sandbox.workspace.mode"] == string(WorkspaceMountFUSE) ||
			container.Labels["sandbox.role"] == "fuse-runtime" {
			continue
		}
		if container.Labels["sandbox.managed"] != "true" || container.Labels["sandbox.pool"] != "true" {
			drainErr = errors.Join(drainErr, fmt.Errorf(
				"ordinary pool runtime %s has invalid pool identity", container.RuntimeID,
			))
			continue
		}
		if err := m.runtime.RemoveSandbox(ctx, container.RuntimeID); err != nil {
			drainErr = errors.Join(drainErr, fmt.Errorf(
				"remove ordinary pool runtime %s during release drain: %w", container.RuntimeID, err,
			))
		}
	}
	return drainErr
}

// buildInstallCommand generates the shell command to install dependencies,
// grouping by package manager (pip/npm).
func buildInstallCommand(deps []Dependency) string {
	if len(deps) == 0 {
		return ""
	}
	var pipPkgs, npmPkgs []string
	for _, d := range deps {
		if !validDepRegexp.MatchString(d.Name) {
			logger.Warn(context.Background(), "skipping dependency with invalid name",
				logger.AddField("dep_name", d.Name),
			)
			continue
		}
		if d.Version != "" && !validDepRegexp.MatchString(d.Version) {
			logger.Warn(context.Background(), "skipping dependency with invalid version",
				logger.AddField("dep_name", d.Name),
				logger.AddField("dep_version", d.Version),
			)
			continue
		}
		pkg := d.Name
		switch d.Manager {
		case "pip":
			if d.Version != "" {
				pkg += "==" + d.Version
			}
			pipPkgs = append(pipPkgs, pkg)
		case "npm":
			if d.Version != "" {
				pkg += "@" + d.Version
			}
			npmPkgs = append(npmPkgs, pkg)
		default:
			logger.Warn(context.Background(), "skipping dependency with unknown manager",
				logger.AddField("dep_name", d.Name),
				logger.AddField("manager", d.Manager),
			)
		}
	}
	var cmds []string
	if len(pipPkgs) > 0 {
		cmds = append(cmds, "PIP_CACHE_DIR=/tmp/pip-cache pip install --no-cache-dir "+strings.Join(pipPkgs, " "))
	}
	if len(npmPkgs) > 0 {
		cmds = append(cmds, "npm_config_cache=/tmp/npm-cache npm install --no-save "+strings.Join(npmPkgs, " "))
	}
	return strings.Join(cmds, " && ")
}

// buildSpec constructs a runtime.SandboxSpec from sandbox config.
// Used for network-enabled sandboxes that bypass the pool.
func (m *Manager) buildSpec(id string, cfg SandboxConfig) runtime.SandboxSpec {
	tmpDisk := cfg.Resources.TmpDisk
	if tmpDisk == "" {
		tmpDisk = m.config.PoolConfig.TmpDisk
	}
	return runtime.SandboxSpec{
		ID:                  id,
		Image:               m.config.PoolConfig.Image,
		Memory:              cfg.Resources.Memory,
		CPU:                 cfg.Resources.CPU,
		Disk:                cfg.Resources.Disk,
		TmpDisk:             tmpDisk,
		NetworkEnabled:      cfg.Network.Enabled,
		NetworkWhitelist:    cfg.Network.Whitelist,
		NetworkBlockPrivate: cfg.Network.BlockPrivate,
		ReadOnlyRootFS:      false,
		RunAsUser:           1000,
		PidLimit:            m.pool.config.PidLimit,
		SeccompProfile:      m.pool.config.SeccompProfile,
		Labels: map[string]string{
			"sandbox.id": id,
		},
	}
}

// resolveLocalWorkspacePath returns the absolute host path for a workspace.
func (m *Manager) resolveLocalWorkspacePath(workspacePath string) string {
	if m.fsMeta == nil {
		return workspacePath
	}
	return filepath.Join(m.fsMeta.LocalPath, workspacePath)
}

// registerWorkspace registers a ScopedFS for a bind-mounted workspace without
// copying files (they are already visible via the mount).
func (m *Manager) registerWorkspace(ctx context.Context, sandboxID, rootPath string) error {
	scoped, err := storage.NewScopedFS(m.filesystem, rootPath)
	if err != nil {
		return fmt.Errorf("create scoped filesystem: %w", err)
	}

	now := time.Now()
	m.mu.Lock()
	sb := m.sandboxes[sandboxID]
	m.workspaces[sandboxID] = scoped
	sb.Workspace = &WorkspaceInfo{
		RootPath:     rootPath,
		MountedAt:    now,
		LastSyncedAt: now,
		BindMounted:  true,
		MountType:    WorkspaceMountLocal,
	}
	sb.UpdatedAt = now
	sessionSnapshot := cloneSandbox(sb)
	m.mu.Unlock()

	if sb.Config.Mode == ModePersistent && m.sessions != nil {
		_ = m.sessions.Save(ctx, &sessionSnapshot)
	}
	return nil
}

// InitMultipartUpload initialises a multipart upload session.
// It creates the staging directory in the container and persists state to Redis.
func (m *Manager) InitMultipartUpload(ctx context.Context, sandboxID, destPath string, totalChunks int) (string, error) {
	if m.multipartStore == nil {
		return "", fmt.Errorf("multipart store not configured")
	}

	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, sandboxID)
	if err != nil {
		return "", err
	}
	ctx = operationCtx
	defer release()
	if err := validatePublicFUSEFilePath(sb, destPath); err != nil {
		return "", err
	}
	runtimeID := m.sandboxRuntimeID(sb)

	uploadID := uuid.New().String()

	if _, err := m.runtime.Exec(ctx, runtimeID, runtime.ExecRequest{
		Command: fmt.Sprintf("mkdir -p '/tmp/.uploads/%s'", uploadID),
		Timeout: 10,
	}); err != nil {
		return "", fmt.Errorf("create staging dir: %w", err)
	}

	st := MultipartUploadState{
		UploadID:    uploadID,
		SandboxID:   sandboxID,
		DestPath:    destPath,
		TotalChunks: totalChunks,
		CreatedAt:   time.Now(),
	}
	data, err := json.Marshal(st)
	if err != nil {
		return "", fmt.Errorf("marshal multipart state: %w", err)
	}
	if err := m.multipartStore.Set(ctx, multipartKey(sandboxID, uploadID), data, multipartTTL); err != nil {
		return "", fmt.Errorf("save multipart state: %w", err)
	}
	return uploadID, nil
}

func (m *Manager) loadMultipartState(ctx context.Context, sandboxID, uploadID string) (*MultipartUploadState, error) {
	if m.multipartStore == nil {
		return nil, fmt.Errorf("multipart store not configured")
	}
	data, err := m.multipartStore.Get(ctx, multipartKey(sandboxID, uploadID))
	if err != nil {
		return nil, fmt.Errorf("get multipart state: %w", err)
	}
	if data == nil {
		return nil, fmt.Errorf("%w: %s", ErrUploadNotFound, uploadID)
	}
	var st MultipartUploadState
	if err := json.Unmarshal(data, &st); err != nil {
		return nil, fmt.Errorf("unmarshal multipart state: %w", err)
	}
	if st.SandboxID != sandboxID {
		return nil, fmt.Errorf("%w: %s", ErrUploadNotFound, uploadID)
	}
	return &st, nil
}

func (m *Manager) saveMultipartState(ctx context.Context, sandboxID, uploadID string, st *MultipartUploadState) error {
	data, err := json.Marshal(st)
	if err != nil {
		return fmt.Errorf("marshal multipart state: %w", err)
	}
	ttl := multipartTTL - time.Since(st.CreatedAt)
	if ttl <= 0 {
		ttl = time.Second
	}
	return m.multipartStore.Set(ctx, multipartKey(sandboxID, uploadID), data, ttl)
}

// UploadChunk writes a single chunk to the container staging directory.
// Chunks must be uploaded in order: chunk_index must equal ReceivedChunks.
// Concurrent uploads for the same uploadID are not supported; callers must serialize chunk requests.
func (m *Manager) UploadChunk(ctx context.Context, sandboxID, uploadID string, chunkIndex int, size int64, reader io.Reader) (received int, total int, err error) {
	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, sandboxID)
	if err != nil {
		return 0, 0, err
	}
	ctx = operationCtx
	defer release()
	runtimeID := m.sandboxRuntimeID(sb)
	st, err := m.loadMultipartState(ctx, sandboxID, uploadID)
	if err != nil {
		return 0, 0, err
	}
	if chunkIndex != st.ReceivedChunks {
		return 0, 0, fmt.Errorf("%w: expected %d, got %d", ErrUnexpectedChunkIndex, st.ReceivedChunks, chunkIndex)
	}

	chunkPath := fmt.Sprintf("/tmp/.uploads/%s/%d", uploadID, chunkIndex)
	if err := m.runtime.UploadFile(ctx, runtimeID, chunkPath, size, reader); err != nil {
		return 0, 0, fmt.Errorf("upload chunk: %w", err)
	}

	st.ReceivedChunks++
	if err := m.saveMultipartState(ctx, sandboxID, uploadID, st); err != nil {
		return 0, 0, fmt.Errorf("save multipart state: %w", err)
	}
	return st.ReceivedChunks, st.TotalChunks, nil
}

// GetMultipartStatus returns the current state of a multipart upload.
func (m *Manager) GetMultipartStatus(ctx context.Context, sandboxID, uploadID string) (*MultipartUploadState, error) {
	_, operationCtx, release, err := m.acquireSandboxOperation(ctx, sandboxID)
	if err != nil {
		return nil, err
	}
	ctx = operationCtx
	defer release()
	return m.loadMultipartState(ctx, sandboxID, uploadID)
}

// CompleteMultipartUpload merges all chunks into the destination path.
// Returns the final file size in bytes.
func (m *Manager) CompleteMultipartUpload(ctx context.Context, sandboxID, uploadID string) (destPath string, size int64, err error) {
	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, sandboxID)
	if err != nil {
		return "", 0, err
	}
	ctx = operationCtx
	defer release()
	runtimeID := m.sandboxRuntimeID(sb)
	st, err := m.loadMultipartState(ctx, sandboxID, uploadID)
	if err != nil {
		return "", 0, err
	}
	if err := validatePublicFUSEFilePath(sb, st.DestPath); err != nil {
		return "", 0, err
	}
	if st.ReceivedChunks != st.TotalChunks {
		return "", 0, fmt.Errorf("%w: received %d of %d chunks", ErrIncompleteUpload, st.ReceivedChunks, st.TotalChunks)
	}

	// Build: cat /tmp/.uploads/{id}/0 /tmp/.uploads/{id}/1 ... > destPath
	parts := make([]string, st.TotalChunks)
	for i := 0; i < st.TotalChunks; i++ {
		parts[i] = fmt.Sprintf("'/tmp/.uploads/%s/%d'", uploadID, i)
	}
	escapedDest := "'" + strings.ReplaceAll(st.DestPath, "'", "'\\''") + "'"
	escapedParent := "'" + strings.ReplaceAll(filepath.Dir(st.DestPath), "'", "'\\''") + "'"

	if mkRes, mkErr := m.runtime.Exec(ctx, runtimeID, runtime.ExecRequest{
		Command: "mkdir -p " + escapedParent,
		Timeout: 10,
	}); mkErr != nil || mkRes.ExitCode != 0 {
		if mkErr != nil {
			return "", 0, fmt.Errorf("create dest dir: %w", mkErr)
		}
		return "", 0, fmt.Errorf("create dest dir: exit %d: %s", mkRes.ExitCode, mkRes.Stderr)
	}

	catCmd := "cat " + strings.Join(parts, " ") + " > " + escapedDest
	catRes, err := m.runtime.Exec(ctx, runtimeID, runtime.ExecRequest{
		Command: catCmd,
		Timeout: 120,
	})
	if err != nil {
		return "", 0, fmt.Errorf("merge chunks: %w", err)
	}
	if catRes.ExitCode != 0 {
		return "", 0, fmt.Errorf("merge chunks: exit %d: %s", catRes.ExitCode, catRes.Stderr)
	}

	// Get file size via wc -c
	statResult, statErr := m.runtime.Exec(ctx, runtimeID, runtime.ExecRequest{
		Command: "wc -c < " + escapedDest,
		Timeout: 10,
	})
	if statErr == nil {
		_, _ = fmt.Sscanf(strings.TrimSpace(statResult.Stdout), "%d", &size)
	} else {
		var stderr string
		if statResult != nil {
			stderr = statResult.Stderr
		}
		logger.Warn(ctx, "CompleteMultipartUpload: stat failed",
			logger.AddField("upload_id", uploadID),
			logger.AddField("stderr", stderr),
			logger.ErrorField(statErr),
		)
	}

	// Cleanup staging dir
	if _, rmErr := m.runtime.Exec(ctx, runtimeID, runtime.ExecRequest{
		Command: fmt.Sprintf("rm -rf '/tmp/.uploads/%s'", uploadID),
		Timeout: 10,
	}); rmErr != nil {
		logger.Warn(ctx, "CompleteMultipartUpload: cleanup staging dir failed",
			logger.AddField("upload_id", uploadID),
			logger.ErrorField(rmErr),
		)
	}
	if delErr := m.multipartStore.Delete(ctx, multipartKey(sandboxID, uploadID)); delErr != nil {
		logger.Warn(ctx, "CompleteMultipartUpload: delete multipart state failed",
			logger.AddField("upload_id", uploadID),
			logger.ErrorField(delErr),
		)
	}

	return st.DestPath, size, nil
}

// CancelMultipartUpload removes staging files and Redis state.
func (m *Manager) CancelMultipartUpload(ctx context.Context, sandboxID, uploadID string) error {
	sb, operationCtx, release, err := m.acquireSandboxOperation(ctx, sandboxID)
	if err != nil {
		return err
	}
	ctx = operationCtx
	defer release()
	runtimeID := m.sandboxRuntimeID(sb)
	if _, err := m.loadMultipartState(ctx, sandboxID, uploadID); err != nil {
		return err
	}

	if _, rmErr := m.runtime.Exec(ctx, runtimeID, runtime.ExecRequest{
		Command: fmt.Sprintf("rm -rf '/tmp/.uploads/%s'", uploadID),
		Timeout: 10,
	}); rmErr != nil {
		logger.Warn(ctx, "CancelMultipartUpload: cleanup staging dir failed",
			logger.AddField("upload_id", uploadID),
			logger.ErrorField(rmErr),
		)
	}
	return m.multipartStore.Delete(ctx, multipartKey(sandboxID, uploadID))
}
