package mounter

import (
	"fmt"
	"net/url"
	"regexp"

	"github.com/goairix/sandbox/internal/fuseprotocol"
)

var canonicalRegion = regexp.MustCompile(`^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$`)

type MountParameterStatus string

const (
	MountParametersVerified   MountParameterStatus = "verified"
	MountParametersCandidate  MountParameterStatus = "candidate"
	MountParametersUnverified MountParameterStatus = "unverified"
)

type DurableFlushStatus string

const (
	DurableFlushVerified     DurableFlushStatus = "verified"
	DurableFlushPendingSpike DurableFlushStatus = "blocked-pending-flush-spike"
)

// ProfileDescriptor is the complete, non-executable audit identity of a
// compiled profile. Runtime argv is generated only by Profile.Options below;
// a packaged manifest can attest to this descriptor but cannot add options.
type ProfileDescriptor struct {
	ID               string               `json:"id"`
	Provider         string               `json:"provider"`
	MountParameters  MountParameterStatus `json:"mount_parameters"`
	DurableFlush     DurableFlushStatus   `json:"durable_flush"`
	TLSRequired      bool                 `json:"tls_required"`
	EndpointOption   string               `json:"endpoint_option"`
	RegionOption     string               `json:"region_option"`
	AddressingStyle  string               `json:"addressing_style"`
	SignatureVersion string               `json:"signature_version"`
}

type Profile struct {
	ID         string
	Provider   string
	Descriptor ProfileDescriptor
	Options    func(fuseprotocol.BootstrapConfig) ([]string, error)
	Flush      func(fuseprotocol.BootstrapConfig) []string
}

type ProfileRegistry interface {
	Lookup(id string) (Profile, bool)
}

type StaticProfiles map[string]Profile

func (p StaticProfiles) Lookup(id string) (Profile, bool) { profile, ok := p[id]; return profile, ok }

var compiledProfileCatalog = map[string]Profile{
	"minio-sigv4-path-style-v1": {
		ID: "minio-sigv4-path-style-v1", Provider: "minio",
		Descriptor: ProfileDescriptor{
			ID: "minio-sigv4-path-style-v1", Provider: "minio",
			MountParameters: MountParametersVerified, DurableFlush: DurableFlushVerified,
			TLSRequired: true, EndpointOption: "url", RegionOption: "endpoint",
			AddressingStyle: "path", SignatureVersion: "sigv4",
		},
		Options: minioOptions,
		Flush:   syncFilesystem,
	},
	"minio-sigv4-path-style-private-http-v1": {
		ID: "minio-sigv4-path-style-private-http-v1", Provider: "minio",
		Descriptor: ProfileDescriptor{
			ID: "minio-sigv4-path-style-private-http-v1", Provider: "minio",
			MountParameters: MountParametersVerified, DurableFlush: DurableFlushVerified,
			TLSRequired: false, EndpointOption: "url", RegionOption: "endpoint",
			AddressingStyle: "path", SignatureVersion: "sigv4",
		},
		Options: minioPrivateHTTPOptions,
		Flush:   syncFilesystem,
	},
	"huawei-obs-public-v1": {
		ID: "huawei-obs-public-v1", Provider: "obs",
		Descriptor: ProfileDescriptor{
			ID: "huawei-obs-public-v1", Provider: "obs",
			MountParameters: MountParametersVerified, DurableFlush: DurableFlushVerified,
			TLSRequired: true, EndpointOption: "url", RegionOption: "endpoint",
			AddressingStyle: "virtual-host", SignatureVersion: "sigv2",
		},
		Options: huaweiPublicOptions,
		Flush:   syncFilesystem,
	},
	"huawei-obs-private-2023-v1": {
		ID: "huawei-obs-private-2023-v1", Provider: "obs",
		Descriptor: ProfileDescriptor{
			ID: "huawei-obs-private-2023-v1", Provider: "obs",
			MountParameters: MountParametersVerified, DurableFlush: DurableFlushVerified,
			TLSRequired: true, EndpointOption: "url", RegionOption: "endpoint",
			AddressingStyle: "virtual-host", SignatureVersion: "sigv2",
		},
		Options: huaweiPrivate2023Options,
		Flush:   syncFilesystem,
	},
}

var bundledProfileIDs = [...]string{
	"minio-sigv4-path-style-v1",
	"minio-sigv4-path-style-private-http-v1",
	"huawei-obs-public-v1",
	"huawei-obs-private-2023-v1",
}

func syncFilesystem(config fuseprotocol.BootstrapConfig) []string {
	return []string{"/bin/sync", "-f", "--", config.MountPath}
}

func minioOptions(config fuseprotocol.BootstrapConfig) ([]string, error) {
	if err := requireHTTPS(config.Endpoint); err != nil {
		return nil, err
	}
	if config.Provider != "" && config.Provider != "minio" {
		return nil, fmt.Errorf("minio profile provider mismatch")
	}
	if !canonicalRegion.MatchString(config.Region) {
		return nil, fmt.Errorf("minio profile requires a canonical SigV4 region")
	}
	return []string{"-o", "url=" + config.Endpoint, "-o", "endpoint=" + config.Region, "-o", "use_path_request_style", "-o", "sigv4"}, nil
}

func minioPrivateHTTPOptions(config fuseprotocol.BootstrapConfig) ([]string, error) {
	if err := requireHTTP(config.Endpoint); err != nil {
		return nil, err
	}
	if config.Provider != "" && config.Provider != "minio" {
		return nil, fmt.Errorf("minio profile provider mismatch")
	}
	if !canonicalRegion.MatchString(config.Region) {
		return nil, fmt.Errorf("minio profile requires a canonical SigV4 region")
	}
	return []string{"-o", "url=" + config.Endpoint, "-o", "endpoint=" + config.Region, "-o", "use_path_request_style", "-o", "sigv4"}, nil
}

func huaweiPublicOptions(config fuseprotocol.BootstrapConfig) ([]string, error) {
	if err := requireHTTPS(config.Endpoint); err != nil {
		return nil, err
	}
	if config.Provider != "" && config.Provider != "obs" {
		return nil, fmt.Errorf("huawei OBS profile provider mismatch")
	}
	if !canonicalRegion.MatchString(config.Region) {
		return nil, fmt.Errorf("huawei OBS public profile requires a region endpoint value")
	}
	return []string{"-o", "url=" + config.Endpoint, "-o", "endpoint=" + config.Region, "-o", "sigv2"}, nil
}

func huaweiPrivate2023Options(config fuseprotocol.BootstrapConfig) ([]string, error) {
	if err := requireHTTPS(config.Endpoint); err != nil {
		return nil, err
	}
	if config.Provider != "" && config.Provider != "obs" {
		return nil, fmt.Errorf("huawei OBS private profile provider mismatch")
	}
	if !canonicalRegion.MatchString(config.Region) {
		return nil, fmt.Errorf("huawei OBS private profile requires a canonical region endpoint value")
	}
	return []string{"-o", "url=" + config.Endpoint, "-o", "endpoint=" + config.Region, "-o", "sigv2", "-o", "compat_dir"}, nil
}

func requireHTTPS(raw string) error {
	endpoint, err := url.Parse(raw)
	if err != nil || endpoint.Scheme != "https" || endpoint.Hostname() == "" || endpoint.User != nil || endpoint.RawQuery != "" || endpoint.Fragment != "" || (endpoint.Path != "" && endpoint.Path != "/") {
		return fmt.Errorf("profile requires a canonical TLS HTTPS endpoint")
	}
	return nil
}

func requireHTTP(raw string) error {
	endpoint, err := url.Parse(raw)
	if err != nil || endpoint.Scheme != "http" || endpoint.Hostname() == "" || endpoint.User != nil || endpoint.RawQuery != "" || endpoint.Fragment != "" || (endpoint.Path != "" && endpoint.Path != "/") {
		return fmt.Errorf("profile requires a canonical HTTP endpoint")
	}
	return nil
}

// InspectCompiledProfile exposes audit metadata, including blocked candidates.
// It must not be used to select a production mount profile.
func InspectCompiledProfile(id string) (Profile, bool) {
	profile, ok := compiledProfileCatalog[id]
	return profile, ok
}

// LookupCompiledProfile is the production mount lookup. Candidate and
// unverified entries, unknown IDs, and provider mismatches all fail closed.
func LookupCompiledProfile(provider, id string) (Profile, bool) {
	profile, ok := InspectCompiledProfile(id)
	if !ok || profile.Provider != provider || profile.Descriptor.MountParameters != MountParametersVerified || profile.Options == nil {
		return Profile{}, false
	}
	return profile, true
}

func CompiledProfiles() ProfileRegistry {
	return BundledProfiles()
}

// BundledProfiles returns every production profile compiled into the common
// mounter binary. The packaged profile bundle is audit evidence only; it
// cannot add or override executable mount behavior.
func BundledProfiles() ProfileRegistry {
	profiles := make(StaticProfiles, len(bundledProfileIDs))
	for _, id := range bundledProfileIDs {
		profile, ok := compiledProfileCatalog[id]
		if !ok || profile.Descriptor.MountParameters != MountParametersVerified || profile.Options == nil {
			continue
		}
		profiles[id] = profile
	}
	return profiles
}

func CheckProductionProfile(provider, id string) error {
	profile, ok := InspectCompiledProfile(id)
	if !ok || profile.Provider != provider {
		return fmt.Errorf("profile is unknown or does not match provider")
	}
	switch profile.Descriptor.MountParameters {
	case MountParametersVerified:
		// Continue to the independent durability gate.
	case MountParametersCandidate:
		return fmt.Errorf("profile is blocked pending provider spike")
	default:
		return fmt.Errorf("profile is blocked pending provider spike")
	}
	if selectable, ok := LookupCompiledProfile(provider, id); !ok || selectable.Options == nil {
		return fmt.Errorf("profile has no verified mount implementation")
	}
	if profile.Descriptor.DurableFlush != DurableFlushVerified || profile.Flush == nil {
		return fmt.Errorf("profile is blocked pending durable-flush provider spike")
	}
	return nil
}
